package ma.salah.eddine.schoolmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Movement::class, MovementCoverage::class, EntrySlip::class, SlipStudent::class, ScheduledLesson::class,
        FamilyContact::class,
        StudentEntity::class,
        SchoolClassEntity::class,
        SubjectEntity::class,
        EnrollmentEntity::class,
        EmployeeEntity::class,
        EmployeeServiceEntity::class,
        ReferenceValueEntity::class,
        TeacherAssignmentEntity::class,
        AppSettingEntity::class,
        ImportHistoryEntity::class
    ],
    version = 7,
    exportSchema = false
)
abstract class SchoolDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao

    companion object {
        @Volatile private var instance: SchoolDatabase? = null

        fun closeForRestore() = synchronized(this) {
            instance?.close()
            instance = null
        }

        fun get(context: Context): SchoolDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                SchoolDatabase::class.java,
                "salah_eddine_school.db"
            ).addMigrations(object : androidx.room.migration.Migration(1,2) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE IF NOT EXISTS family_contacts (year TEXT NOT NULL, massar TEXT NOT NULL, role TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, kind TEXT NOT NULL, PRIMARY KEY(year,massar,role))")
                }
            }, object : androidx.room.migration.Migration(2,3) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("ALTER TABLE enrollments ADD COLUMN ordinal INTEGER")
                    db.execSQL("CREATE TABLE scheduled_lessons (revision TEXT NOT NULL, activity TEXT NOT NULL, teacher TEXT NOT NULL, subject TEXT NOT NULL, section TEXT NOT NULL, room TEXT NOT NULL, day TEXT NOT NULL, hour INTEGER NOT NULL, duration INTEGER NOT NULL, PRIMARY KEY(revision,activity))")
                }
            }, object : androidx.room.migration.Migration(3,4) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE entry_slips (id TEXT NOT NULL PRIMARY KEY, year TEXT NOT NULL, date TEXT NOT NULL, time TEXT NOT NULL, section TEXT NOT NULL, reason TEXT NOT NULL, guardianStudent TEXT NOT NULL, guardianName TEXT NOT NULL, relation TEXT NOT NULL, identity TEXT NOT NULL)")
                    db.execSQL("CREATE INDEX index_entry_slips_year_date ON entry_slips(year,date)")
                    db.execSQL("CREATE TABLE slip_students (slip TEXT NOT NULL, massar TEXT NOT NULL, displayName TEXT NOT NULL, ordinal INTEGER, PRIMARY KEY(slip,massar), FOREIGN KEY(slip) REFERENCES entry_slips(id) ON UPDATE NO ACTION ON DELETE NO ACTION)")
                    db.execSQL("CREATE INDEX index_slip_students_massar ON slip_students(massar)")
                }
            }, object : androidx.room.migration.Migration(4,5) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    for (field in listOf("mobile","landline","address","city","nationalId")) {
                        db.execSQL("ALTER TABLE employees ADD COLUMN $field TEXT")
                    }
                }
            }, object : androidx.room.migration.Migration(5,6) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("ALTER TABLE family_contacts ADD COLUMN address TEXT")
                }
            }, object : androidx.room.migration.Migration(6,7) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE movements (year TEXT NOT NULL, kind TEXT NOT NULL, massar TEXT NOT NULL, eventDate TEXT NOT NULL, fullName TEXT NOT NULL, level TEXT NOT NULL, section TEXT NOT NULL, origin TEXT NOT NULL, destination TEXT NOT NULL, transferType TEXT NOT NULL, ordinal INTEGER, PRIMARY KEY(year,kind,massar,eventDate))")
                    db.execSQL("CREATE TABLE movement_coverage (year TEXT NOT NULL, kind TEXT NOT NULL, level TEXT NOT NULL, section TEXT NOT NULL, PRIMARY KEY(year,kind,level,section))")
                }
            }).build().also { instance = it }
        }
    }
}
