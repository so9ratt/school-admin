package ma.salah.eddine.schoolmanager

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextDirectionHeuristics
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.*
import ma.salah.eddine.schoolmanager.data.*

internal data class Register(val title:String,val school:String,val academy:String,val province:String,val year:String,
    val headers:List<String>,val widths:List<Int>,val groups:List<RegisterGroup>)
internal data class RegisterGroup(val section:String,val level:String,val rows:List<List<String>>)

@Composable
internal fun FamilyExport(dao:SchoolDao,year:String,school:String,academy:String,province:String){

    var classes by remember(year){mutableStateOf(emptyList<ClassSummary>())}
    LaunchedEffect(year){ classes=dao.classSummaries(year) }
    var level by rememberSaveable(year){mutableStateOf("")}
    var section by rememberSaveable(year){mutableStateOf("")}
    RosterFilter("حسب المستوى",level,classes.map { it.levelName }.distinct(),Modifier.fillMaxWidth()){level=it;section=""}
    RosterFilter("حسب القسم",section,classes.filter {level.isBlank()||it.levelName==level}.map{it.className},Modifier.fillMaxWidth()){section=it}
    ExportButtons(true,"Parents-"+year.replace('/','-')) {
        val family=dao.familyForYear(year).groupBy { it.massar }
        val ids=dao.familyIds().associate { it.key to it.value }
        val groups=dao.studentsForYear(year).filter { (level.isBlank()||level==it.levelName)&&(section.isBlank()||section==it.className) }.groupBy {it.className}.map { (c,pupils)->
            RegisterGroup(c,pupils.first().levelName,pupils.map { s->
                val parents=family[s.massarCode].orEmpty()
                val father=parents.find {it.role=="الأب"}
                val mother=parents.find {it.role=="الأم"}
                val parent=listOfNotNull(father,mother).firstOrNull {it.name.isNotBlank()}
                listOf(s.ordinal?.toString().orEmpty(),s.givenName+" "+s.surname,parent?.name.orEmpty(),parent?.role.orEmpty(),father?.phone.orEmpty(),mother?.phone.orEmpty(),parent?.address.orEmpty(),ids["family.id.$year.${s.massarCode}.${parent?.role}"].orEmpty())
            })
        }
        Register("لائحة أولياء أمور التلاميذ",school,academy,province,year,listOf("ر.ت","اسم التلميذ ونسبه","اسم ولي الأمر ونسبه","الصفة","هاتف الأب","هاتف الأم","العنوان","رقم البطاقة الوطنية"),listOf(5,18,18,7,12,12,18,10),groups)
    }
}

@Composable
internal fun ExportButtons(excel:Boolean,file:String,report:suspend ()->Register){
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun write(uri:android.net.Uri?,xlsx:Boolean){
        if(uri==null)return
        busy=true
        scope.launch {
            runCatching { withContext(Dispatchers.IO){
                val data=report()
                require(data.groups.any {it.rows.isNotEmpty()}){"لا توجد بيانات للتصدير"}
                context.contentResolver.openOutputStream(uri,"wt")?.use { out->
                    if(xlsx) spreadsheet(context,data,out) else printRegister(context,data,out)
                } ?: error("تعذر فتح الوجهة")
            } }.onSuccess {message="تم حفظ الملف"}.onFailure {message=it.message ?: "تعذر التصدير"}
            busy=false
        }
    }
    val pdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){write(it,false)}
    val sheet=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){write(it,true)}
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedButton(onClick={pdf.launch("$file.pdf")},enabled=!busy){Text("تصدير PDF")}
        if(excel) OutlinedButton(onClick={sheet.launch("$file.xlsx")},enabled=!busy){Text("تصدير Excel")}
    }
    if(message.isNotBlank()) Text(message)
}

private fun printRegister(ctx:Context,reg:Register,out:OutputStream){
    val logo=BitmapFactory.decodeResource(ctx.resources,R.drawable.ministry_new)
    val ink=Color.rgb(12,54,78)
    val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    var pageNumber=0
    fun block(value:String,width:Int,size:Float,bold:Boolean=false):StaticLayout {
        val tp=TextPaint(Paint.ANTI_ALIAS_FLAG).apply {color=ink;textSize=size;typeface=if(bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT}
        return StaticLayout.Builder.obtain(value,0,value.length,tp,width).setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL).build()
    }
    val pdf=PdfDocument()
    try {
        for(group in reg.groups){
            var index=0
            while(index<group.rows.size){
                val page=pdf.startPage(PdfDocument.PageInfo.Builder(842,595,++pageNumber).create())
                val c=page.canvas
                val w=logo.width*40f/logo.height
                c.drawBitmap(logo,null,RectF(421-w/2,10f,421+w/2,50f),null)
                fun header(text:String,y:Int,size:Float){c.save();c.translate(20f,y.toFloat());block(text,802,size,true).draw(c);c.restore()}
                header(reg.academy+"   •   "+reg.province,52,10f)
                header(reg.school,69,12f);header(reg.title,89,15f)
                header("الموسم "+reg.year+"     •     "+group.level+"     •     "+group.section,113,10f)
                var y=135
                fun row(values:List<String>,heading:Boolean):Boolean{
                    val widths=reg.widths.map { 800*it/reg.widths.sum() }
                    val layouts=values.mapIndexed { i,v->block(v.ifBlank{"—"},widths[i]-6,if(heading) 10f else 9f,heading)}
                    val h=(layouts.maxOf {it.height}+8).coerceAtLeast(22)
                    if(y+h>565 && y>160)return false
                    var right=821
                    layouts.forEachIndexed {i,l->
                        val left=right-widths[i]
                        paint.color=if(heading) Color.rgb(211,231,240) else if(index%2==0) Color.WHITE else Color.rgb(242,247,249)
                        c.drawRect(left.toFloat(),y.toFloat(),right.toFloat(),(y+h).toFloat(),paint)
                        paint.color=Color.LTGRAY;c.drawLine(left.toFloat(),y.toFloat(),left.toFloat(),(y+h).toFloat(),paint)
                        c.save();c.translate((left+3).toFloat(),(y+(h-l.height)/2).toFloat());l.draw(c);c.restore();right=left
                    }
                    y+=h;return true
                }
                row(reg.headers,true)
                while(index<group.rows.size && row(group.rows[index],false))index++
                header(pageNumber.toString(),573,9f);pdf.finishPage(page)
            }
        }
        pdf.writeTo(out)
    } finally {pdf.close()}
}

private fun xml(s:String)=android.text.TextUtils.htmlEncode(s.filter {it.code>=32 || it=='\n' || it=='\t'})
private fun spreadsheet(ctx:Context,reg:Register,out:OutputStream){
    val ss="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    val rel="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    val pkg="http://schemas.openxmlformats.org/package/2006/relationships"
    val doc="application/vnd.openxmlformats-officedocument.spreadsheetml."
    ZipOutputStream(out).use { z->
        fun entry(path:String,body:String){z.putNextEntry(ZipEntry(path));z.write(body.toByteArray());z.closeEntry()}
        fun relationships(path:String,items:List<Pair<String,String>>){
            entry(path,"""<Relationships xmlns="$pkg">"""+items.mapIndexed { i,(type,target)->"""<Relationship Id="rId${i+1}" Type="$rel/$type" Target="$target"/>""" }.joinToString("")+"</Relationships>")
        }
        val n=reg.groups.size
        entry("[Content_Types].xml","""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="jpg" ContentType="image/jpeg"/><Override PartName="/xl/workbook.xml" ContentType="${doc}sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="${doc}styles+xml"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>"""+(1..n).joinToString(""){"""<Override PartName="/xl/worksheets/sheet$it.xml" ContentType="${doc}worksheet+xml"/>"""}+"</Types>")
        relationships("_rels/.rels",listOf("officeDocument" to "xl/workbook.xml"))
        relationships("xl/_rels/workbook.xml.rels",(1..n).map {"worksheet" to "worksheets/sheet$it.xml"}+("styles" to "styles.xml"))
        val used=mutableSetOf<String>()
        entry("xl/workbook.xml","""<workbook xmlns="$ss" xmlns:r="$rel"><sheets>"""+reg.groups.mapIndexed { i,g->
            val base=g.section.map {if(it in "[]:*?/\\") '_' else it}.joinToString("").trim('\'').ifBlank{"قسم"}.take(31)
            var name=base;var j=1
            while(!used.add(name.lowercase())){val suffix="-"+j++;name=base.take(31-suffix.length)+suffix}
            """<sheet name="${xml(name)}" sheetId="${i+1}" r:id="rId${i+1}"/>"""
        }.joinToString("")+"</sheets></workbook>")
        entry("xl/styles.xml","""<styleSheet xmlns="$ss"><fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="12"/><color rgb="FF093853"/><name val="Arial"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDCECF2"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>""")
        z.putNextEntry(ZipEntry("xl/media/logo.jpg"));ctx.resources.openRawResource(R.drawable.ministry_new).use {it.copyTo(z)};z.closeEntry()
        val draw="http://schemas.openxmlformats.org/drawingml/2006"
        entry("xl/drawings/drawing1.xml","""<xdr:wsDr xmlns:xdr="$draw/spreadsheetDrawing" xmlns:a="$draw/main" xmlns:r="$rel"><xdr:oneCellAnchor><xdr:from><xdr:col>2</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:ext cx="2450000" cy="735000"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="1" name="شعار الوزارة"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>""")
        relationships("xl/drawings/_rels/drawing1.xml.rels",listOf("image" to "../media/logo.jpg"))
        reg.groups.forEachIndexed { i,g->
            relationships("xl/worksheets/_rels/sheet${i+1}.xml.rels",listOf("drawing" to "../drawings/drawing1.xml"))
            val rows=listOf(emptyList(),listOf(reg.academy+" • "+reg.province),listOf(reg.school),listOf(reg.title),listOf(reg.year+" • "+g.level+" • "+g.section),reg.headers)+g.rows
            val sheet=buildString {
                append("""<worksheet xmlns="$ss" xmlns:r="$rel"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews><cols>""")
                reg.widths.forEachIndexed { col,w->append("""<col min="${col+1}" max="${col+1}" width="${w*1.6}" customWidth="1"/>""") }
                append("</cols><sheetData>")
                rows.forEachIndexed { r,values->
                    append("""<row r="${r+1}" ht="${if(r==0) 64 else if(r<=5) 24 else 32}" customHeight="1">""")
                    values.forEachIndexed { col,v->append("""<c r="${'A'+col}${r+1}" s="${if(r in 1..5) 1 else 0}" t="inlineStr"><is><t xml:space="preserve">${xml(v.ifBlank{"—"})}</t></is></c>""") }
                    append("</row>")
                }
                append("</sheetData><mergeCells count=\"4\">")
                for(r in 2..5)append("""<mergeCell ref="A$r:H$r"/>""")
                append("""</mergeCells><pageMargins left="0.25" right="0.25" top="0.3" bottom="0.3" header="0" footer="0"/><pageSetup paperSize="9" orientation="landscape"/><drawing r:id="rId1"/></worksheet>""")
            }
            entry("xl/worksheets/sheet${i+1}.xml",sheet)
        }
    }
}
