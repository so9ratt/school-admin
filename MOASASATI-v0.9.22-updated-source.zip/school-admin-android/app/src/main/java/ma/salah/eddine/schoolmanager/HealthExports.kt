package ma.salah.eddine.schoolmanager

import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import ma.salah.eddine.schoolmanager.data.*
import org.json.JSONArray
import org.json.JSONObject

internal data class ExportGroup(val name:String,val rows:List<List<String>>)
@Composable
internal fun TableExport(title:String,school:String,academy:String,province:String,year:String,headers:List<String>,groups:List<ExportGroup>) {
    val context=LocalContext.current
    var message by remember { mutableStateOf("") }
    val pdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){ uri ->
        if(uri!=null) message=runCatching {
            context.contentResolver.openOutputStream(uri)!!.use { out ->
                val doc=PdfDocument(); var number=0
                try {
                    groups.forEach { group ->
                        (group.rows.chunked(19).ifEmpty { listOf(emptyList()) }).forEach { rows ->
                            val page=doc.startPage(PdfDocument.PageInfo.Builder(842,595,++number).create()); val c=page.canvas
                            val p=Paint(Paint.ANTI_ALIAS_FLAG); p.textSize=12f; p.textAlign=Paint.Align.CENTER
                            val logo=BitmapFactory.decodeResource(context.resources,R.drawable.ministry_new)
                            c.drawBitmap(logo,null,RectF(235f,12f,607f,105f),p)
                            c.drawText("$academy — $province",421f,120f,p); c.drawText("$school — $year",421f,138f,p); c.drawText("$title — ${group.name}",421f,158f,p)
                            val w=800f/headers.size
                            (listOf(headers)+rows).forEachIndexed { i,row ->
                                row.forEachIndexed { j,value ->
                                    val x=821f-(j+1)*w; val y=172f+i*20f
                                    p.style=Paint.Style.STROKE; c.drawRect(x,y,x+w,y+20,p); p.style=Paint.Style.FILL
                                    p.textSize=10f; while(p.measureText(value)>w-5 && p.textSize>5f) p.textSize-=0.5f
                                    c.save();c.clipRect(x,y,x+w,y+20);c.drawText(value,x+w/2,y+14,p);c.restore()
                                }
                            };doc.finishPage(page)
                        }
                    };doc.writeTo(out)
                } finally {doc.close()}
            }; "تم التصدير"
        }.getOrElse { "تعذر التصدير: ${it.message}" }
    }
    val excel=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")){uri ->
        if(uri!=null) message=runCatching {
            context.contentResolver.openOutputStream(uri)!!.use { out ->
                val book=jxl.Workbook.createWorkbook(out)
                groups.forEachIndexed { i,g -> val sheet=book.createSheet(g.name.take(31),i); (listOf(headers)+g.rows).forEachIndexed { r,row -> row.forEachIndexed { col,v -> sheet.addCell(jxl.write.Label(col,r,v)) } } };book.write();book.close()
            };"تم التصدير"
        }.getOrElse { "تعذر التصدير: ${it.message}" }
    }
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick={pdf.launch("$title.pdf")}){Text("PDF")};OutlinedButton(onClick={excel.launch("$title.xls")}){Text("Excel")} }
    if(message.isNotBlank()) Text(message)
}
@Composable
internal fun GuardianExportScreen(dao:SchoolDao,year:String,school:String,academy:String,province:String,back:()->Unit){
    Column(Modifier.fillMaxSize().padding(12.dp)){
        PageTitle("تصدير معلومات أولياء الأمور",back)
        FamilyExport(dao,year,school,academy,province)
    }
}
@Composable
internal fun HealthScreen(dao:SchoolDao,year:String,school:String,academy:String,province:String,back:()->Unit){
    var section by remember {mutableStateOf("")};var mode by remember {mutableStateOf("")};var query by remember {mutableStateOf("")};var roster by remember {mutableStateOf(emptyList<StudentListRow>())};var chosen by remember {mutableStateOf<StudentListRow?>(null)};var date by remember {mutableStateOf("")};var note by remember {mutableStateOf("")};val scope=rememberCoroutineScope()
    val key="health.$year.$mode";val raw by remember(key){dao.watchSetting(key)}.collectAsState(initial=null)
    val records=remember(raw){val a=runCatching {JSONArray(raw?:"[]")}.getOrElse {JSONArray()};(0 until a.length()).map {a.getJSONObject(it)}}
    LaunchedEffect(year){roster=dao.studentsForYear(year)}
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
        PageTitle(mode.ifBlank {"الصحة المدرسية"}){if(mode.isBlank())back() else mode=""}
        if(mode.isBlank()){listOf("الإعفاء من التربية البدنية","نقل التلميذ إلى المستشفى").forEach { label -> Button(onClick={mode=label;query="";section=""},modifier=Modifier.fillMaxWidth()){Text(label)} }} else {
            val hospital=mode=="نقل التلميذ إلى المستشفى"
            Text("المجموع: ${records.distinctBy {it.optString("massar")}.size} • الإناث: ${records.filter {it.optString("gender").isFemaleValue()}.distinctBy {it.optString("massar")}.size}")
            Text("الذكور: "+records.filter {it.optString("gender").isMaleValue()}.distinctBy {it.optString("massar")}.size)
            if(hospital) Text("عدد عمليات النقل: "+records.size)
            SearchBox(query,{query=it},"الاسم أو رقم مسار أو القسم أو الرقم الترتيبي")
            if(query.isNotBlank()) roster.filter { it.ordinal?.toString()==query.trim() || (it.givenName+" "+it.surname).contains(query,true) || (it.surname+" "+it.givenName+" "+it.massarCode+" "+it.className).contains(query,true) }.take(5).forEach { s -> TextButton(onClick={chosen=s;date=java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));note=""}){Text(s.surname+" "+s.givenName+" — "+s.className)} }
            RosterFilter("جميع الأقسام",section,records.map {it.optString("class")}.distinct().sorted(),Modifier.fillMaxWidth()){section=it}
            val visible=records.filter {section.isBlank()||it.optString("class")==section}
            TableExport(mode,school,academy,province,year,listOf("ر.ت","مسار","الاسم","القسم","التاريخ والساعة","ملاحظة"),visible.groupBy {it.optString("class")}.map { (name,rs)->ExportGroup(name,rs.map {r->listOf(r.optString("ordinal").ifBlank{roster.find {it.massarCode==r.optString("massar")}?.ordinal?.toString().orEmpty()})+listOf("massar","name","class","date","note").map {r.optString(it)}}) })
            LazyColumn {items(visible){r->Text(r.optString("name")+" • "+r.optString("class")+" • "+r.optString("date"));Text(r.optString("note"));HorizontalDivider()} }
            chosen?.let {s->AlertDialog(onDismissRequest={chosen=null},title={Text(s.surname+" "+s.givenName)},text={Column {if(hospital){OutlinedTextField(date,{date=it},label={Text("التاريخ والساعة")});OutlinedTextField(note,{note=it},label={Text("ملاحظات")})}}},confirmButton={TextButton(onClick={scope.launch {val a=JSONArray(dao.setting(key)?:"[]");if(hospital||(0 until a.length()).none {a.getJSONObject(it).optString("massar")==s.massarCode}){a.put(JSONObject().put("ordinal",s.ordinal?.toString().orEmpty()).put("massar",s.massarCode).put("name",s.surname+" "+s.givenName).put("class",s.className).put("gender",s.gender).put("date",date).put("note",note));dao.saveSetting(AppSettingEntity(key,a.toString()))};chosen=null;query=""}}){Text("حفظ")}},dismissButton={TextButton(onClick={chosen=null}){Text("إلغاء")}})}
        }
    }
}
