package ma.salah.eddine.schoolmanager

import android.app.TimePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ma.salah.eddine.schoolmanager.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

private val kinds = listOf("مخالفات","التزامات سلوك","التزامات غياب")
private val icons = listOf(Icons.Default.EditNote, Icons.Default.Assignment, Icons.Default.CalendarMonth)
private val accents = listOf(Color(0xFFAB5514),Color(0xFF127858),Color(0xFF126684))
private val incidents = listOf("عرقلة السير العادي للحصة","عدم الامتثال للتعليمات","استعمال الهاتف داخل الفصل","تهديد أمن وسلامة الأستاذ والتلاميذ","التلفظ بكلام نابٍ داخل القسم")
private val behaviors = listOf("استعمال الهاتف داخل المؤسسة","التلفظ بكلام نابٍ داخل المؤسسة","عرقلة السير العادي للدراسة","تهديد أمن وسلامة الأطر التربوية")
private val measures = listOf("توبيخ التلميذ","توقيع التزام مصادق عليه من طرف ولي الأمر","توقيع التزام في مكتب الحراسة العامة","العرض على المجلس التأديبي")
private val clock = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT)

@Composable
private fun Panel(content:@Composable ColumnScope.()->Unit) {
    Card(modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp),content=content)
    }
}

@Composable
private fun Heading(title:String) { Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary) }

@Composable
internal fun ConductScreen(dao:SchoolDao,year:String,initialKind:String="",back:()->Unit) {
    var kind by rememberSaveable { mutableStateOf(initialKind) }
    var adding by rememberSaveable { mutableStateOf(initialKind.isNotEmpty()) }
    val records by remember(dao,year){dao.conduct(year)}.collectAsState(emptyList())
    fun previous() { if(adding) adding=false else if(kind.isNotEmpty()) kind="" else back() }
    BackHandler { previous() }
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        PageTitle(if(kind.isEmpty()) "المواظبة والسلوك" else kind){ previous() }
        if(kind.isEmpty()) {
            kinds.forEachIndexed { i,title ->
                Card(onClick={kind=title},modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(44.dp).background(accents[i].copy(alpha=.10f),RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center){
                            Icon(icons[i],null,tint=accents[i])
                        }
                        Column(Modifier.weight(1f)) { Heading(title); Text("عدد السجلات • "+records.count { it.kind==title }) }
                        Icon(Icons.Default.KeyboardArrowLeft,null)
                    }
                }
            }
        } else if(adding) ConductForm(dao,year,kind){adding=false}
        else key(kind) { ConductList(dao,kind,records.filter { it.kind==kind }){adding=true} }
    }
}

@Composable
private fun ConductList(dao:SchoolDao,kind:String,records:List<ConductRecord>,add:()->Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var level by rememberSaveable { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf("") }
    val levels=records.map { it.level }.distinct().sorted()
    val sections=records.filter { level=="" || it.level==level }.map { it.section }.distinct().sorted()
    val found=records.filter { (level=="" || it.level==level) && (section=="" || it.section==section) &&
        matches(query,it.studentName,it.massar) }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item { Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            SummaryCard("المجموع",found.size.toString(),Modifier.weight(1f))
            if(kind==kinds.first()) {
                SummaryCard("قيد المعالجة",found.count { !it.closed }.toString(),Modifier.weight(1f))
                SummaryCard("تمت تسويتها",found.count { it.closed }.toString(),Modifier.weight(1f))
            }
        } }
        item { SearchBox(query,{query=it},"اسم التلميذ أو رمز مسار") }
        item { Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            RosterFilter("حسب المستوى",level,levels,Modifier.weight(1f)){level=it;section=""}
            RosterFilter("حسب القسم",section,sections,Modifier.weight(1f)){section=it}
        } }
        item { Button(onClick=add){Icon(Icons.Default.Add,null);Text(if(kind==kinds.first()) "إضافة مخالفة" else "إضافة التزام")} }
        if(found.isEmpty()) item { Text("لا توجد سجلات مطابقة") }
        items(found,key={it.id}) { ConductCard(dao,it) }
    }
}

private fun matches(query:String,vararg values:String):Boolean =
    query.trim().split(Regex("\\s+")).all { part -> values.any { it.contains(part,true) } }

@Composable
private fun ConductCard(dao:SchoolDao,r:ConductRecord) {
    var open by rememberSaveable(r.id){mutableStateOf(false)}
    var edit by rememberSaveable(r.id){mutableStateOf(false)}
    Panel {
        Row(Modifier.fillMaxWidth().clickable { open=!open }.padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Heading(r.studentName)
                Text(listOf(r.section,r.date,r.time).joinToString("   •   "),style=MaterialTheme.typography.bodySmall)
            }
            if(r.kind==kinds.first()) Text(if(r.closed)"تمت تسويتها" else "قيد المعالجة",color=if(r.closed) accents[1] else accents[0])
            Icon(if(open) Icons.Default.ExpandLess else Icons.Default.ExpandMore,if(open)"طي التفاصيل" else "عرض التفاصيل")
        }
        if(open){
            HorizontalDivider()
            Text(r.reasons,Modifier.fillMaxWidth().background(Color(0xFFFFF1EA),RoundedCornerShape(10.dp)).padding(10.dp))
            if(r.kind==kinds.first()){
                Heading("الأستاذ صاحب التقرير")
                Text(r.teacher, fontWeight=FontWeight.Bold)
                Text(arabicConductSubject(r.subject),color=accents[1])
                Text("اقتراح الأستاذ • "+r.proposed.ifBlank { "لم يسجّل اقتراح" })
                Text("الإجراء المتخذ • "+r.decision.ifBlank { "لم يسجّل إجراء بعد" })
                Text(if(r.contacted)"تم الاتصال بولي الأمر" else "لم يتم الاتصال بولي الأمر")
                Text(if(r.withdrawn)"سحب الأستاذ التقرير" else "لم يسحب الأستاذ التقرير")
                TextButton(onClick={edit=true}) { Text("تحيين متابعة المخالفة") }
            } else {
                Text(if(r.relation.isEmpty()) "لم يحضر ولي الأمر" else "حضر ولي الأمر • "+listOf(r.relation,r.guardian,r.phone,r.identity).filter { it.isNotBlank() }.joinToString(" • "))
            }
        }
    }
    if(edit) FollowUp(dao,r){edit=false}
}

@Composable
internal fun PersonalConduct(dao:SchoolDao,year:String,massar:String) {
    val records by remember(dao,year,massar){dao.conduct(year,massar)}.collectAsState(emptyList())
    var selected by rememberSaveable(massar){mutableStateOf("")}
    Panel {
        Heading("المواظبة والسلوك")
        kinds.forEach { kind ->
            Row(Modifier.fillMaxWidth().clickable { selected=if(selected==kind) "" else kind }.padding(vertical=5.dp)) {
                Text(kind,Modifier.weight(1f)); Text(records.count { it.kind==kind }.toString()); Icon(Icons.Default.ExpandMore,null)
            }
            if(selected==kind) {
                val group=records.filter { it.kind==kind }
                if(group.isEmpty()) Text("لا توجد سجلات")
                group.forEach { key(it.id){ConductCard(dao,it)} }
            }
        }
    }
}

@Composable
internal fun ConductStatistics(dao:SchoolDao,year:String) {
    val records by remember(year){dao.conduct(year)}.collectAsState(emptyList())
    val slips by remember(year){dao.slipRows(year,"","")}.collectAsState(emptyList())
    val today=LocalDate.now()
    val month=slips.filter {
        val day=slipDay(it.date)
        it.reason=="غياب" && day?.year==today.year && day.month==today.month
    }
    Panel {
        Heading("المواظبة والسلوك • "+year)
        val incidents=records.filter { it.kind==kinds.first() }
        val metrics=listOf("المتغيبون اليوم" to month.filter { slipDay(it.date)==today }.distinctBy { it.massar }.size,"حالات الغياب هذا الشهر" to month.size,"المخالفات" to incidents.size,"قيد المعالجة" to incidents.count { !it.closed },"تمت تسويتها" to incidents.count { it.closed }) + kinds.drop(1).map { label -> label to records.count { it.kind==label } }
        metrics.chunked(2).forEach { pair -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { pair.forEach { (label,value) -> Box(Modifier.weight(1f).background(Color(0xFFF0F5F7),RoundedCornerShape(12.dp))) { SummaryCard(label,value.toString(),Modifier.fillMaxWidth()) } }; if(pair.size==1) Spacer(Modifier.weight(1f)) } }

    }
}


@Composable
private fun CheckLine(title:String,value:Boolean,change:(Boolean)->Unit) {
    Row(Modifier.fillMaxWidth().clickable { change(!value) }.heightIn(min=44.dp),verticalAlignment=Alignment.CenterVertically) {
        Checkbox(value,null);Spacer(Modifier.width(8.dp));Text(title)
    }
}

@Composable
private fun Field(title:String,value:String,change:(String)->Unit) {
    OutlinedTextField(value,change,Modifier.fillMaxWidth(),label={Text(title)},shape=RoundedCornerShape(14.dp))
}

@Composable
private fun MeasuresField(value:String,deciding:Boolean,change:(String)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    val none="لم يُتخذ أي إجراء"
    val selected=value.lines().filter { it.isNotBlank() }
    OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()) {
        Text(if(selected.isEmpty()) (if(deciding) "اختيار الإجراء" else "اختيار المقترحات") else selected.joinToString("، "))
    }
    if(expanded) AlertDialog(onDismissRequest={expanded=false},title={Heading(if(deciding)"الإجراءات المتخذة" else "مقترحات الأستاذ")},text={
        Column(Modifier.verticalScroll(rememberScrollState())) {
            (if(deciding) measures+none else measures).forEach { item ->
                CheckLine(item,item in selected){checked ->
                    val next=when {
                        !checked -> selected-item
                        item==none -> listOf(none)
                        else -> (selected-none)+item
                    }
                    change(next.joinToString("\n"))
                }
            }
        }
    },confirmButton={TextButton(onClick={expanded=false}){Text("تم")}})
}

@Composable
private fun FollowUp(dao:SchoolDao,r:ConductRecord,close:()->Unit) {
    var decision by rememberSaveable { mutableStateOf(r.decision) }
    var contacted by rememberSaveable { mutableStateOf(r.contacted) }
    var withdrawn by rememberSaveable { mutableStateOf(r.withdrawn) }
    var closed by rememberSaveable { mutableStateOf(r.closed) }
    var busy by remember {mutableStateOf(false)}
    var error by remember {mutableStateOf("")}
    val scope=rememberCoroutineScope()
    AlertDialog(onDismissRequest={if(!busy) close()},title={Heading("متابعة المخالفة")},text={
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(r.studentName+" • "+r.date)
            Text("اقتراح الأستاذ • "+r.proposed.ifBlank { "غير مسجّل" })
            Heading("الإجراء المتخذ")
            MeasuresField(decision,true){decision=it}
            CheckLine("تم الاتصال بولي الأمر",contacted){contacted=it}
            CheckLine("سحب الأستاذ التقرير",withdrawn){withdrawn=it}
            CheckLine("تمت التسوية",closed){closed=it}
            if(error.isNotEmpty())Text(error)
        }
    },confirmButton={Button(enabled=!busy,onClick={
        busy=true
        scope.launch { runCatching { dao.saveConduct(r.copy(decision=decision,contacted=contacted,withdrawn=withdrawn,closed=closed)) }
            .onSuccess { close() }.onFailure { busy=false;error="تعذّر حفظ المتابعة" } }
    }){Text("حفظ المتابعة")}},dismissButton={TextButton(enabled=!busy,onClick=close){Text("رجوع")}})
}

private fun StudentListRow.displayName()=givenName+" "+surname
private fun EmployeeEntity.displayName()=nameArabic.ifBlank { nameFrench }
private fun EmployeeEntity.subject()=disciplineLabelArabic.orEmpty().ifBlank { disciplineLabelFrench.orEmpty() }

@Composable
private fun ConductForm(dao:SchoolDao,year:String,kind:String,done:()->Unit) {
    val incident=kind==kinds.first()
    val scope=rememberCoroutineScope()
    val context=LocalContext.current
    val students by produceState(emptyList<StudentListRow>(),year){value=dao.studentsForYear(year)}
    var query by rememberSaveable {mutableStateOf("")}
    var massar by rememberSaveable {mutableStateOf("")}
    val student=students.firstOrNull { it.massarCode==massar }
    var teacherQuery by rememberSaveable {mutableStateOf("")}
    var ppr by rememberSaveable {mutableStateOf("")}
    val staff by produceState(emptyList<TeacherAssignmentEntity>(),year,student?.className){value=if(incident && student!=null) dao.assignmentsForClass(year,student.className).distinctBy { it.teacherCode to it.subjectName } else emptyList()}
    val teacher=staff.firstOrNull { it.teacherCode+"|"+it.subjectName==ppr }
    var date by rememberSaveable {mutableStateOf(LocalDate.now().toString())}
    var time by rememberSaveable {mutableStateOf(LocalTime.now().format(clock))}
    var selected by rememberSaveable {mutableStateOf(arrayListOf<String>())}
    var other by rememberSaveable {mutableStateOf("")}
    var proposed by rememberSaveable {mutableStateOf("")}
    var decision by rememberSaveable {mutableStateOf("")}
    var contacted by rememberSaveable {mutableStateOf(false)}
    var withdrawn by rememberSaveable {mutableStateOf(false)}
    var closed by rememberSaveable {mutableStateOf(false)}
    var present by rememberSaveable {mutableStateOf(false)}
    var relation by rememberSaveable {mutableStateOf("")}
    var guardian by rememberSaveable {mutableStateOf("")}
    var identity by rememberSaveable {mutableStateOf("")}
    var phone by rememberSaveable {mutableStateOf("")}
    var loadedParent by rememberSaveable {mutableStateOf("")}
    val parentKey=listOf(massar,present.toString(),relation).joinToString("|")
    val ready=loadedParent==parentKey
    LaunchedEffect(massar,present,relation) {
        if(ready) return@LaunchedEffect
        guardian="";identity="";phone=""
        if(present && relation in listOf("الأب","الأم") && massar.isNotEmpty()) {
            val parent=dao.family(year,massar).firstOrNull { it.role==relation }
            guardian=parent?.name.orEmpty();phone=parent?.phone.orEmpty()
            identity=dao.setting("family.id."+year+"."+massar+"."+relation).orEmpty()
        }
        loadedParent=parentKey
    }
    var busy by remember {mutableStateOf(false)}
    var error by remember {mutableStateOf("")}
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Panel {
            Heading("التلميذ المعني")
            if(student==null) {
                SearchBox(query,{query=it},"الاسم أو رمز مسار أو الرقم الترتيبي")
                if(query.isNotBlank()) {
                    val results=students.filter { matches(query,it.displayName(),it.massarCode) || it.ordinal?.toString()==query.trim() }
                    results.take(20).forEach { s -> TextButton(onClick={massar=s.massarCode}){
                        Text(s.displayName()+" • "+s.className+" • "+s.massarCode)
                    } }
                    if(results.isEmpty()) Text("لا توجد نتائج")
                    if(results.size>20) Text("أضف أحرفاً لتضييق البحث")
                }
            } else TextButton(onClick={massar="";query=""}) {Text(student.displayName()+" • "+student.className+"   ✎")}
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                DayPicker(date){date=it}
                OutlinedButton(onClick={
                    val t=LocalTime.parse(time)
                    TimePickerDialog(context,{_,h,m->time=LocalTime.of(h,m).format(clock)},t.hour,t.minute,true).show()
                }) {Text(time)}
            }
        }
        if(incident) Panel {
            Heading("الأستاذ صاحب التقرير")
            if(teacher==null){
                SearchBox(teacherQuery,{teacherQuery=it},"اسم الأستاذ أو المادة أو رقم التأجير")
                val options=staff.filter { matches(teacherQuery,it.teacherName,it.teacherCode,arabicConductSubject(it.subjectName)) }
                options.take(6).forEach { t -> TextButton(onClick={ppr=t.teacherCode+"|"+t.subjectName}) {Text(t.teacherName+" • "+arabicConductSubject(t.subjectName))} }
                if(staff.isEmpty())Text("لا يوجد توزيع حصص لهذا القسم.")
                else if(options.size>6) Text("اكتب لتضييق لائحة الأساتذة")
            } else {
                TextButton(onClick={ppr="";teacherQuery=""}){Text(teacher.teacherName+"   ✎")}
                Text("المادة • "+arabicConductSubject(teacher.subjectName))
            }
        }
        Panel {
            Heading(when(kind){kinds[0]->"محتوى المخالفة";kinds[1]->"السلوك موضوع الالتزام";else->"سبب الغياب"})
            val options=when(kind){kinds[0]->incidents;kinds[1]->behaviors;else->emptyList()}
            options.forEach { option -> CheckLine(option,option in selected){on->
                selected=ArrayList(if(on) selected+option else selected-option)
            } }
            Field(if(options.isEmpty())"سبب الغياب" else "إضافة اختيار آخر",other){other=it}
        }
        if(incident) Panel {
            Heading("الإجراءات المقترحة من طرف الأستاذ")
            MeasuresField(proposed,false){proposed=it}
            Heading("الإجراء المتخذ في حق التلميذ")
            MeasuresField(decision,true){decision=it}
            CheckLine("تم الاتصال بولي الأمر",contacted){contacted=it}
            CheckLine("سحب الأستاذ التقرير",withdrawn){withdrawn=it}
            CheckLine("تمت التسوية",closed){closed=it}
        } else Panel {
            CheckLine("حضر ولي الأمر",present){present=it}
            if(present){
                RosterFilter("صفة ولي الأمر",relation,listOf("الأب","الأم","الأخ","الأخت","العم","أخرى"),Modifier.fillMaxWidth()){relation=it}
                if(ready){
                    Field("الاسم الكامل",guardian){guardian=it}
                    Field("رقم الهاتف",phone){phone=it}
                    Field("رقم البطاقة الوطنية",identity){identity=it}
                }
            }
        }
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        val reasons=(selected+other.trim()).filter { it.isNotBlank() }.joinToString("، ")
        Button(modifier=Modifier.fillMaxWidth().heightIn(min=48.dp),enabled=!busy && ready && student!=null && reasons.isNotBlank() &&
            (!incident || teacher!=null) && (!present || (relation.isNotEmpty() && guardian.isNotBlank())),onClick={
            val s=student ?: return@Button
            val record=ConductRecord(id=UUID.randomUUID().toString(),year=year,kind=kind,massar=s.massarCode,studentName=s.displayName(),
                section=s.className,level=s.levelName,date=date,time=time,teacher=teacher?.teacherName.orEmpty(),subject=teacher?.subjectName?.let(::arabicConductSubject).orEmpty(),
                ppr=teacher?.teacherCode.orEmpty(),reasons=reasons,proposed=proposed,decision=decision,relation=if(present)relation else "",guardian=if(present)guardian.trim() else "",
                phone=if(present)phone.trim() else "",identity=if(present)identity.trim() else "",closed=closed,contacted=contacted,withdrawn=withdrawn)
            busy=true
            scope.launch { runCatching { dao.recordConduct(record) }.onSuccess { done() }.onFailure { busy=false;error="تعذّر حفظ السجل، أعد المحاولة" } }
        }) {Text(if(incident)"حفظ المخالفة" else "حفظ الالتزام")}
        Spacer(Modifier.height(12.dp))
    }
}


private fun arabicConductSubject(value:String):String {
    val k=java.text.Normalizer.normalize(value.uppercase(Locale.ROOT),java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}"),"")
    return when { k.contains("ISLAM") -> "التربية الإسلامية"; k.contains("MATH") -> "الرياضيات"; k.contains("PHYS") && !k.contains("EDUC") -> "الفيزياء والكيمياء"; k.contains("SPORT") || k.contains("EDUCATION PHYS") || k=="EPS" -> "التربية البدنية"; k.contains("ARABE") -> "اللغة العربية"; k.contains("FRAN") -> "اللغة الفرنسية"; k.contains("ANGL") -> "اللغة الإنجليزية"; k.contains("PHILO") -> "الفلسفة"; k.contains("HIST") || k.contains("GEO") -> "التاريخ والجغرافيا"; k.contains("SVT") || k.contains("VIE") -> "علوم الحياة والأرض"; k.contains("INFO") -> "المعلوميات"; k.contains("AMAZ") -> "اللغة الأمازيغية"; k.contains("ECON") -> "الاقتصاد"; else -> value }
}
