package ma.salah.eddine.schoolmanager

import android.content.Context
import ma.salah.eddine.schoolmanager.data.SchoolDatabase
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Offline backup of the full Room database, including all school settings and records. */
internal object SchoolBackup {
    private const val DB = "salah_eddine_school.db"
    private const val ENTRY = "database/$DB"
    private const val PENDING = "pending-school-restore.db"

    fun export(context: Context, output: java.io.OutputStream) {
        val db = SchoolDatabase.get(context).openHelper.writableDatabase
        db.query("PRAGMA wal_checkpoint(FULL)").use { while (it.moveToNext()) {} }
        val file = context.getDatabasePath(DB)
        require(file.isFile) { "قاعدة البيانات غير موجودة" }
        ZipOutputStream(output).use { zip ->
            zip.putNextEntry(ZipEntry("backup-version.txt"))
            zip.write("MOASASATI_BACKUP_V1\n".toByteArray())
            zip.closeEntry()
            zip.putNextEntry(ZipEntry(ENTRY))
            file.inputStream().use { it.copyTo(zip) }
            zip.closeEntry()
        }
    }

    /** Stage a verified backup for restoration before the next Room initialization. */
    fun stageRestore(context: Context, input: java.io.InputStream) {
        val staged = File(context.filesDir, "$PENDING.tmp")
        var marker = false
        var found = false
        try {
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    when (entry.name) {
                        "backup-version.txt" -> marker = zip.readBytes().decodeToString().trim() == "MOASASATI_BACKUP_V1"
                        ENTRY -> {
                            staged.outputStream().use { out ->
                                val buffer = ByteArray(8192)
                                var size = 0L
                                while (true) {
                                    val n = zip.read(buffer)
                                    if (n < 0) break
                                    size += n
                                    require(size <= 200L * 1024 * 1024) { "الملف كبير جدًا" }
                                    out.write(buffer, 0, n)
                                }
                            }
                            found = true
                        }
                    }
                    zip.closeEntry()
                }
            }
            require(marker && found) { "هذا الملف ليس نسخة احتياطية صالحة لمؤسستي" }
            val header = ByteArray(16)
            staged.inputStream().use { require(it.read(header) == 16) }
            require(String(header, Charsets.US_ASCII) == "SQLite format 3\u0000") { "قاعدة البيانات غير صالحة" }
            val renamed = staged.renameTo(File(context.filesDir, PENDING))
            require(renamed) { "تعذر تجهيز الاستعادة" }
        } finally { staged.delete() }
    }

    /** Must run on a fresh process before SchoolDatabase.get(). */
    fun applyPending(context: Context) {
        val pending = File(context.filesDir, PENDING)
        if (!pending.exists()) return
        val target = context.getDatabasePath(DB)
        target.parentFile?.mkdirs()
        // Preserve the previous database if anything goes wrong during restoration.
        val previous = File(context.filesDir, "pre-restore-school.db")
        if (target.exists()) target.copyTo(previous, overwrite = true)
        try {
            pending.copyTo(target, overwrite = true)
            File(target.path + "-wal").delete()
            File(target.path + "-shm").delete()
            pending.delete()
        } catch (e: Exception) {
            if (previous.exists()) previous.copyTo(target, overwrite = true)
            throw e
        }
    }
}
