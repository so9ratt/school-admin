package ma.salah.eddine.schoolmanager

import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Checkbox
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.res.painterResource
import androidx.activity.compose.BackHandler
import ma.salah.eddine.schoolmanager.importing.FamilyBatch
import ma.salah.eddine.schoolmanager.importing.FamilyReview
import ma.salah.eddine.schoolmanager.importing.FamilyFile
import ma.salah.eddine.schoolmanager.data.FamilyContact
import ma.salah.eddine.schoolmanager.data.SchoolDao
import android.os.Bundle
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.AppSettingEntity
import ma.salah.eddine.schoolmanager.data.ClassSummary
import ma.salah.eddine.schoolmanager.data.DashboardCounts
import ma.salah.eddine.schoolmanager.data.EmployeeEntity
import ma.salah.eddine.schoolmanager.data.EmployeeServiceEntity
import ma.salah.eddine.schoolmanager.data.StudentListRow
import ma.salah.eddine.schoolmanager.data.TeacherAssignmentEntity
import ma.salah.eddine.schoolmanager.data.SchoolDatabase
import ma.salah.eddine.schoolmanager.importing.EmployeeImportDiff
import ma.salah.eddine.schoolmanager.importing.EmployeeImportPlan
import ma.salah.eddine.schoolmanager.importing.EmployeeXmlParser
import ma.salah.eddine.schoolmanager.importing.ImportCoordinator
import ma.salah.eddine.schoolmanager.importing.StudentImportDiff
import ma.salah.eddine.schoolmanager.importing.StudentWorkbookParser
import ma.salah.eddine.schoolmanager.importing.StudentWorkbookPlan
import ma.salah.eddine.schoolmanager.importing.TeacherLoadPlan
import ma.salah.eddine.schoolmanager.importing.TeacherLoadWorkbookParser
import ma.salah.eddine.schoolmanager.importing.TeachingImportDiff

internal val Navy = Color(0xFF093853)
internal val Teal = Color(0xFF167450)
private val Pale = Color(0xFFF3F7F8)
private val Ink = Color(0xFF173447)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SchoolBackup.applyPending(this)
        setContent { SchoolApp() }
    }
}

private data class Module(val title: String, val subtitle: String, val route: String)

private val modules = listOf(
    Module("الإحصائيات", "مؤشرات المؤسسة", "statistics"),
    Module("لائحة التلاميذ", "الأقسام والمواد والأساتذة", "students"),
    Module("حركية التلاميذ", "الوافدون والمغادرون وتتبع الالتحاق", "movements"),
    Module("الأقسام والمستويات", "لوائح الأقسام", "classes"),
    Module("الأساتذة", "الموظفون والخدمات", "staff"),
    Module("توزيع الأقسام على الأساتذة", "توزيع الحصص", "teaching"),
    Module("استعمال الزمن", "الجداول الأسبوعية", "timetable"),
    Module("الغياب", "الغياب والتأخر وسجل التسليم", "slips"),
    Module("الإعدادات", "المؤسسة واستيراد الملفات", "settings")
)

private enum class ImportType { STUDENTS, EMPLOYEES, TEACHING }

private sealed interface ImportReview {
    val fileName: String
    data class Students(val plan: StudentWorkbookPlan, val diff: StudentImportDiff, override val fileName: String) : ImportReview
    data class Employees(val plan: EmployeeImportPlan, val diff: EmployeeImportDiff, override val fileName: String) : ImportReview
    data class Teaching(val plan: TeacherLoadPlan, val diff: TeachingImportDiff, override val fileName: String) : ImportReview
}

@Composable
private fun SchoolApp() {
    val movementState = androidx.compose.runtime.saveable.rememberSaveableStateHolder()
    val context = LocalContext.current
    val dao = remember { SchoolDatabase.get(context).schoolDao() }
    var route by rememberSaveable { mutableStateOf("home") }
    var schoolName by rememberSaveable { mutableStateOf("الثانوية التأهيلية صلاح الدين الأيوبي") }
    var schoolLevel by rememberSaveable { mutableStateOf("الثانوي التأهيلي") }
    var province by rememberSaveable { mutableStateOf("تاوريرت") }
    var academy by rememberSaveable { mutableStateOf("الشرق") }
    var schoolYear by rememberSaveable { mutableStateOf("2026/2027") }
    var counts by remember { mutableStateOf(DashboardCounts(0, 0, 0, 0, 0)) }
    var classSummaries by remember { mutableStateOf(emptyList<ClassSummary>()) }
    var selectedClass by rememberSaveable { mutableStateOf("") }
    var search by rememberSaveable { mutableStateOf("") }
    var studentRows by remember { mutableStateOf(emptyList<StudentListRow>()) }
    var classMembers by remember { mutableStateOf(emptyList<StudentListRow>()) }
    var classAssignments by remember { mutableStateOf(emptyList<TeacherAssignmentEntity>()) }
    var employeeRows by remember { mutableStateOf(emptyList<EmployeeEntity>()) }
    var employeeServiceRows by remember { mutableStateOf(emptyList<EmployeeServiceEntity>()) }
    var assignmentRows by remember { mutableStateOf(emptyList<TeacherAssignmentEntity>()) }
    var refreshKey by remember { mutableStateOf(0) }
    var importType by remember { mutableStateOf(ImportType.STUDENTS) }
    var review by remember { mutableStateOf<ImportReview?>(null) }
    var importError by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val backupExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.use { SchoolBackup.export(context, it) } ?: error("تعذر فتح الملف") } }
                .onSuccess { statusMessage = "تم تصدير النسخة الاحتياطية بنجاح" }
                .onFailure { importError = it.message ?: "فشل التصدير" }
        }
    }
    val backupImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { SchoolBackup.stageRestore(context, it) } ?: error("تعذر فتح الملف") } }
                .onSuccess { statusMessage = "تم تجهيز الاستعادة. أغلق التطبيق تمامًا ثم افتحه مجددًا لاستعادة البيانات." }
                .onFailure { importError = it.message ?: "فشلت الاستعادة" }
        }
    }

    fun displayName(uri: Uri): String {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment ?: "ملف مستورد"
    }

    var familyReview by remember { mutableStateOf<FamilyReview?>(null) }
    var scheduleClass by rememberSaveable { mutableStateOf("") }
    var scheduleReview by rememberSaveable { mutableStateOf(false) }
    var profile by remember { mutableStateOf<StudentListRow?>(null) }
    val familyPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            isLoading = true
            statusMessage = ""
            importError = ""
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        val files = mutableListOf<FamilyFile>()
                        val errors = mutableListOf<String>()
                        for (uri in uris.distinct()) {
                            val name = displayName(uri)
                            runCatching {
                                context.contentResolver.openInputStream(uri)?.use { FamilyBatch.parse(name,it) } ?: error("تعذر فتح الملف")
                            }.onSuccess { files += it }.onFailure { errors += "$name — ${it.message}" }
                        }
                        FamilyBatch.review(dao,files,schoolYear,errors)
                    }
                }.onSuccess { familyReview = it }.onFailure { importError = it.message ?: "تعذرت المعاينة" }
                isLoading = false
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val type = importType
            val fileName = displayName(uri)
            isLoading = true
            importError = ""
            scope.launch {
                val result = runCatching {
                    withContext(Dispatchers.IO) {
                        when (type) {
                            ImportType.STUDENTS -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(StudentWorkbookParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                ImportReview.Students(plan, ImportCoordinator.compareStudents(dao, plan), fileName)
                            }
                            ImportType.EMPLOYEES -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(EmployeeXmlParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                ImportReview.Employees(plan, ImportCoordinator.compareEmployees(dao, plan), fileName)
                            }
                            ImportType.TEACHING -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(TeacherLoadWorkbookParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                ImportReview.Teaching(plan, ImportCoordinator.compareTeaching(dao, plan), fileName)
                            }
                        }
                    }
                }
                result.onSuccess { review = it }.onFailure { importError = it.message ?: "تعذر تحليل الملف." }
                isLoading = false
            }
        }
    }

    fun chooseImport(type: ImportType) {
        importType = type
        importError = ""
        val mimeTypes = when (type) {
            ImportType.STUDENTS, ImportType.TEACHING -> arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            ImportType.EMPLOYEES -> arrayOf("application/xml", "text/xml", "text/*", "application/*")
        }
        picker.launch(mimeTypes)
    }

    fun confirmImport() {
        val chosen = review ?: return
        isLoading = true
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    when (chosen) {
                        is ImportReview.Students -> ImportCoordinator.importStudents(dao, chosen.plan, chosen.fileName, chosen.diff)
                        is ImportReview.Employees -> ImportCoordinator.importEmployees(dao, chosen.plan, chosen.fileName, chosen.diff)
                        is ImportReview.Teaching -> ImportCoordinator.importTeaching(dao, chosen.plan, chosen.fileName, chosen.diff)
                    }
                }
            }
            result.onSuccess {
                statusMessage = "تم اعتماد البيانات وحفظها على الجهاز."
                review = null
                refreshKey++
            }.onFailure { importError = it.message ?: "تعذر حفظ البيانات." }
            isLoading = false
        }
    }

    LaunchedEffect(refreshKey) {
        val saved = withContext(Dispatchers.IO) {
            listOf("schoolName", "province", "academy", "schoolYear", "schoolLevel").map { dao.setting(it) }
        }
        saved[0]?.let { schoolName = it }
        saved[1]?.let { province = it }
        saved[2]?.let { academy = it }
        saved[3]?.let { schoolYear = it }
        saved[4]?.let { schoolLevel = it }
        withContext(Dispatchers.IO) {
            dao.saveSetting(AppSettingEntity("schoolName", schoolName))
            dao.saveSetting(AppSettingEntity("province", province))
            dao.saveSetting(AppSettingEntity("academy", academy))
            dao.saveSetting(AppSettingEntity("schoolYear", schoolYear))
            dao.saveSetting(AppSettingEntity("schoolLevel", schoolLevel))
        }
    }

    LaunchedEffect(schoolYear, route, selectedClass, search, refreshKey) {
        val loaded = withContext(Dispatchers.IO) {
            val dashboard = dao.dashboardCounts(schoolYear)
            val classes = dao.classSummaries(schoolYear)
            val members = if (selectedClass.isNotBlank()) dao.studentsInClass(schoolYear, selectedClass) else emptyList()
            val aliases = dao.scheduleLabels().associate { it.key to it.value }
            fun named(rows: List<TeacherAssignmentEntity>) = rows.map { row -> aliases["fet.label.الأستاذ."+row.teacherCode.filterNot(Char::isWhitespace).uppercase()]?.let { row.copy(teacherName=it) } ?: row }
            val classLoad = if (selectedClass.isNotBlank()) dao.assignmentsForClass(schoolYear, selectedClass) else emptyList()
            val students = if (route == "students" || route == "profiles") dao.studentsForYear(schoolYear, search.trim().map { it.digitToIntOrNull()?.digitToChar() ?: it }.joinToString("")) else emptyList()
            val employees = if (route in setOf("teaching","staff")) dao.allEmployees() else emptyList()
            val statsEmployees = if (route in setOf("statistics","institution")) dao.allEmployees() else emptyList()
            val services = if (route == "statistics") dao.allEmployeeServices() else emptyList()
            val assignments = if (route in setOf("teaching","institution")) dao.assignments(schoolYear) else emptyList()
            val statsStudents = if (route in setOf("statistics","institution")) dao.studentsForYear(schoolYear) else students
            ScreenData(dashboard, classes, members, named(classLoad), students, employees, named(assignments), statsStudents, statsEmployees, services)
        }
        counts = loaded.counts
        classSummaries = loaded.classes
        classMembers = loaded.members
        classAssignments = loaded.classAssignments
        if (route == "students" || route == "profiles") studentRows = loaded.students
        if (route in setOf("teaching","staff")) employeeRows = loaded.employees
        if (route in setOf("teaching","institution")) assignmentRows = loaded.assignments
        if (route in setOf("statistics","institution")) {
            studentRows = loaded.statsStudents
            employeeRows = loaded.statsEmployees
            employeeServiceRows = loaded.services
        }
    }

    var intro by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) { if(intro) { kotlinx.coroutines.delay(3000); intro=false } }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            shapes = androidx.compose.material3.Shapes(extraSmall=RoundedCornerShape(14.dp),small=RoundedCornerShape(16.dp),medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(22.dp)),
            colorScheme = lightColorScheme(
                primary = Navy,
                secondary = Teal,
                background = Pale,
                surface = Color.White,
                primaryContainer = Color(0xFFDCEFF4),
                secondaryContainer = Color(0xFFE4F4E9),
                surfaceVariant = Color(0xFFEAF2F5),
                onSurfaceVariant = Navy,
                onPrimary = Color.White,
                onBackground = Ink,
                onSurface = Ink
            )
        ) {
            Surface(modifier = Modifier.fillMaxSize(), color = Pale) {
                val transition = remember { androidx.compose.animation.core.Animatable(1f) }
                LaunchedEffect(route,profile?.massarCode,intro) {
                    transition.snapTo(0.35f)
                    transition.animateTo(1f,androidx.compose.animation.core.tween(180))
                }
                Column(modifier = Modifier.fillMaxSize().safeDrawingPadding().then(Modifier.graphicsLayer { alpha=transition.value })) {
                    if(intro) {
                        Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
                            Image(painterResource(R.drawable.moasasati_foreground),"شعار مؤسستي",Modifier.size(130.dp))
                            Text("مؤسستي",fontSize=28.sp,fontWeight=FontWeight.Bold,color=Navy)
                            androidx.compose.material3.LinearProgressIndicator(Modifier.width(144.dp).padding(top=14.dp))
                        }
                    } else {
                    if (route != "home") Header(schoolName)
                    BackHandler(enabled=route!="home"){ if(profile!=null) profile=null else route="home" }
                    val student = profile
                    if (student != null) {
                        val family by remember(student,schoolYear){dao.watchFamily(schoolYear,student.massarCode)}.collectAsState(initial=emptyList())
                        BackHandler { profile = null }
                        FamilyProfile(dao, schoolYear, student, family, onSchedule = { scheduleClass=student.className; scheduleReview=false; profile=null; route="timetable" }) { profile = null }
                    } else when (route) {
                        "home" -> HomeScreen(counts, schoolYear, schoolName, province, academy, modules) { scheduleClass = ""; scheduleReview = false; selectedClass = ""; search = ""; route = it }
                        "students", "profiles" -> StudentsScreen(dao,schoolYear,route == "profiles", studentRows, classSummaries, selectedClass, classMembers, classAssignments, { selectedClass = it }, search, onSearch = { search = it }, onStudent = { profile = it }, onBack = { route = "home" })
                        "classes" -> ClassesScreen(classSummaries, selectedClass, classMembers, classAssignments,
                            onSelect = { selectedClass = it }, onStudent = { profile = it }, onBack = { if (selectedClass.isNotBlank()) selectedClass = "" else route = "home" })
                        "staff" -> StaffScreen(employeeRows) { route = "home" }
                        "movements" -> movementState.SaveableStateProvider(schoolYear) { MovementScreen(dao,schoolYear,onStudent={profile=it}) { route="home" } }
                        "slips" -> SlipsScreen(dao,schoolYear,classSummaries.map { it.className }) { route="home" }
                        "teaching" -> TeachingScreen(assignmentRows,employeeRows,{code,name ->
                            scope.launch { dao.saveSetting(AppSettingEntity("fet.label.الأستاذ."+code.filterNot(Char::isWhitespace).uppercase(),name));refreshKey++ }
                        }) { route = "home" }
                        "institution" -> InstitutionDashboard(schoolName,schoolLevel,province,schoolYear,counts,studentRows,employeeRows,assignmentRows) { route="statistics" }
                        "statistics" -> StatisticsScreen(counts, schoolYear, studentRows, employeeRows, employeeServiceRows, { route = "institution" }) { route = "home" }
                        "health" -> HealthScreen(dao,schoolYear,schoolName,academy,province) { route="home" }
                        "guardianExport" -> GuardianExportScreen(dao,schoolYear,schoolName,academy,province) { route="settings" }
                        "timetable" -> WeekScreen(dao,schoolYear,scheduleClass,scheduleReview) { route = "home" }
                        "settings" -> SettingsScreen(
                            counts = counts,
                            schoolName = schoolName,
                            schoolLevel = schoolLevel,
                            onSchoolLevel = { value -> schoolLevel = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("schoolLevel", value)) } },
                            onSchoolName = { value -> schoolName = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("schoolName", value)) } },
                            province = province,
                            onProvince = { value -> province = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("province", value)) } },
                            academy = academy,
                            onAcademy = { value -> academy = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("academy", value)) } },
                            schoolYear = schoolYear,
                            onSchoolYear = { value -> schoolYear = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("schoolYear", value)) } },
                            onImport = ::chooseImport,
                            onBackupExport = { backupExport.launch("MOASASATI_Backup_${System.currentTimeMillis()}.zip") },
                            onBackupImport = { backupImport.launch(arrayOf("application/zip", "application/octet-stream")) },
                            timetableImport = { MovementImport(dao,schoolYear,::displayName); FetImport(dao,schoolYear) { scheduleClass=""; scheduleReview=true; route="timetable" } },
                            onGuardianExport = { route="guardianExport" },
                            onFamily = { familyPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) },
                            error = importError,
                            status = statusMessage,
                            isLoading = isLoading,
                            onBack = { route = "home" }
                        )
                        else -> HomeScreen(counts, schoolYear, schoolName, province, academy, modules) { scheduleClass = ""; scheduleReview = false; selectedClass = ""; search = ""; route = it }
                    }
                }
            }
            }
            familyReview?.let { batch ->
                AlertDialog(onDismissRequest = { if (!isLoading) familyReview = null },
                    title = { Text("معاينة ملفات أولياء الأمور") },
                    text = {
                        LazyColumn(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            item { Text("سجلات الاتصال الجديدة أو المتغيرة: ${batch.contacts.size}") }
                            items(batch.notes) { Text(it, fontSize = 13.sp) }
                        }
                    },
                    dismissButton = { OutlinedButton(onClick = { familyReview = null }, enabled = !isLoading) { Text("إغلاق") } },
                    confirmButton = { Button(enabled = !isLoading && batch.contacts.isNotEmpty(), onClick = {
                        isLoading = true
                        scope.launch {
                            runCatching { dao.storeFamily(batch.contacts) }.onSuccess {
                                statusMessage = "تم حفظ بيانات الأسرة على الجهاز."
                            }.onFailure { importError = it.message ?: "تعذر حفظ بيانات الأسرة" }
                            familyReview = null
                            isLoading = false
                        }
                    }) { Text("تأكيد حفظ المطابقات") } })
            }
            if (review != null) {
                ImportPreviewDialog(review!!, isLoading, onDismiss = { if (!isLoading) review = null }, onConfirm = ::confirmImport)
            }
        }
    }
}

private data class ScreenData(
    val counts: DashboardCounts,
    val classes: List<ClassSummary>,
    val members: List<StudentListRow>,
    val classAssignments: List<TeacherAssignmentEntity>,
    val students: List<StudentListRow>,
    val employees: List<EmployeeEntity>,
    val assignments: List<TeacherAssignmentEntity>,
    val statsStudents: List<StudentListRow>,
    val statsEmployees: List<EmployeeEntity>,
    val services: List<EmployeeServiceEntity>
)

@Composable
private fun Header(schoolName: String) {
    Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF093853),Color(0xFF11678B))))
        .padding(horizontal=16.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Image(painterResource(R.drawable.moasasati_foreground),"شعار مؤسستي",Modifier.size(42.dp).clip(CircleShape))
        Column(Modifier.weight(1f)) {
            Text("مؤسستي",color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold)
            Text(schoolName,color=Color.White,fontSize=12.sp)
        }
    }
}

@Composable
private fun HomeScreen(counts: DashboardCounts, year: String, schoolName: String, province: String, academy: String, modulesList: List<Module>, open: (String) -> Unit) {
    val tiles = listOf(
        HomeTile("الإحصائيات", "مؤشرات المؤسسة", "statistics", Icons.Default.BarChart, Color(0xFF8738E6)),
        HomeTile("التلاميذ", "لائحة التلاميذ ومعلوماتهم", "students", Icons.Default.Groups, Color(0xFF079AAA)),
        HomeTile("حركية التلاميذ", "لوائح الحركية", "movements", Icons.Default.SwapHoriz, Color(0xFF09AE40)),
        HomeTile("الأقسام", "تدبير الأقسام", "classes", Icons.Default.Layers, Color(0xFF078CE1)),
        HomeTile("الموظفون", "لائحة الموظفين", "staff", Icons.Default.PersonOutline, Color(0xFFE74E88)),
        HomeTile("توزيع الأساتذة", "إسناد المواد", "teaching", Icons.Default.CoPresent, Color(0xFFFF974B)),
        HomeTile("استعمال الزمن", "الجداول الأسبوعية", "timetable", Icons.Default.CalendarMonth, Color(0xFF9B50C2)),
        HomeTile("ورقة الدخول", "الغياب والتأخر", "slips", Icons.Default.EditNote, Color(0xFF225DC4)),
        HomeTile("الإعدادات", "ضبط التطبيق", "settings", Icons.Default.Settings, Color(0xFF5A7194)),
        HomeTile("الصحة المدرسية", "الإعفاء والنقل", "health", Icons.Default.Favorite, Color(0xFF148FA3))
    )
    val homeFont = androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Font(R.font.neo_sans_arabic))
    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize()) {
    val scale = ((maxHeight.value - 58f) / 600f).coerceIn(0.82f, 1.15f)
    Column(Modifier.fillMaxSize().background(Color(0xFFF4F7FC))) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 8.dp), verticalArrangement = Arrangement.spacedBy((5 * scale).dp)) {
            item {
                Column(Modifier.fillMaxWidth().background(Color.White), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.ministry_new), "شعار الوزارة", Modifier.fillMaxWidth(0.92f).height((62 * scale).dp), contentScale = ContentScale.Fit)
                    Text(if (academy.contains("الأكاديمية")) academy else "الأكاديمية الجهوية للتربية والتكوين لجهة $academy",
                        color = Ink, fontFamily = androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Font(R.font.neo_sans_arabic)), fontSize = (11 * scale).sp, lineHeight = (13 * scale).sp, textAlign = TextAlign.Center)
                    Text(if (province.contains("المديرية")) province else "المديرية الإقليمية $province",
                        color = Ink, fontFamily = androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Font(R.font.neo_sans_arabic)), fontSize = (11 * scale).sp, lineHeight = (13 * scale).sp)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        val line = listOf(Color.Transparent, Teal)
                        Spacer(Modifier.weight(1f).height(1.5.dp).background(Brush.horizontalGradient(line)))
                        Box(Modifier.fillMaxWidth(0.73f).padding(horizontal = 6.dp)
                            .shadow(2.dp, RoundedCornerShape(11.dp))
                            .background(Color.White, RoundedCornerShape(11.dp))
                            .border(1.dp, Color(0xFFDDE5EB), RoundedCornerShape(11.dp))
                            .padding(horizontal = 5.dp, vertical = 3.dp), contentAlignment = Alignment.Center) {
                            Text(schoolName, color = Navy, fontFamily = homeFont, fontSize = (15 * scale).sp, lineHeight = (18 * scale).sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                        }
                        Spacer(Modifier.weight(1f).height(1.5.dp).background(Brush.horizontalGradient(line.reversed())))
                    }
                    Image(painterResource(R.drawable.home_identity), "مؤسستي — MOASASATI",
                        Modifier.fillMaxWidth().height((94 * scale).dp), contentScale = ContentScale.FillBounds)
                }
                Box(Modifier.fillMaxWidth()) {
                    Image(painterResource(R.drawable.home_wave_edge), null,
                        Modifier.fillMaxWidth().height((49 * scale).dp), contentScale = ContentScale.FillBounds)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HomeStat("الموظفون", counts.employeeCount, Icons.Default.PersonOutline, Color(0xFFFF8D23), Color(0xFFFFF6EA), Modifier.weight(1f), scale)
                        HomeStat("الأقسام", counts.classCount, Icons.Default.Layers, Color(0xFF08AC77), Color(0xFFE7F9F5), Modifier.weight(1f), scale)
                        HomeStat("التلميذات والتلاميذ", counts.studentCount, Icons.Default.Groups, Color(0xFF11678B), Color(0xFFEEF1FF), Modifier.weight(1f), scale)
                    }
                }
            }
            items(tiles.chunked(2)) { pair ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    pair.forEach { tile ->
                        Card(onClick = { open(tile.route) }, modifier = Modifier.weight(1f).heightIn(min = (49 * scale).dp), shape = RoundedCornerShape(15.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
                            Row(Modifier.fillMaxWidth().heightIn(min = (49 * scale).dp).padding(horizontal = 7.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size((32 * scale).dp).background(Brush.verticalGradient(listOf(tile.color.copy(alpha = 0.77f), tile.color)), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                                    Icon(tile.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size((24 * scale).dp))
                                }
                                Spacer(Modifier.width(7.dp))
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(tile.title, color = Navy, fontWeight = FontWeight.ExtraBold, fontFamily = homeFont, fontSize = (13 * scale).sp, lineHeight = (15 * scale).sp, textAlign = TextAlign.Center, maxLines = 2)
                                    Text(tile.subtitle, color = Color(0xFF303846), fontFamily = homeFont, fontSize = (9 * scale).sp, lineHeight = (11 * scale).sp, textAlign = TextAlign.Center, maxLines = 2)
                                }
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFF093853)).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf(Triple("الرئيسية", "home", Icons.Default.Home), Triple("التلاميذ", "students", Icons.Default.Groups), Triple("الإحصائيات", "statistics", Icons.Default.BarChart), Triple("الإعدادات", "settings", Icons.Default.Settings)).forEach { (label, route, icon) ->
                Column(Modifier.weight(1f).clickable { if(route != "home") open(route) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, contentDescription = label, tint = if(route == "home") Color(0xFFFF9B29) else Color.White, modifier = Modifier.size((24 * scale).dp))
                    Text(label, color = if(route == "home") Color(0xFFFF9B29) else Color.White, fontSize = 11.sp, fontWeight = if(route == "home") FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}
}

private data class HomeTile(val title: String, val subtitle: String, val route: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val color: Color)

@Composable
private fun HomeStat(label: String, count: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, background: Color, modifier: Modifier, scale: Float = 1f) {
    Card(modifier = modifier.heightIn(min = (72 * scale).dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = background), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Column(Modifier.fillMaxWidth().heightIn(min = (72 * scale).dp).padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size((25 * scale).dp).background(accent, CircleShape).padding(5.dp))
            Text(count.toString(), fontSize = (23 * scale).sp, color = Color(0xFF0C2547), fontWeight = FontWeight.Black)
            Text(label, fontSize = 10.sp, color = Color(0xFF111D30), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}

@Composable
internal fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier.heightIn(min = 60.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 22.sp, color = Teal, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 11.sp, color = Color(0xFF627484), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun StudentsScreen(dao:SchoolDao,year:String,profileSearch: Boolean, rows: List<StudentListRow>, classes: List<ClassSummary>, section: String, members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>, onSection: (String) -> Unit, query: String, onSearch: (String) -> Unit, onStudent: (StudentListRow) -> Unit, onBack: () -> Unit) {
    var level by rememberSaveable { mutableStateOf("") }
    val movements by remember(year){dao.movements(year)}.collectAsState(initial=emptyList())
    val byCode=remember(movements){movements.groupBy {it.massar}}
    val additional=if(query.isBlank()) emptyList() else byCode.values.mapNotNull { events ->
        val m=events.first()
        val q=query.trim()
        if(m.massar.contains(q,true) || m.fullName.contains(q,true) || m.ordinal?.toString()==q)
            StudentListRow(m.massar,"",m.fullName,"","",null,m.level,m.section,m.ordinal)
        else null
    }
    val sections = classes.filter { level.isEmpty() || it.levelName == level }.map { it.className }.distinct().sorted()
    val visible = (rows+additional).distinctBy { it.massarCode }.filter { (level.isEmpty() || it.levelName == level) && (section.isEmpty() || it.className == section) }

    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle(if (profileSearch) "بطاقة التلميذ" else "لائحة التلاميذ", onBack)
        val total=classes.sumOf { it.studentCount }
        Text("إجمالي التلاميذ: $total"+if(query.isNotBlank() || section.isNotBlank() || level.isNotBlank()) "    •    نتائج البحث: ${visible.size}" else "",
            style=MaterialTheme.typography.labelLarge,color=Navy)
        SearchBox(query,onSearch,"الاسم أو رمز مسار أو الرقم الترتيبي")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RosterFilter("حسب المستوى", level, classes.map { it.levelName }.filter { it.isNotBlank() }.distinct().sorted(), Modifier.weight(1f)) {
                level = it
                onSection("")
            }
            RosterFilter("حسب القسم", section, sections, Modifier.weight(1f)) { onSection(it) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (!profileSearch && section.isNotBlank()) {
                item { ClassOverview(members.filter { it.className == section }, assignments.filter { it.className == section }) }
            }
            if (visible.isEmpty()) item { EmptyCard("لا يوجد تلاميذ ضمن هذا الاختيار.") }
            items(visible, key = { it.massarCode }) { student ->
                StudentResult(student,byCode[student.massarCode].orEmpty().map { when(it.kind){
                    "ARRIVAL" -> "وافد"
                    "DEPARTURE" -> "مغادر"
                    "DROPOUT" -> "منقطع"
                    else -> "غير ملتحق"
                } }.distinct().joinToString(" • ")) { onStudent(student) }
            }
        }
    }

}

@Composable
private fun ClassesScreen(classes: List<ClassSummary>, selected: String, members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>, onSelect: (String) -> Unit, onStudent: (StudentListRow) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle(if (selected.isBlank()) "الأقسام والمستويات" else selected, onBack)
        if (selected.isNotBlank()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item { ClassOverview(members.filter { it.className == selected }, assignments.filter { it.className == selected }) }
                item { Text("لائحة التلاميذ", color = Navy, fontWeight = FontWeight.Bold) }
                items(members, key = { it.massarCode }) { student ->
                    StudentResult(student) { onStudent(student) }
                }
            }
        } else if (classes.isEmpty()) {
            EmptyCard("ستظهر الأقسام تلقائياً بعد استيراد ملف التلاميذ.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("الأقسام: "+classes.size+"   •   المستويات: "+classes.distinctBy { it.levelName }.size) }
                classes.groupBy { it.levelName }.forEach { (level, levelClasses) ->
                    item { Text(level, fontWeight = FontWeight.Bold, color = Teal, modifier = Modifier.padding(top = 6.dp)) }
                    items(levelClasses, key = { it.className }) { summary ->
                    Card(Modifier.fillMaxWidth().clickable { onSelect(summary.className) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(summary.className, color = Navy, fontWeight = FontWeight.SemiBold)
                            Text("${summary.studentCount} تلميذاً", color = Color(0xFF627484), fontSize = 12.sp)
                        }
                    }
                    }
                }
            }
        }
    }
}

@Composable
private fun StaffScreen(employees: List<EmployeeEntity>, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf<EmployeeEntity?>(null) }
    chosen?.let { e ->
        BackHandler { chosen = null }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PageTitle("بطاقة الموظف") { chosen = null }
            ProfileHeading(e.nameArabic.ifBlank { e.nameFrench }, e.nameFrench)
            ProfilePhones(listOf("الهاتف المحمول" to e.mobile, "الهاتف الثابت" to e.landline))
            ProfileGrid("الملف المهني", listOf("رقم التأجير" to e.ppr, "المادة" to (e.disciplineLabelArabic ?: e.disciplineLabelFrench),
                "الإطار" to e.cadreLabel, "الدرجة" to e.gradeLabel, "الرتبة" to e.echelon, "الوضعية" to e.statusLabel,
                "الوضع الإداري" to e.positionLabel, "الوظيفة" to e.functionLabel, "تاريخ التوظيف" to e.recruitmentDate,
                "تاريخ الترسيم" to e.titularizationDate, "الجنس" to e.gender))
            ProfileGrid("العنوان", listOf("المدينة" to e.city, "عنوان السكن" to e.address))
            var showId by remember(e.ppr) { mutableStateOf(false) }
            OutlinedButton(onClick={showId=!showId},enabled=!e.nationalId.isNullOrBlank()) {
                Text(if(e.nationalId.isNullOrBlank()) "رقم البطاقة غير متوفر" else if(showId) "إخفاء رقم البطاقة" else "إظهار رقم البطاقة الوطنية")
            }
            if(showId) Text(e.nationalId.orEmpty())
        }
        return
    }
    val filtered = employees.filter {
        query.isBlank() || it.ppr.contains(query, true) || it.nameArabic.contains(query, true) ||
            it.nameFrench.contains(query, true) || it.disciplineLabelArabic.orEmpty().contains(query, true) ||
            it.disciplineLabelFrench.orEmpty().contains(query, true)
    }
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("الأساتذة والموظفون", onBack)
        Text("عدد السجلات: ${employees.size}", color = Teal, fontWeight = FontWeight.SemiBold)
        SearchBox(query,{query=it},"الاسم أو رقم التأجير أو المادة")
        if (employees.isEmpty()) EmptyCard("استورد ملف الموارد البشرية من الإعدادات لعرض الموظفين.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.ppr }) { employee ->
                Card(modifier = Modifier.clickable { chosen = employee }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(employee.nameArabic.ifBlank { employee.nameFrench }, color = Navy, fontWeight = FontWeight.Bold)
                        Text("PPR: ${employee.ppr}", color = Color(0xFF627484), fontSize = 11.sp)
                        val discipline = employee.disciplineLabelArabic ?: employee.disciplineLabelFrench
                        if (!discipline.isNullOrBlank()) Text("المادة/التخصص: $discipline", color = Teal, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun TeachingScreen(assignments: List<TeacherAssignmentEntity>, employees:List<EmployeeEntity>, rename:(String,String)->Unit, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf("") }
    var editing by remember { mutableStateOf<TeacherAssignmentEntity?>(null) }
    var name by rememberSaveable { mutableStateOf("") }
    editing?.let { row ->
        AlertDialog(onDismissRequest={editing=null},title={Text("تسمية الأستاذ")},text={
            Column {
                OutlinedTextField(name,{name=it},label={Text("الاسم المعروض")})
                RosterFilter("اختر من لائحة الأساتذة","",employees.map { it.nameArabic.ifBlank { it.nameFrench } }.filter { it.isNotBlank() }.distinct(),Modifier.fillMaxWidth()){if(it.isNotBlank())name=it}
            }
        },confirmButton={Button(enabled=name.isNotBlank(),onClick={rename(row.teacherCode,name.trim());editing=null}){Text("حفظ")}},
        dismissButton={androidx.compose.material3.TextButton(onClick={editing=null}){Text("إلغاء")}})
    }
    var subject by rememberSaveable { mutableStateOf("") }
    val matches=assignments.filter {
        (section.isEmpty() || it.className==section) && (subject.isEmpty() || it.subjectName==subject) &&
            listOf(it.teacherName,it.subjectName,it.className).any { label -> label.contains(query.trim(),true) }
    }
    Column(Modifier.fillMaxSize().padding(pageInset()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        PageTitle("توزيع الأقسام على الأساتذة",onBack)
        Text("الأساتذة: "+matches.distinctBy { it.teacherCode }.size+"   •   الأقسام: "+matches.distinctBy { it.className }.size)
        SearchBox(query,{query=it},"اسم الأستاذ أو المادة أو القسم")
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            RosterFilter("حسب القسم",section,assignments.filter { subject.isEmpty() || it.subjectName==subject }.map { it.className }.distinct().sorted(),Modifier.weight(1f)){section=it}
            RosterFilter("حسب المادة",subject,assignments.filter { section.isEmpty() || it.className==section }.map { it.subjectName }.distinct().sorted(),Modifier.weight(1f)){subject=it}
        }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            if(matches.isEmpty()) item { EmptyCard("لا توجد إسنادات ضمن هذا الاختيار") }
            items(matches.groupBy { it.teacherCode }.values.sortedBy { it.first().teacherName },key={it.first().teacherCode}) { records ->
                val first=records.first()
                Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal=10.dp),verticalAlignment=Alignment.CenterVertically) {
                        Text(first.teacherName,Modifier.weight(1f),fontWeight=FontWeight.Bold,color=Navy)
                        Text(records.map { it.subjectName }.distinct().joinToString("، "),Modifier.weight(0.8f),color=Teal,fontSize=13.sp)
                        IconButton(onClick={editing=first;name=first.teacherName}) {Icon(Icons.Default.Edit,"تعديل اسم الأستاذ")}
                    }
                    FlowRow(Modifier.padding(start=12.dp,end=12.dp,bottom=10.dp),horizontalArrangement=Arrangement.spacedBy(5.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        records.map { it.className }.distinct().sorted().forEach {
                            Text(it,Modifier.background(Pale,RoundedCornerShape(8.dp)).padding(horizontal=7.dp,vertical=3.dp),fontSize=12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatisticsScreen(
    counts: DashboardCounts,
    year: String,
    students: List<StudentListRow>,
    employees: List<EmployeeEntity>,
    services: List<EmployeeServiceEntity>,
    onInstitution: () -> Unit,
    onBack: () -> Unit
) {
    val girls = students.count { it.gender.isFemaleValue() }
    val boys = students.count { it.gender.isMaleValue() }
    val unknownGender = students.size - girls - boys
    val total = students.size
    val levelCounts = students.groupingBy { it.levelName }.eachCount().toList().sortedByDescending { it.second }
    val classCounts = students.groupingBy { it.className }.eachCount().toList().sortedByDescending { it.second }
    val distinctClasses = students.map { it.className }.distinct().size
    val average = if (distinctClasses == 0) 0.0 else total.toDouble() / distinctClasses
    val linkedEmployeeCodes = services.mapNotNull { it.employeePpr }.distinct().size
    val disciplineCounts = employees.groupingBy { it.disciplineLabelArabic ?: it.disciplineLabelFrench ?: "غير محدد" }.eachCount()
        .toList().sortedByDescending { it.second }
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("الإحصائيات", onBack)
        OutlinedButton(onClick=onInstitution) { Text("معلومات المؤسسة") }
        Text("الموسم الدراسي $year", color = Color(0xFF627484))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { SummaryCard("مجموع التلاميذ", total.toString(), Modifier.fillMaxWidth()) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("التوزيع حسب الجنس", color = Navy, fontWeight = FontWeight.Bold)
                        StatLine("الإناث (${percentage(girls, total)})", girls, total)
                        StatLine("الذكور (${percentage(boys, total)})", boys, total)
                        if (unknownGender > 0) StatLine("غير محدد (${percentage(unknownGender, total)})", unknownGender, total)
                    }
                }
            }
            item { SummaryCard("الأقسام", distinctClasses.toString(), Modifier.fillMaxWidth()) }
            item { SummaryCard("متوسط التلاميذ في القسم", String.format(java.util.Locale.ROOT,"%.1f", average), Modifier.fillMaxWidth()) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("التلاميذ حسب المستوى", color = Navy, fontWeight = FontWeight.Bold)
                        if (levelCounts.isEmpty()) Text("لا توجد بيانات بعد.", color = Color(0xFF627484))
                        levelCounts.forEach { (label, count) -> StatLine(label, count, total) }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("الأقسام الأكثر اكتظاظاً", color = Navy, fontWeight = FontWeight.Bold)
                        if (classCounts.isEmpty()) Text("لا توجد بيانات بعد.", color = Color(0xFF627484))
                        classCounts.forEach { (label, count) -> StatLine(label, count, classCounts.firstOrNull()?.second ?: 1) }
                    }
                }
            }
            item { SummaryCard("موظفون في XML", counts.employeeCount.toString(), Modifier.fillMaxWidth()) }
            item { SummaryCard("موظفون مرتبطون بصفوف خدمات XML", linkedEmployeeCodes.toString(), Modifier.fillMaxWidth()) }
            item { SummaryCard("معرفات أساتذة في مستخرج الحصص", counts.scheduleTeacherCount.toString(), Modifier.fillMaxWidth()) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("الموظفون حسب التخصص", color = Navy, fontWeight = FontWeight.Bold)
                        disciplineCounts.forEach { (label, count) -> StatLine(label, count, counts.employeeCount) }
                    }
                }
            }
        }
    }
}

internal fun String.isFemaleValue(): Boolean = trim().lowercase() in setOf("أنثى", "انثى", "f", "féminin", "feminin", "female")
internal fun String.isMaleValue(): Boolean = trim().lowercase() in setOf("ذكر", "m", "masculin", "male")
private fun percentage(value: Int, total: Int): String = if (total == 0) "0%" else "${(value * 100.0 / total).let { String.format(java.util.Locale.ROOT, "%.1f", it) }}%"

@Composable
private fun StatLine(label: String, value: Int, maxValue: Int) {
    val fraction = if (maxValue <= 0) 0f else (value.toFloat() / maxValue).coerceIn(0f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = Ink, modifier = Modifier.weight(1f))
            Text(value.toString(), fontSize = 12.sp, color = Teal, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0xFFE4EBF0), RoundedCornerShape(8.dp))) {
            Box(Modifier.fillMaxWidth(fraction).height(6.dp).background(Teal, RoundedCornerShape(8.dp)))
        }
    }
}

@Composable
private fun SettingsScreen(
    counts: DashboardCounts,
    schoolName: String,
    schoolLevel: String,
    onSchoolLevel: (String) -> Unit,
    onSchoolName: (String) -> Unit,
    province: String,
    onProvince: (String) -> Unit,
    academy: String,
    onAcademy: (String) -> Unit,
    schoolYear: String,
    onSchoolYear: (String) -> Unit,
    onImport: (ImportType) -> Unit,
    onBackupExport: () -> Unit,
    onBackupImport: () -> Unit,
    timetableImport: @Composable () -> Unit,
    onFamily: () -> Unit,
    onGuardianExport: () -> Unit,
    error: String,
    status: String,
    isLoading: Boolean,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(pageInset()).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("الإعدادات", onBack)
        Text("التلاميذ: ${counts.studentCount}   •   الأقسام: ${counts.classCount}   •   الموظفون: ${counts.employeeCount}")
        OutlinedTextField(value = schoolName, onValueChange = onSchoolName, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المؤسسة") }, singleLine = true)
        Text("السلك التعليمي", fontWeight = FontWeight.Bold, color = Navy)
        listOf("التعليم الابتدائي", "الثانوي الإعدادي", "الثانوي التأهيلي").forEach { level ->
            Row(Modifier.fillMaxWidth().clickable { onSchoolLevel(level) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = schoolLevel == level, onClick = { onSchoolLevel(level) })
                Text(level, color = Navy)
            }
        }
        Text("يمكن تغيير اسم المؤسسة والسلك دون تغيير تصميم الواجهة.", color = Teal, fontSize = 12.sp)
        OutlinedTextField(value = province, onValueChange = onProvince, modifier = Modifier.fillMaxWidth(), label = { Text("المديرية الإقليمية") }, singleLine = true)
        OutlinedTextField(value = academy, onValueChange = onAcademy, modifier = Modifier.fillMaxWidth(), label = { Text("الأكاديمية الجهوية") }, singleLine = true)
        OutlinedTextField(value = schoolYear, onValueChange = onSchoolYear, modifier = Modifier.fillMaxWidth(), label = { Text("الموسم الدراسي") }, singleLine = true)
        Text("النسخ الاحتياطي واستعادة البيانات", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Navy)
        ImportButton("تصدير نسخة احتياطية", "حفظ بيانات المؤسسة كاملة في ملف ZIP واحد", !isLoading, onBackupExport)
        ImportButton("استعادة نسخة احتياطية", "استبدال بيانات التطبيق بملف محفوظ بعد إعادة تشغيله", !isLoading, onBackupImport)
        Text("تنبيه: الاستعادة تستبدل البيانات الحالية. صدّر نسخة احتياطية أولًا، ولا تستعد بيانات مؤسسة أخرى دون التأكد من محتوى الملف.", color = Color(0xFF9C4F14), fontSize = 12.sp)
        ImportButton("تصدير معلومات أولياء الأمور", "PDF وExcel حسب القسم", !isLoading, onGuardianExport)
        Text("استيراد البيانات", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.padding(top = 4.dp))
        ImportButton("لائحة التلاميذ — Excel", "XLSX • الأقسام والبيانات الشخصية الدراسية", !isLoading) { onImport(ImportType.STUDENTS) }
        ImportButton("أولياء الأمور — Excel", "اختيار ملف أو عدة ملفات أقسام دفعة واحدة", !isLoading, onFamily)
        ImportButton("لائحة الموظفين — XML", "XML • بيانات إدارية وجداول مرجعية", !isLoading) { onImport(ImportType.EMPLOYEES) }
        ImportButton("مستخرج حصص الأساتذة — Excel", "XLSX • المادة والقسم وG1 وG2", !isLoading) { onImport(ImportType.TEACHING) }
        timetableImport()
        if (isLoading) Text("جارٍ تحليل الملف…", color = Teal, fontWeight = FontWeight.SemiBold)
        if (error.isNotBlank()) Text(error, color = Color(0xFFB3261E), fontSize = 13.sp)
        if (status.isNotBlank()) Text(status, color = Teal, fontSize = 13.sp)
        Text("تُحفظ البيانات محلياً على الجهاز. لن تُعتمد أي تغييرات قبل مراجعة المعاينة.", color = Color(0xFF627484), fontSize = 12.sp)
    }
}

@Composable
private fun ImportButton(title: String, subtitle: String, enabled: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = Navy, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color(0xFF627484), fontSize = 11.sp)
        }
    }
}

@Composable
private fun ImportPreviewDialog(review: ImportReview, busy: Boolean, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("معاينة الاستيراد", color = Navy, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الملف: ${review.fileName}", color = Color(0xFF627484), fontSize = 12.sp)
                when (review) {
                    is ImportReview.Students -> {
                        Text("الموسم الدراسي: ${review.plan.schoolYear}")
                        Text("الأوراق/الأقسام: ${review.plan.sectionCount}")
                        Text("التلاميذ المقروءون: ${review.plan.students.size}")
                        Text("جدد: ${review.diff.newStudents} • تحديث بيانات: ${review.diff.updatedProfiles}")
                        Text("انتقال بين الأقسام: ${review.diff.sectionTransfers} • دون تغيير: ${review.diff.unchangedStudents}")
                        review.diff.transferDetails.take(8).forEach { transfer ->
                            Text("${transfer.massarCode}: ${transfer.oldClass} ← ${transfer.newClass}", color = Teal, fontSize = 12.sp)
                        }
                        Text("موجودون سابقاً وغير واردين في هذا الملف: ${review.diff.notInNewFile} (لن يُحذفوا)")
                        Text("المؤسسة: ${review.plan.institution.orEmpty()}")
                    }
                    is ImportReview.Employees -> {
                        Text("الموظفون: ${review.plan.employees.size}")
                        Text("جدد: ${review.diff.newEmployees} • تحديثات: ${review.diff.updatedEmployees} • دون تغيير: ${review.diff.unchangedEmployees}")
                        Text("موظفون سابقون غير واردين في هذا الملف: ${review.diff.notInNewFile} (سيبقون محفوظين كبيانات سابقة)")
                        Text("جداول مرجعية: ${review.plan.referenceValues.size} • سجلات الأنشطة: ${review.plan.activityCount}")
                        Text("صفوف الخدمات: ${review.plan.serviceRecordCount} • موظفون مرتبطون بها: ${review.plan.employeesWithServiceRows} • دون صفوف مطابقة: ${review.plan.employeesWithoutServiceRows}")
                        Text("لن تُستورد أرقام الهوية والعناوين وأرقام الاتصال في هذه النسخة.", color = Teal, fontSize = 12.sp)
                    }
                    is ImportReview.Teaching -> {
                        Text("الموسم الدراسي: ${review.plan.schoolYear}")
                        Text("الأقسام: ${review.plan.sectionCount} • أعمدة المجموعات: ${review.plan.subgroupCount}")
                        Text("المواد: ${review.plan.subjectCount} • معرفات الأساتذة: ${review.plan.teacherCount}")
                        Text("إسنادات المادة والقسم/المجموعة: ${review.plan.assignments.size}")
                        Text("مجموع القيم المقروءة: ${review.plan.statedLessonTotal}")
                        Text("جديدة: ${review.diff.newAssignments} • متغيرة: ${review.diff.changedAssignments} • دون تغيير: ${review.diff.unchangedAssignments}")
                        Text("غير واردة في الملف الجديد: ${review.diff.noLongerListed} (ستُحفظ كسجلات غير حالية)")
                    }
                }
                val warnings = when (review) {
                    is ImportReview.Students -> review.plan.warnings
                    is ImportReview.Employees -> review.plan.warnings
                    is ImportReview.Teaching -> review.plan.warnings
                }
                if (warnings.isNotEmpty()) {
                    Text("ملاحظات (${warnings.size})", color = Color(0xFFB26A00), fontWeight = FontWeight.Bold)
                    warnings.take(8).forEach { Text("• $it", fontSize = 12.sp, color = Color(0xFF6B5A3C)) }
                    if (warnings.size > 8) Text("… وهناك ${warnings.size - 8} ملاحظات أخرى.", fontSize = 12.sp)
                }
            }
        },
        confirmButton = { Button(onClick = onConfirm, enabled = !busy) { Text(if (busy) "جارٍ الحفظ…" else "تأكيد الاستيراد") } },
        dismissButton = { OutlinedButton(onClick = onDismiss, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
internal fun PageTitle(title: String, onBack: () -> Unit) {
    val brush=Brush.horizontalGradient(listOf(Color(0xFF093853), Color(0xFF11678B)))
    Box(Modifier.fillMaxWidth().background(brush,RoundedCornerShape(18.dp))) {
        Text(title,Modifier.align(Alignment.Center).padding(horizontal=44.dp,vertical=12.dp),color=Color.White,
            fontWeight=FontWeight.Bold,fontSize=19.sp,textAlign=TextAlign.Center)
        IconButton(onClick=onBack,modifier=Modifier.align(Alignment.CenterEnd)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack,"رجوع",tint=Color.White)
        }
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Text(message, Modifier.fillMaxWidth().padding(18.dp), color = Color(0xFF526777), fontSize = 14.sp, lineHeight = 22.sp)
    }
}

@Composable
internal fun RosterFilter(all: String, selected: String, options: List<String>, modifier: Modifier, select: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected.ifEmpty { all } + " ▾", maxLines = 2)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            (listOf("") + options).forEach { option ->
                DropdownMenuItem(text = { Text(option.ifEmpty { all }) }, onClick = {
                    select(option)
                    expanded = false
                })
            }
        }
    }
}

@Composable
private fun ClassOverview(members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>) {
    val girls = members.count { it.gender.isFemaleValue() }
    val boys = members.count { it.gender.isMaleValue() }
    val unknown = members.size - girls - boys
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            SummaryCard("التلاميذ", members.size.toString(), Modifier.weight(1f))
            SummaryCard("الإناث", girls.toString(), Modifier.weight(1f))
            SummaryCard("الذكور", boys.toString(), Modifier.weight(1f))
        }
        if (unknown > 0) Text("جنس غير محدد: $unknown", fontSize = 12.sp)
        Text("المواد والأساتذة", color = Navy, fontWeight = FontWeight.Bold)
        if (assignments.isEmpty()) Text("لا توجد إسنادات لهذا القسم. يمكن استيراد مستخرج الحصص من الإعدادات.", fontSize = 13.sp)
        androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
            val columns = ((maxWidth.value + 8f) / 158f).toInt().coerceIn(1, 6)
            val subjects = assignments.groupBy { it.subjectName }.toList()
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                subjects.chunked(columns).forEach { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        line.forEach { (subject, lessons) ->
                            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(subject, color = Navy, fontWeight = FontWeight.SemiBold)
                                    lessons.distinctBy { it.teacherCode }.forEach { lesson ->
                                        Text(lesson.teacherName, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                        repeat(columns - line.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun pageInset() = if (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp <= 360) 10.dp else 14.dp

@Composable
private fun FamilyProfile(dao:SchoolDao,year:String,student: StudentListRow, contacts: List<FamilyContact>, onSchedule:()->Unit, back: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pageInset()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PageTitle("بطاقة التلميذ", back)
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StudentAvatar(student.massarCode,editable=true)
            Box(Modifier.weight(1f)){ProfileHeading(student.givenName+" "+student.surname, student.className+"   •   "+student.levelName)}
        }
        val roles = listOf("الأب","الأم")
        val scope=rememberCoroutineScope()
        var roleEdit by rememberSaveable(student.massarCode){mutableStateOf("")}
        var number by rememberSaveable(student.massarCode){mutableStateOf("")}
        var failure by remember { mutableStateOf("") }
        fun editPhone(role:String,initial:String) { roleEdit=role;number=initial;failure="" }
        ProfilePhones(roles.map { role -> "هاتف $role" to contacts.find { it.role==role }?.phone }) { index -> editPhone(roles[index],contacts.find { it.role==roles[index] }?.phone.orEmpty()) }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
            Column { Text("رمز مسار", color=Teal); Text(student.massarCode,fontWeight=FontWeight.Bold) }
            IconButton(onClick={
                val clipboard=context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("مسار",student.massarCode))
                if(android.os.Build.VERSION.SDK_INT<33) android.widget.Toast.makeText(context,"تم نسخ رمز مسار",android.widget.Toast.LENGTH_SHORT).show()
            }) { Icon(Icons.Default.ContentCopy, contentDescription="نسخ رمز مسار", tint=Teal) }
        }
        ProfileGrid("المعلومات الشخصية", listOf("الرقم الترتيبي" to student.ordinal?.toString(),"الجنس" to student.gender,
            "تاريخ الازدياد" to student.birthDate,"مكان الازدياد" to student.birthPlace))
        val history by remember(year,student.massarCode) { dao.studentMovements(year,student.massarCode) }.collectAsState(initial=emptyList())
        if(history.isNotEmpty()) {
            Text("حركية التلميذ",fontWeight=FontWeight.Bold,color=Navy)
            history.forEach { movement ->
                if(movement.kind=="ARRIVAL") {
                    Text("المؤسسة الأصلية: "+movement.origin.ifBlank {"غير متوفر"})
                    Text("تاريخ التحويل حسب لائحة الوافدين: "+movement.eventDate.ifBlank {"غير متوفر"})
                }
                Text(listOf(ma.salah.eddine.schoolmanager.importing.MovementKind.valueOf(movement.kind).label,movement.eventDate,movement.level)
                    .filter(String::isNotBlank).joinToString("  •  "))
            }
        }
        OutlinedButton(onClick=onSchedule) { Text("استعمال زمن القسم") }
        ProfileCells(roles.size) { index ->
            val role=roles[index]
            val contact = contacts.find { it.role == role }
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(role, color = Teal, fontWeight = FontWeight.Bold)
                    Text("اسم $role: ${contact?.name.orEmpty().ifBlank { "غير متوفر" }}")
                    Text("عنوان $role: ${contact?.address.orEmpty().ifBlank { "غير متوفر" }}")
                    val key="family.id.$year.${student.massarCode}.$role"
                    val cin by remember(key){dao.watchSetting(key)}.collectAsState(initial=null)
                    var editingId by remember(key){mutableStateOf(false)}
                    var idDraft by remember(key){mutableStateOf("")}
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("رقم البطاقة: "+cin.orEmpty().ifBlank { "غير متوفر" },Modifier.weight(1f))
                        IconButton(onClick={idDraft=cin.orEmpty();editingId=true}) { Icon(Icons.Default.Edit,"تعديل البطاقة") }
                    }
                    if(editingId) AlertDialog(onDismissRequest={editingId=false},title={Text("رقم البطاقة الوطنية")},text={OutlinedTextField(idDraft,{idDraft=it},singleLine=true)},confirmButton={TextButton(onClick={scope.launch { dao.saveSetting(AppSettingEntity(key,idDraft.trim()));editingId=false }}){Text("حفظ")}},dismissButton={TextButton(onClick={editingId=false}){Text("إلغاء")}})

                }
            }
        }
        val father=contacts.firstOrNull { it.role=="الأب" }
        var suggested by remember(student.massarCode){mutableStateOf(emptyList<String>())}
        LaunchedEffect(year,student.massarCode,father) {
            suggested=if(father!=null && father.name.trim().contains(" ") && father.phone.isBlank())
                dao.familyForYear(year).filter { it.role=="الأب" && it.massar!=student.massarCode && it.name.trim()==father.name.trim() && it.phone.isNotBlank() }.map { it.phone }.distinct()
            else emptyList()
        }
        for(candidate in suggested) {
            Text("اسم الأب مطابق لبطاقة تلميذ آخر. تحقق من صلة القرابة قبل اعتماد الرقم.")
            OutlinedButton(onClick={editPhone("الأب",candidate)}) { Text("مراجعة الرقم $candidate") }
        }
        if(roleEdit.isNotEmpty()) AlertDialog(onDismissRequest={roleEdit=""},title={Text("هاتف $roleEdit")},text={
            Column { OutlinedTextField(number,{number=it},singleLine=true,label={Text("رقم الهاتف")});if(failure.isNotBlank()) Text(failure) }
        },confirmButton={TextButton(onClick={
            val role=roleEdit;val updated=number.trim()
            scope.launch {
                runCatching {
                    val c=dao.family(year,student.massarCode).firstOrNull { it.role==role } ?: FamilyContact(year,student.massarCode,role,"","","")
                    dao.storeFamily(listOf(c.copy(phone=updated)))
                }.onSuccess {roleEdit=""}.onFailure {failure="تعذر حفظ الرقم"}
            }
        }) {Text("حفظ")}},dismissButton={TextButton(onClick={roleEdit=""}){Text("إلغاء")}})
        PersonalSlips(dao,year,student.massarCode)
    }
}

@Composable
private fun ProfilePhones(numbers:List<Pair<String,String?>>, edit: ((Int)->Unit)? = null) {
    val context=LocalContext.current
    ProfileCells(numbers.size) { index ->
        val (label,raw)=numbers[index]
        val number=raw.orEmpty().trim()
        Column(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp))
            .clickable(enabled=number.isNotEmpty(), onClickLabel="فتح لوحة الاتصال") {
                val intent=android.content.Intent(android.content.Intent.ACTION_DIAL,Uri.fromParts("tel",number,null))
                try { context.startActivity(intent) } catch (_:android.content.ActivityNotFoundException) {
                    android.widget.Toast.makeText(context,"تطبيق الاتصال غير متوفر",android.widget.Toast.LENGTH_SHORT).show()
                }
            }.padding(12.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(label,color=Teal,style=MaterialTheme.typography.labelMedium,modifier=Modifier.weight(1f))
                if(edit!=null) IconButton(onClick={edit(index)},modifier=Modifier.size(30.dp)) { Icon(Icons.Default.Edit,"تعديل",modifier=Modifier.size(16.dp),tint=Teal) }
            }
            Text(number.ifBlank { "غير متوفر" },color=Navy,fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
private fun ProfileHeading(name:String, subtitle:String) {
    Column(Modifier.fillMaxWidth().background(Navy,RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text(name,color=Color.White,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        if(subtitle.isNotBlank() && subtitle!=name) Text(subtitle,color=Color.White)
    }
}

@Composable
private fun ProfileCells(count:Int, content:@Composable (Int)->Unit) {
    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
        val columns=if(maxWidth>=310.dp && androidx.compose.ui.platform.LocalDensity.current.fontScale<=1.3f && count>1) 2 else 1
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            for(start in 0 until count step columns) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    repeat(columns) { col ->
                        Box(Modifier.weight(1f)) { if(start+col<count) content(start+col) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileGrid(title:String, fields:List<Pair<String,String?>>) {
    Text(title,color=Navy,fontWeight=FontWeight.Bold)
    ProfileCells(fields.size) { i ->
        val (label,value)=fields[i]
        Column(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).padding(12.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(label,color=Teal,style=MaterialTheme.typography.labelMedium,modifier=Modifier.weight(1f))
                if(edit!=null) IconButton(onClick={edit(index)},modifier=Modifier.size(30.dp)) { Icon(Icons.Default.Edit,"تعديل",modifier=Modifier.size(16.dp),tint=Teal) }
            }
            Text(value.orEmpty().ifBlank { "غير متوفر" },color=Ink)
        }
    }
}
