package ma.salah.eddine.schoolmanager.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert

@Dao
abstract class SchoolDao {
    @Query("SELECT * FROM movements WHERE year=:year ORDER BY eventDate DESC,section,ordinal,fullName")
    abstract fun movements(year: String): kotlinx.coroutines.flow.Flow<List<Movement>>
    @Query("SELECT * FROM movements WHERE year=:year AND massar=:massar ORDER BY eventDate DESC")
    abstract fun studentMovements(year:String,massar:String): kotlinx.coroutines.flow.Flow<List<Movement>>
    @Query("SELECT * FROM movement_coverage WHERE year=:year ORDER BY level,section")
    abstract fun coverage(year: String): kotlinx.coroutines.flow.Flow<List<MovementCoverage>>
    @Upsert abstract suspend fun putMovements(rows: List<Movement>)
    @Upsert abstract suspend fun putCoverage(rows: List<MovementCoverage>)
    @Transaction open suspend fun storeMovements(rows: List<Movement>, sheets: List<MovementCoverage>) {
        putMovements(rows)
        putCoverage(sheets)
    }

    @Query("SELECT value FROM app_settings WHERE key=:key")
    abstract fun watchSetting(key:String): kotlinx.coroutines.flow.Flow<String?>

    @Insert abstract suspend fun insertSlip(slip: EntrySlip)
    @Insert abstract suspend fun insertRecipients(rows: List<SlipStudent>)
    @Transaction
    open suspend fun recordSlip(slip: EntrySlip, rows: List<SlipStudent>) {
        require(rows.isNotEmpty() && rows.all { it.slip == slip.id } && (slip.guardianStudent.isBlank() || rows.any { it.massar == slip.guardianStudent }))
        insertSlip(slip)
        insertRecipients(rows)
    }
    @Query("SELECT * FROM entry_slips WHERE id=:id")
    abstract suspend fun slip(id: String): EntrySlip?
    @Query("SELECT d.id,d.date,d.time,d.section,d.reason,d.guardianStudent,s.massar,s.displayName,s.ordinal FROM entry_slips d JOIN slip_students s ON s.slip=d.id WHERE d.year=:year AND (:date='' OR d.date=:date) AND (:student='' OR s.massar=:student) ORDER BY d.date DESC,d.time DESC,d.rowid DESC,s.ordinal")
    abstract fun slipRows(year: String, date: String, student: String): kotlinx.coroutines.flow.Flow<List<SlipRow>>
    @Query("SELECT * FROM slip_students WHERE slip=:id ORDER BY ordinal")
    abstract suspend fun recipients(id: String): List<SlipStudent>
    @androidx.room.Update abstract suspend fun updateLesson(row: ScheduledLesson): Int

    @Query("SELECT * FROM scheduled_lessons WHERE revision=(SELECT value FROM app_settings WHERE key=:revisionKey)")
    abstract suspend fun currentSchedule(revisionKey:String):List<ScheduledLesson>
    @Query("SELECT * FROM app_settings WHERE key LIKE 'fet.label.%'")
    abstract suspend fun scheduleLabels():List<AppSettingEntity>
    @Insert
    abstract suspend fun insertLessons(lessons:List<ScheduledLesson>)
    @Transaction
    open suspend fun saveSchedule(year:String, lessons:List<ScheduledLesson>) {
        require(lessons.isNotEmpty())
        insertLessons(lessons)
        saveSetting(AppSettingEntity("fet.current.$year", lessons.first().revision))
    }

    @Query("SELECT * FROM family_contacts WHERE year = :year")
    abstract suspend fun familyForYear(year:String):List<FamilyContact>
    @Query("SELECT * FROM family_contacts WHERE year = :year AND massar = :massar")
    abstract suspend fun family(year:String,massar:String):List<FamilyContact>
    @Upsert
    abstract suspend fun storeFamily(rows:List<FamilyContact>)

    @Query("SELECT * FROM students ORDER BY surname, givenName")
    abstract suspend fun allStudents(): List<StudentEntity>

    @Query("SELECT * FROM students WHERE massarCode = :code LIMIT 1")
    abstract suspend fun student(code: String): StudentEntity?

    @Query("SELECT * FROM enrollments WHERE schoolYear = :year")
    abstract suspend fun enrollments(year: String): List<EnrollmentEntity>

    @Query("SELECT * FROM school_classes WHERE schoolYear = :year")
    abstract suspend fun schoolClasses(year: String): List<SchoolClassEntity>

    @Query("""
        SELECT s.massarCode, s.surname, s.givenName, s.gender, s.birthDate, s.birthPlace,
               c.levelName, e.className, e.ordinal
        FROM students s JOIN enrollments e ON e.massarCode = s.massarCode
        JOIN school_classes c ON c.schoolYear = e.schoolYear AND c.className = e.className
        WHERE e.schoolYear = :year
        AND (CASE WHEN length(:query) BETWEEN 1 AND 3 AND :query NOT GLOB '*[^0-9]*'
                  THEN e.ordinal = CAST(:query AS INTEGER)
                  ELSE (:query = '' OR s.massarCode LIKE '%' || :query || '%'
             OR s.surname LIKE '%' || :query || '%' OR s.givenName LIKE '%' || :query || '%'
             OR s.birthDate LIKE '%' || :query || '%'
             OR (s.surname || ' ' || s.givenName) LIKE '%' || :query || '%') END)
        ORDER BY e.className, e.ordinal IS NULL, e.ordinal, s.surname, s.givenName
    """)
    abstract suspend fun studentsForYear(year: String, query: String = ""): List<StudentListRow>

    @Query("SELECT DISTINCT className FROM enrollments WHERE schoolYear = :year ORDER BY className")
    abstract suspend fun classNames(year: String): List<String>

    @Query("SELECT c.className, c.levelName, COUNT(e.massarCode) AS studentCount FROM school_classes c LEFT JOIN enrollments e ON e.schoolYear = c.schoolYear AND e.className = c.className WHERE c.schoolYear = :year GROUP BY c.className, c.levelName ORDER BY c.levelName, c.className")
    abstract suspend fun classSummaries(year: String): List<ClassSummary>

    @Query("""
        SELECT s.massarCode, s.surname, s.givenName, s.gender, s.birthDate, s.birthPlace,
               c.levelName, e.className, e.ordinal
        FROM students s JOIN enrollments e ON e.massarCode = s.massarCode
        JOIN school_classes c ON c.schoolYear = e.schoolYear AND c.className = e.className
        WHERE e.schoolYear = :year AND e.className = :className
        ORDER BY e.className, e.ordinal IS NULL, e.ordinal, s.surname, s.givenName
    """)
    abstract suspend fun studentsInClass(year: String, className: String): List<StudentListRow>

    @Query("SELECT * FROM employees WHERE isCurrent = 1 ORDER BY nameArabic, nameFrench")
    abstract suspend fun allEmployees(): List<EmployeeEntity>

    @Query("SELECT * FROM employee_services WHERE isCurrent = 1 ORDER BY employeePpr, disciplineLabelFrench, levelCode")
    abstract suspend fun allEmployeeServices(): List<EmployeeServiceEntity>

    @Query("SELECT DISTINCT employeePpr FROM employee_services WHERE isCurrent = 1 AND employeePpr IS NOT NULL")
    abstract suspend fun employeesWithServices(): List<String>

    @Query("SELECT * FROM employee_services WHERE employeePpr = :ppr AND isCurrent = 1 ORDER BY disciplineLabelFrench, levelCode")
    abstract suspend fun employeeServices(ppr: String): List<EmployeeServiceEntity>

    @Query("SELECT * FROM teacher_assignments WHERE schoolYear = :year AND isCurrent = 1 ORDER BY subjectName, teacherName")
    abstract suspend fun assignments(year: String): List<TeacherAssignmentEntity>

    @Query("SELECT * FROM teacher_assignments WHERE schoolYear = :year AND className = :className AND isCurrent = 1 ORDER BY subjectName, teacherName")
    abstract suspend fun assignmentsForClass(year: String, className: String): List<TeacherAssignmentEntity>

    @Query("SELECT * FROM teacher_assignments WHERE schoolYear = :year AND teacherCode = :teacherCode AND isCurrent = 1 ORDER BY subjectName, className")
    abstract suspend fun assignmentsForTeacher(year: String, teacherCode: String): List<TeacherAssignmentEntity>

    @Query("SELECT * FROM reference_values")
    abstract suspend fun allReferenceValues(): List<ReferenceValueEntity>

    @Query("SELECT value FROM app_settings WHERE key = :key LIMIT 1")
    abstract suspend fun setting(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun saveSetting(setting: AppSettingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putStudents(items: List<StudentEntity>)

    @Upsert
    abstract suspend fun putClasses(items: List<SchoolClassEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun ensureClasses(items: List<SchoolClassEntity>)

    @Upsert
    abstract suspend fun putSubjects(items: List<SubjectEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putEnrollments(items: List<EnrollmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putEmployees(items: List<EmployeeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putEmployeeServices(items: List<EmployeeServiceEntity>)

    @Query("UPDATE employees SET isCurrent = 0")
    abstract suspend fun archiveEmployees()

    @Query("UPDATE employee_services SET isCurrent = 0")
    abstract suspend fun archiveEmployeeServices()

    @Transaction
    open suspend fun replaceCurrentEmployeeData(employees: List<EmployeeEntity>, services: List<EmployeeServiceEntity>) {
        archiveEmployees()
        archiveEmployeeServices()
        putEmployees(employees)
        putEmployeeServices(services)
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putReferences(items: List<ReferenceValueEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putAssignments(items: List<TeacherAssignmentEntity>)

    @Insert
    abstract suspend fun addImportHistory(item: ImportHistoryEntity)

    @Query("UPDATE teacher_assignments SET isCurrent = 0 WHERE schoolYear = :year")
    abstract suspend fun archiveAssignmentsForYear(year: String)

    @Transaction
    open suspend fun replaceAssignmentsForYear(year: String, items: List<TeacherAssignmentEntity>) {
        archiveAssignmentsForYear(year)
        putAssignments(items)
    }

    @Transaction
    open suspend fun commitStudentImport(
        students: List<StudentEntity>,
        classes: List<SchoolClassEntity>,
        enrollments: List<EnrollmentEntity>,
        settings: List<AppSettingEntity>,
        history: ImportHistoryEntity
    ) {
        putClasses(classes)
        putStudents(students)
        putEnrollments(enrollments)
        settings.forEach { saveSetting(it) }
        addImportHistory(history)
    }

    @Transaction
    open suspend fun commitEmployeeImport(
        employees: List<EmployeeEntity>,
        services: List<EmployeeServiceEntity>,
        references: List<ReferenceValueEntity>,
        history: ImportHistoryEntity
    ) {
        replaceCurrentEmployeeData(employees, services)
        putReferences(references)
        addImportHistory(history)
    }

    @Transaction
    open suspend fun commitTeachingImport(
        year: String,
        classes: List<SchoolClassEntity>,
        subjects: List<SubjectEntity>,
        assignments: List<TeacherAssignmentEntity>,
        history: ImportHistoryEntity
    ) {
        ensureClasses(classes)
        putSubjects(subjects)
        replaceAssignmentsForYear(year, assignments)
        saveSetting(AppSettingEntity("schoolYear", year))
        addImportHistory(history)
    }

    @Query("""
        SELECT
          (SELECT COUNT(*) FROM students s JOIN enrollments e ON e.massarCode = s.massarCode WHERE e.schoolYear = :year) AS studentCount,
          (SELECT COUNT(*) FROM enrollments WHERE schoolYear = :year) AS enrollmentCount,
          (SELECT COUNT(*) FROM school_classes WHERE schoolYear = :year) AS classCount,
          (SELECT COUNT(*) FROM employees WHERE isCurrent = 1) AS employeeCount,
          (SELECT COUNT(DISTINCT teacherCode) FROM teacher_assignments WHERE schoolYear = :year AND isCurrent = 1) AS scheduleTeacherCount
    """)
    abstract suspend fun dashboardCounts(year: String): DashboardCounts
}

data class DashboardCounts(
    val studentCount: Int,
    val enrollmentCount: Int,
    val classCount: Int,
    val employeeCount: Int,
    val scheduleTeacherCount: Int
)
