package ma.salah.eddine.schoolmanager

import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Checkbox
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.res.painterResource
import androidx.activity.compose.BackHandler
import ma.salah.eddine.schoolmanager.importing.MovementKind
import ma.salah.eddine.schoolmanager.importing.FamilyBatch
import ma.salah.eddine.schoolmanager.importing.FamilyReview
import ma.salah.eddine.schoolmanager.importing.FamilyFile
import ma.salah.eddine.schoolmanager.data.FamilyContact
import ma.salah.eddine.schoolmanager.data.SchoolDao
import android.os.Bundle
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.animation.core.animateFloat
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.AcademicSeason
import ma.salah.eddine.schoolmanager.data.AppSettingEntity
import ma.salah.eddine.schoolmanager.data.ClassSummary
import ma.salah.eddine.schoolmanager.data.DashboardCounts
import ma.salah.eddine.schoolmanager.data.EmployeeEntity
import ma.salah.eddine.schoolmanager.data.EmployeeServiceEntity
import ma.salah.eddine.schoolmanager.data.StudentListRow
import ma.salah.eddine.schoolmanager.data.TeacherAssignmentEntity
import ma.salah.eddine.schoolmanager.data.SchoolDatabase
import ma.salah.eddine.schoolmanager.importing.EmployeeImportDiff
import ma.salah.eddine.schoolmanager.importing.EmployeeImportPlan
import ma.salah.eddine.schoolmanager.importing.EmployeeXmlParser
import ma.salah.eddine.schoolmanager.importing.ImportCoordinator
import ma.salah.eddine.schoolmanager.importing.StudentImportDiff
import ma.salah.eddine.schoolmanager.importing.StudentWorkbookParser
import ma.salah.eddine.schoolmanager.importing.StudentWorkbookPlan
import ma.salah.eddine.schoolmanager.importing.TeacherLoadPlan
import ma.salah.eddine.schoolmanager.importing.TeacherLoadWorkbookParser
import ma.salah.eddine.schoolmanager.importing.TeachingImportDiff

internal val Navy = Color(0xFF093853)
internal val Teal = Color(0xFF167450)
private val Pale = Color(0xFFF3F7F8)
private val Ink = Color(0xFF173447)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val restored = runCatching { SchoolBackup.applyPending(this) }
        restored.onSuccess { count ->
            if (count != null) android.widget.Toast.makeText(this, "تم استرجاع البيانات: $count ورقة دخول", android.widget.Toast.LENGTH_LONG).show()
        }.onFailure { error ->
            android.widget.Toast.makeText(this, "تعذرت الاستعادة: ${error.message}", android.widget.Toast.LENGTH_LONG).show()
        }
        setContent { SchoolApp() }
    }
}

private data class Module(val title: String, val subtitle: String, val route: String)

private val modules = listOf(
    Module("الإحصائيات", "مؤشرات المؤسسة", "statistics"),
    Module("لائحة التلاميذ", "الأقسام والمواد والأساتذة", "students"),
    Module("حركية التلاميذ", "الوافدون والمغادرون وتتبع الالتحاق", "movements"),
    Module("الأقسام والمستويات", "لوائح الأقسام", "classes"),
    Module("الأساتذة", "الموظفون والخدمات", "staff"),
    Module("توزيع الأقسام على الأساتذة", "توزيع الحصص", "teaching"),
    Module("استعمال الزمن", "الجداول الأسبوعية", "timetable"),
    Module("الغياب", "الغياب والتأخر وسجل التسليم", "slips"),
    Module("الإعدادات", "المؤسسة واستيراد الملفات", "settings")
)

private enum class ImportType { STUDENTS, EMPLOYEES, TEACHING }

private sealed interface ImportReview {
    val fileName: String
    data class Students(val plan: StudentWorkbookPlan, val diff: StudentImportDiff, override val fileName: String) : ImportReview
    data class Employees(val plan: EmployeeImportPlan, val diff: EmployeeImportDiff, override val fileName: String) : ImportReview
    data class Teaching(val plan: TeacherLoadPlan, val diff: TeachingImportDiff, override val fileName: String) : ImportReview
}

@Composable
private fun SchoolApp() {
    val movementState = androidx.compose.runtime.saveable.rememberSaveableStateHolder()
    val context = LocalContext.current
    val dao = remember { SchoolDatabase.get(context).schoolDao() }
    var route by rememberSaveable { mutableStateOf("home") }
    var schoolName by rememberSaveable { mutableStateOf("الثانوية التأهيلية صلاح الدين الأيوبي") }
    var schoolLevel by rememberSaveable { mutableStateOf("الثانوي التأهيلي") }
    var province by rememberSaveable { mutableStateOf("تاوريرت") }
    var academy by rememberSaveable { mutableStateOf("الشرق") }
    var schoolYear by rememberSaveable { mutableStateOf("2026/2027") }
    var availableYears by remember { mutableStateOf(emptyList<String>()) }
    var settingsLoaded by remember { mutableStateOf(false) }
    var counts by remember { mutableStateOf(DashboardCounts(0, 0, 0, 0, 0)) }
    var classSummaries by remember { mutableStateOf(emptyList<ClassSummary>()) }
    var selectedClass by rememberSaveable { mutableStateOf("") }
    var search by rememberSaveable { mutableStateOf("") }
    var studentRows by remember { mutableStateOf(emptyList<StudentListRow>()) }
    var classMembers by remember { mutableStateOf(emptyList<StudentListRow>()) }
    var classAssignments by remember { mutableStateOf(emptyList<TeacherAssignmentEntity>()) }
    var employeeRows by remember { mutableStateOf(emptyList<EmployeeEntity>()) }
    var employeeServiceRows by remember { mutableStateOf(emptyList<EmployeeServiceEntity>()) }
    var assignmentRows by remember { mutableStateOf(emptyList<TeacherAssignmentEntity>()) }
    var refreshKey by remember { mutableStateOf(0) }
    var importType by remember { mutableStateOf(ImportType.STUDENTS) }
    var review by remember { mutableStateOf<ImportReview?>(null) }
    val movementChoices = remember { mutableStateMapOf<String,String>() }
    var importError by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val backupExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.use { SchoolBackup.export(context, it) } ?: error("تعذر فتح الملف") } }
                .onSuccess { statusMessage = "تم تصدير النسخة الاحتياطية بنجاح" }
                .onFailure { importError = it.message ?: "فشل التصدير" }
        }
    }
    val backupImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { SchoolBackup.stageRestore(context, it) } ?: error("تعذر فتح الملف") } }
                .onSuccess {
                    statusMessage = "تم تجهيز الاستعادة"
                    (context as? android.app.Activity)?.recreate()
                }
                .onFailure { importError = it.message ?: "فشلت الاستعادة" }
        }
    }

    fun displayName(uri: Uri): String {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment ?: "ملف مستورد"
    }

    var familyReview by remember { mutableStateOf<FamilyReview?>(null) }
    var scheduleClass by rememberSaveable { mutableStateOf("") }
    var scheduleReview by rememberSaveable { mutableStateOf(false) }
    var profile by remember { mutableStateOf<StudentListRow?>(null) }
    val familyPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            isLoading = true
            statusMessage = ""
            importError = ""
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        val files = mutableListOf<FamilyFile>()
                        val errors = mutableListOf<String>()
                        for (uri in uris.distinct()) {
                            val name = displayName(uri)
                            runCatching {
                                context.contentResolver.openInputStream(uri)?.use { FamilyBatch.parse(name,it) } ?: error("تعذر فتح الملف")
                            }.onSuccess { files += it }.onFailure { errors += "$name — ${it.message}" }
                        }
                        FamilyBatch.review(dao,files,schoolYear,errors)
                    }
                }.onSuccess { familyReview = it }.onFailure { importError = it.message ?: "تعذرت المعاينة" }
                isLoading = false
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val type = importType
            val fileName = displayName(uri)
            isLoading = true
            importError = ""
            scope.launch {
                val result = runCatching {
                    withContext(Dispatchers.IO) {
                        when (type) {
                            ImportType.STUDENTS -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(StudentWorkbookParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                val target = if (AcademicSeason.parse(plan.schoolYear) != null) plan.copy(schoolYear=dao.resolveYear(plan.schoolYear)) else plan
                                ImportReview.Students(target, ImportCoordinator.compareStudents(dao, target), fileName)
                            }
                            ImportType.EMPLOYEES -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(EmployeeXmlParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                ImportReview.Employees(plan, ImportCoordinator.compareEmployees(dao, plan), fileName)
                            }
                            ImportType.TEACHING -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(TeacherLoadWorkbookParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                val target = if (AcademicSeason.parse(plan.schoolYear) != null) plan.copy(schoolYear=dao.resolveYear(plan.schoolYear)) else plan
                                ImportReview.Teaching(target, ImportCoordinator.compareTeaching(dao, target), fileName)
                            }
                        }
                    }
                }
                result.onSuccess { movementChoices.clear(); review = it }.onFailure { importError = it.message ?: "تعذر تحليل الملف." }
                isLoading = false
            }
        }
    }

    fun chooseImport(type: ImportType) {
        importType = type
        importError = ""
        val mimeTypes = when (type) {
            ImportType.STUDENTS, ImportType.TEACHING -> arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            ImportType.EMPLOYEES -> arrayOf("application/xml", "text/xml", "text/*", "application/*")
        }
        picker.launch(mimeTypes)
    }

    fun changeImportYear(value: String) {
        val chosen = review ?: return
        isLoading = true
        importError = ""
        scope.launch {
            runCatching { withContext(Dispatchers.IO) {
                val target = dao.resolveYear(value)
                when (chosen) {
                    is ImportReview.Students -> chosen.plan.copy(schoolYear=target).let { chosen.copy(plan=it,diff=ImportCoordinator.compareStudents(dao,it)) }
                    is ImportReview.Teaching -> chosen.plan.copy(schoolYear=target).let { chosen.copy(plan=it,diff=ImportCoordinator.compareTeaching(dao,it)) }
                    is ImportReview.Employees -> chosen
                }
            } }.onSuccess { movementChoices.clear(); review=it }
                .onFailure { importError=it.message ?: "تعذر تغيير الموسم" }
            isLoading=false
        }
    }

    fun confirmImport() {
        val chosen = review ?: return
        isLoading = true
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    when (chosen) {
                        is ImportReview.Students -> ImportCoordinator.importStudents(dao, chosen.plan, chosen.fileName, chosen.diff.copy(changes=chosen.diff.changes.map { it.copy(kind=movementChoices[it.massar] ?: it.kind) }))
                        is ImportReview.Employees -> ImportCoordinator.importEmployees(dao, chosen.plan, chosen.fileName, chosen.diff)
                        is ImportReview.Teaching -> ImportCoordinator.importTeaching(dao, chosen.plan, chosen.fileName, chosen.diff)
                    }
                }
            }
            result.onSuccess {
                statusMessage = "تم اعتماد البيانات وحفظها على الجهاز."
                review = null
                refreshKey++
            }.onFailure { importError = it.message ?: "تعذر حفظ البيانات." }
            isLoading = false
        }
    }

    LaunchedEffect(refreshKey) {
        val saved = withContext(Dispatchers.IO) {
            listOf("schoolName", "province", "academy", "schoolYear", "schoolLevel").map { dao.setting(it) }
        }
        saved[0]?.let { schoolName = it }
        saved[1]?.let { province = it }
        saved[2]?.let { academy = it }
        availableYears = withContext(Dispatchers.IO) { dao.availableYears() }.filter { AcademicSeason.parse(it) != null }
        schoolYear = saved[3]?.takeIf { AcademicSeason.parse(it) != null }
            ?: availableYears.maxByOrNull { AcademicSeason.parse(it)!! } ?: schoolYear
        saved[4]?.let { schoolLevel = it }
        withContext(Dispatchers.IO) {
            dao.saveSetting(AppSettingEntity("schoolName", schoolName))
            dao.saveSetting(AppSettingEntity("province", province))
            dao.saveSetting(AppSettingEntity("academy", academy))
            if (AcademicSeason.parse(dao.setting("schoolYear")) == null) dao.saveSetting(AppSettingEntity("schoolYear", schoolYear))
            dao.saveSetting(AppSettingEntity("schoolLevel", schoolLevel))
        }
        settingsLoaded=true
    }

    LaunchedEffect(schoolYear, route, selectedClass, search, refreshKey) {
        val loaded = withContext(Dispatchers.IO) {
            val dashboard = dao.dashboardCounts(schoolYear)
            val classes = dao.classSummaries(schoolYear)
            val members = if (selectedClass.isNotBlank()) dao.studentsInClass(schoolYear, selectedClass) else emptyList()
            val aliases = dao.scheduleLabels().associate { it.key to it.value }
            fun named(rows: List<TeacherAssignmentEntity>) = rows.map { row -> aliases["fet.label.الأستاذ."+row.teacherCode.filterNot(Char::isWhitespace).uppercase()]?.let { row.copy(teacherName=it) } ?: row }
            val classLoad = if (selectedClass.isNotBlank()) dao.assignmentsForClass(schoolYear, selectedClass) else emptyList()
            val students = if (route == "students" || route == "profiles") dao.studentsForYear(schoolYear, search.trim().map { it.digitToIntOrNull()?.digitToChar() ?: it }.joinToString("")) else emptyList()
            val employees = if (route in setOf("teaching","staff")) dao.allEmployees() else emptyList()
            val statsEmployees = if (route in setOf("statistics","institution")) dao.allEmployees() else emptyList()
            val services = if (route == "statistics") dao.allEmployeeServices() else emptyList()
            val assignments = if (route in setOf("teaching","institution","councils")) dao.assignments(schoolYear) else emptyList()
            val statsStudents = if (route in setOf("statistics","institution")) dao.studentsForYear(schoolYear) else students
            ScreenData(dashboard, classes, members, named(classLoad), students, employees, named(assignments), statsStudents, statsEmployees, services)
        }
        counts = loaded.counts
        classSummaries = loaded.classes
        classMembers = loaded.members
        classAssignments = loaded.classAssignments
        if (route == "students" || route == "profiles") studentRows = loaded.students
        if (route in setOf("teaching","staff")) employeeRows = loaded.employees
        if (route in setOf("teaching","institution","councils")) assignmentRows = loaded.assignments
        if (route in setOf("statistics","institution")) {
            studentRows = loaded.statsStudents
            employeeRows = loaded.statsEmployees
            employeeServiceRows = loaded.services
        }
    }

    var intro by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) { if(intro) { kotlinx.coroutines.delay(3200); intro=false } }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            shapes = androidx.compose.material3.Shapes(extraSmall=RoundedCornerShape(14.dp),small=RoundedCornerShape(16.dp),medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(22.dp)),
            colorScheme = lightColorScheme(
                primary = Navy,
                secondary = Teal,
                background = Pale,
                surface = Color.White,
                primaryContainer = Color(0xFFDCEFF4),
                secondaryContainer = Color(0xFFE4F4E9),
                surfaceVariant = Color(0xFFEAF2F5),
                onSurfaceVariant = Navy,
                onPrimary = Color.White,
                onBackground = Ink,
                onSurface = Ink
            )
        ) {
            Surface(modifier = Modifier.fillMaxSize(), color = Pale) {
                val transition = remember { androidx.compose.animation.core.Animatable(1f) }
                LaunchedEffect(route,profile?.massarCode,intro) {
                    transition.snapTo(0.35f)
                    transition.animateTo(1f,androidx.compose.animation.core.tween(180))
                }
                Column(modifier = Modifier.fillMaxSize().safeDrawingPadding().then(Modifier.graphicsLayer { alpha=transition.value })) {
                    if(intro || !settingsLoaded) {
                        SplashIntro()
                    } else {
                    if (route !in listOf("home","settings")) Header(schoolName)
                    BackHandler(enabled=route!="home"){ if(profile!=null) profile=null else route="home" }
                    val navigate: (String) -> Unit = { r -> scheduleClass = ""; scheduleReview = false; selectedClass = ""; search = ""; profile = null; route = r }
                    val searchNav: (String) -> Unit = { q -> scheduleClass = ""; scheduleReview = false; selectedClass = ""; profile = null; search = q; route = "students" }
                    Box(Modifier.weight(1f)) {
                    key(schoolYear) {
                    val student = profile
                    if (student != null) {
                        val family by remember(student,schoolYear){dao.watchFamily(schoolYear,student.massarCode)}.collectAsState(initial=emptyList())
                        BackHandler { profile = null }
                        FamilyProfile(dao, schoolYear, student, family, onSchedule = { scheduleClass=student.className; scheduleReview=false; profile=null; route="timetable" }) { profile = null }
                    } else when (route) {
                        "home" -> HomeScreen(counts, schoolYear, schoolName, province, academy, modules, navigate, searchNav, dao, { profile = it })
                        "students", "profiles" -> StudentsScreen({chooseImport(ImportType.STUDENTS)},dao,schoolYear,route == "profiles", studentRows, classSummaries, selectedClass, classMembers, classAssignments, { selectedClass = it }, search, onSearch = { search = it }, onStudent = { profile = it }, onBack = { route = "home" })
                        "classes" -> ClassesScreen(classSummaries, selectedClass, classMembers, classAssignments,
                            onSelect = { selectedClass = it }, onStudent = { profile = it }, onBack = { if (selectedClass.isNotBlank()) selectedClass = "" else route = "home" })
                        "staff" -> StaffScreen(employeeRows) { route = "home" }
                        "movements" -> movementState.SaveableStateProvider(schoolYear) { MovementScreen(dao,schoolYear,schoolName,academy,province,onStudent={profile=it}) { route="home" } }
                        "slips" -> SlipsScreen(dao,schoolYear,classSummaries.map { it.className }) { route="home" }
                        "teaching" -> TeachingScreen(assignmentRows,employeeRows,{code,name ->
                            scope.launch { dao.saveSetting(AppSettingEntity("fet.label.الأستاذ."+code.filterNot(Char::isWhitespace).uppercase(),name));refreshKey++ }
                        }) { route = "home" }
                        "institution" -> InstitutionDashboard(schoolName,schoolLevel,province,schoolYear,counts,studentRows,employeeRows,assignmentRows) { route="statistics" }
                        "councils" -> CouncilsScreen(schoolName,schoolLevel,schoolYear,employeeRows,assignmentRows){route="home"}
                        "statistics" -> StatisticsScreen(dao, counts, schoolYear, studentRows, employeeRows, employeeServiceRows, { route = "institution" }) { route = "home" }
                        "conduct" -> ConductScreen(dao,schoolYear,openExpulsion={route="quickExpulsion"}) { route="home" }
                        "quickIncident", "quickBehavior", "quickAbsence" -> key(route) { ConductScreen(dao,schoolYear,when(route){"quickIncident"->"مخالفات";"quickBehavior"->"التزامات سلوك";else->"التزامات غياب"}) { route="home" } }
                        "quickPe", "quickHospital" -> key(route) { HealthScreen(dao,schoolYear,schoolName,academy,province,if(route=="quickPe") "الإعفاء من التربية البدنية" else "نقل التلميذ إلى المستشفى") { route="home" } }
                        "quickExpulsion" -> ExpulsionScreen(dao,schoolYear,schoolName,academy,province){route="conduct"}
                        "health" -> HealthScreen(dao,schoolYear,schoolName,academy,province) { route="home" }
                        "guardianExport" -> GuardianExportScreen(dao,schoolYear,schoolName,academy,province) { route="settings" }
                        "timetable" -> WeekScreen(dao,schoolYear,scheduleClass,scheduleReview) { route = "home" }
                        "settings" -> SettingsScreen(
                            counts = counts,
                            schoolName = schoolName,
                            schoolLevel = schoolLevel,
                            onSchoolLevel = { value -> schoolLevel = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("schoolLevel", value)) } },
                            onSchoolName = { value -> schoolName = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("schoolName", value)) } },
                            province = province,
                            onProvince = { value -> province = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("province", value)) } },
                            academy = academy,
                            onAcademy = { value -> academy = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("academy", value)) } },
                            schoolYear = schoolYear,
                            availableYears = availableYears,
                            onSchoolYear = { value ->
                                isLoading=true
                                scope.launch {
                                    runCatching { withContext(Dispatchers.IO) {
                                        // Explicitly choosing an existing legacy key remains possible.
                                        val target = if (value in dao.availableYears() && AcademicSeason.parse(value)!=null) value else dao.resolveYear(value)
                                        dao.saveSetting(AppSettingEntity("schoolYear",target))
                                        target
                                    } }.onSuccess { target ->
                                        profile=null; selectedClass=""; search=""; scheduleClass=""; scheduleReview=false
                                        counts=DashboardCounts(0,0,0,0,0); classSummaries=emptyList(); studentRows=emptyList(); classMembers=emptyList(); classAssignments=emptyList(); assignmentRows=emptyList()
                                        schoolYear=target; refreshKey++; importError=""; statusMessage="تم اعتماد الموسم الدراسي $target"
                                    }.onFailure { importError=it.message ?: "تعذر حفظ الموسم" }
                                    isLoading=false
                                }
                            },
                            onImport = ::chooseImport,
                            onBackupExport = { backupExport.launch("MOASASATI_Backup_${System.currentTimeMillis()}.zip") },
                            onBackupImport = { backupImport.launch(arrayOf("application/zip", "application/octet-stream")) },
                            movementImport = { MovementImport(dao,schoolYear,::displayName) },
                            timetableImport = { FetImport(dao,schoolYear) { scheduleClass=""; scheduleReview=true; route="timetable" } },
                            onGuardianExport = { route="guardianExport" },
                            onFamily = { familyPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) },
                            error = importError,
                            status = statusMessage,
                            isLoading = isLoading,
                            onBack = { route = "home" }
                        )
                        else -> HomeScreen(counts, schoolYear, schoolName, province, academy, modules, navigate, searchNav, dao, { profile = it })
                    }
                    }
                    }
                    AppBottomBar(route, navigate)
                }
            }
            }
            familyReview?.let { batch ->
                AlertDialog(onDismissRequest = { if (!isLoading) familyReview = null },
                    title = { Text("معاينة ملفات أولياء الأمور") },
                    text = {
                        LazyColumn(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            item { Text("سجلات الاتصال الجديدة أو المتغيرة: ${batch.contacts.size}") }
                            items(batch.notes) { Text(it, fontSize = 13.sp) }
                        }
                    },
                    dismissButton = { OutlinedButton(onClick = { familyReview = null }, enabled = !isLoading) { Text("إغلاق") } },
                    confirmButton = { Button(enabled = !isLoading && (batch.contacts.isNotEmpty() || batch.ids.isNotEmpty()), onClick = {
                        isLoading = true
                        scope.launch {
                            runCatching { dao.storeFamily(batch.contacts); batch.ids.forEach { dao.saveSetting(it) } }.onSuccess {
                                statusMessage = "تم حفظ بيانات الأسرة على الجهاز."
                            }.onFailure { importError = it.message ?: "تعذر حفظ بيانات الأسرة" }
                            familyReview = null
                            isLoading = false
                        }
                    }) { Text("تأكيد حفظ المطابقات") } })
            }
            if (review != null) {
                ImportPreviewDialog(review!!, isLoading, movementChoices, schoolYear, importError, ::changeImportYear, onDismiss = { if (!isLoading) review = null }, onConfirm = ::confirmImport)
            }
        }
    }
}

private data class ScreenData(
    val counts: DashboardCounts,
    val classes: List<ClassSummary>,
    val members: List<StudentListRow>,
    val classAssignments: List<TeacherAssignmentEntity>,
    val students: List<StudentListRow>,
    val employees: List<EmployeeEntity>,
    val assignments: List<TeacherAssignmentEntity>,
    val statsStudents: List<StudentListRow>,
    val statsEmployees: List<EmployeeEntity>,
    val services: List<EmployeeServiceEntity>
)

@Composable
private fun Header(schoolName: String) {
    Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF093853),Color(0xFF11678B))))
        .padding(horizontal=16.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Image(painterResource(R.drawable.moasasati_foreground),"شعار مؤسستي",Modifier.size(42.dp).clip(CircleShape))
        Column(Modifier.weight(1f)) {
            Text("مؤسستي",color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold)
            Text(schoolName,color=Color.White,fontSize=12.sp)
        }
    }
}

    private val AllHomeTiles = listOf(
        HomeTile("مجالس المؤسسة", "تشكيلة المجالس", "councils", Icons.Default.Groups, Color(0xFF11678B)),
        HomeTile("المواظبة والسلوك", "المخالفات والالتزامات", "conduct", Icons.Default.EditNote, Color(0xFF16745F)),
        HomeTile("الغياب", "ورقة الدخول وسجل التأخر", "slips", Icons.Default.EditNote, Color(0xFF225DC4)),
        HomeTile("التلاميذ", "لائحة التلاميذ ومعلوماتهم", "students", Icons.Default.Groups, Color(0xFF079AAA)),
        HomeTile("حركية التلاميذ", "لوائح الحركية", "movements", Icons.Default.SwapHoriz, Color(0xFF00B540)),
        HomeTile("الأقسام", "تدبير الأقسام", "classes", Icons.Default.Layers, Color(0xFF078CE1)),
        HomeTile("الموظفون", "توزيع الأساتذة والمواد", "staff", Icons.Default.Person, Color(0xFFE58A30)),
        HomeTile("توزيع الأساتذة", "إسناد المواد", "teaching", Icons.Default.CoPresent, Color(0xFFFF974B)),
        HomeTile("استعمال الزمن", "الجداول الأسبوعية", "timetable", Icons.Default.CalendarMonth, Color(0xFF167450)),
        HomeTile("الإعدادات", "ضبط التطبيق", "settings", Icons.Default.Settings, Color(0xFF5A7194)),
        HomeTile("الصحة المدرسية", "الإعفاء والنقل", "health", Icons.Default.Favorite, Color(0xFF148FA3))
)

private val MainHomeRoutes = listOf("slips", "staff", "classes", "teaching", "conduct", "health", "movements", "councils")
private val MoreRoutes = AllHomeTiles.map { it.route }.filter { it !in MainHomeRoutes } + listOf("institution", "guardianExport")

@Composable
private fun HomeScreen(counts: DashboardCounts, year: String, schoolName: String, province: String, academy: String, modulesList: List<Module>, open: (String) -> Unit, onSearch: (String) -> Unit, dao: SchoolDao, onStudent: (StudentListRow) -> Unit) {
    val tiles = MainHomeRoutes.mapNotNull { r -> AllHomeTiles.firstOrNull { it.route == r } }
    val homeFont = androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Font(R.font.neo_sans_arabic))
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFFF0F5F7)), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Box(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart=32.dp,bottomEnd=32.dp)).background(Brush.verticalGradient(listOf(Color(0xFF103B55),Color(0xFF105B73)))).padding(20.dp).padding(bottom=46.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("$province · $academy",color=Color(0xFFB8D7E2),fontSize=12.sp,fontFamily=homeFont)
                            FitSchoolName(schoolName,Color.White,20.sp,homeFont)
                        }
                        HomeAlerts(dao,year,open)
                    }
                    HomeSearchField(homeFont,onSearch,dao,year,onStudent)
                }
                Row(Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(horizontal=16.dp).offset(y=30.dp),horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    HomeStat("التلاميذ",counts.studentCount,Icons.Default.Groups,Color(0xFF105B73),Color.White,Modifier.weight(1f))
                    HomeStat("الأقسام",counts.classCount,Icons.Default.Layers,Color(0xFF138B80),Color.White,Modifier.weight(1f))
                    HomeStat("الموظفون",counts.employeeCount,Icons.Default.Person,Color(0xFFB66D18),Color.White,Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(34.dp))
        }
        item { QuickActions(homeFont,open) }
        item { Text("الخدمات",color=Navy,fontWeight=FontWeight.Bold,fontSize=16.sp,fontFamily=homeFont,modifier=Modifier.padding(horizontal=16.dp)) }
        items(tiles.chunked(2).size) { idx ->
            Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                tiles.chunked(2)[idx].forEach { tile -> HomeTileCard(tile,0.78f,homeFont,Modifier.weight(1f)) { open(tile.route) } }
            }
        }
    }
}

@Composable
private fun Modifier.pressScale(src: androidx.compose.foundation.interaction.MutableInteractionSource): Modifier {
    val pressed by src.collectIsPressedAsState()
    val sc by androidx.compose.animation.core.animateFloatAsState(if (pressed) 0.95f else 1f)
    return this.graphicsLayer { scaleX = sc; scaleY = sc }
}

@Composable
private fun HomeTileCard(tile: HomeTile, scale: Float, font: androidx.compose.ui.text.font.FontFamily, modifier: Modifier, onClick: () -> Unit) {
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    Card(onClick = onClick, modifier = modifier.pressScale(src), shape = RoundedCornerShape(16.dp), interactionSource = src,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDFE9EC))) {
        Row(Modifier.fillMaxWidth().heightIn(min = (82 * scale).dp).padding(horizontal = 9.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size((34 * scale).dp).background(tile.color.copy(alpha = 0.11f), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                Icon(tile.icon, null, tint = tile.color, modifier = Modifier.size((22 * scale).dp))
            }
            Column(Modifier.weight(1f),horizontalAlignment=Alignment.Start,verticalArrangement=Arrangement.spacedBy(2.dp)) {
                FitSchoolName(tile.title,Navy,12.sp,font)
                Text(tile.subtitle, color = Color(0xFF84919A), fontFamily = font, fontSize = 10.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun HomeSearchField(font: androidx.compose.ui.text.font.FontFamily, onSearch: (String) -> Unit, dao: SchoolDao, year: String, onStudent: (StudentListRow) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    var selectedClass by rememberSaveable(year) { mutableStateOf("") }
    var classMenu by remember { mutableStateOf(false) }
    val roster by androidx.compose.runtime.produceState(emptyList<StudentListRow>(), dao, year) {
        value = withContext(Dispatchers.IO) { dao.studentsForYear(year) }
    }
    val classes=remember(roster){schoolSections(roster.map { it.className })}
    val movements by remember(year) { dao.movements(year) }.collectAsState(emptyList())
    val byCode = remember(movements) { movements.groupBy { it.massar } }
    val people by androidx.compose.runtime.produceState(emptyMap<String, ma.salah.eddine.schoolmanager.data.StudentEntity>(), dao, year, movements) {
        value = withContext(Dispatchers.IO) { dao.allStudents().associateBy { it.massarCode } }
    }
    val results by androidx.compose.runtime.produceState(emptyList<StudentListRow>(), dao, year, q, selectedClass, movements, people, roster) {
        value = emptyList()
        val term = q.trim()
        if (term.isNotBlank() || selectedClass.isNotBlank()) {
            kotlinx.coroutines.delay(100)
            value = withContext(Dispatchers.Default) {
                val current = roster
                val extra = byCode.values.mapNotNull { events ->
                    val m = events.first()
                    val person = people[m.massar]
                    StudentListRow(m.massar, person?.surname.orEmpty(), person?.givenName ?: m.fullName, person?.gender.orEmpty(), person?.birthDate.orEmpty(), person?.birthPlace, m.level, m.section, m.ordinal)
                }
                (current + extra).distinctBy { it.massarCode }.filter { (selectedClass.isBlank() || it.className == selectedClass) && (if(term.isNotBlank() && term.all { c -> c.isDigit() } && term.length<=3) it.ordinal==term.map { c -> c.digitToInt().digitToChar() }.joinToString("").toIntOrNull() else pupilPrefix(term,it.givenName,it.surname,it.massarCode,it.birthDate)) }
            }
        }
    }
    val go = { if (q.isNotBlank()) { onSearch(q.trim()); q = "" } }
    Box(Modifier.fillMaxWidth()) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(46.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF36758A))
        .border(1.dp, Color(0xFF36758A), RoundedCornerShape(14.dp)).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Search, null, tint = Color(0xFFD4E8EF), modifier = Modifier.size(22.dp).clickable { if (selectedClass.isBlank()) go() })
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (q.isEmpty()) Text("ابحث عن تلميذ: الاسم أو رمز مسار", color = Color(0xFFD4E8EF), fontFamily = font, fontSize = 13.sp)
            androidx.compose.foundation.text.BasicTextField(value = q, onValueChange = { q = it }, singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp, fontFamily = font),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { if (selectedClass.isBlank()) go() }),
                modifier = Modifier.fillMaxWidth())
        }
        Box {
            Text(if (selectedClass.isBlank()) "الأقسام ▾" else "$selectedClass ▾", color = Color.White, fontSize = 11.sp, maxLines = 1, modifier = Modifier.clickable { classMenu = true }.padding(4.dp))
            DropdownMenu(expanded = classMenu, onDismissRequest = { classMenu = false }) {
                DropdownMenuItem(text = { Text("جميع الأقسام") }, onClick = { selectedClass = ""; classMenu = false })
                classes.forEach { section -> DropdownMenuItem(text = { Text(section) }, onClick = { selectedClass = section; classMenu = false }) }
            }
        }
    }
    if((q.isNotBlank() || selectedClass.isNotBlank()) && results.isNotEmpty()) androidx.compose.ui.window.Popup(popupPositionProvider=object: androidx.compose.ui.window.PopupPositionProvider { override fun calculatePosition(anchorBounds:androidx.compose.ui.unit.IntRect,windowSize:androidx.compose.ui.unit.IntSize,layoutDirection:androidx.compose.ui.unit.LayoutDirection,popupContentSize:androidx.compose.ui.unit.IntSize)=androidx.compose.ui.unit.IntOffset((anchorBounds.left+anchorBounds.right-popupContentSize.width)/2,anchorBounds.bottom) },onDismissRequest={},properties=androidx.compose.ui.window.PopupProperties(focusable=false)) {
        Card(Modifier.width(310.dp).shadow(8.dp,RoundedCornerShape(12.dp)),shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=Color(0xF5FFFFFF))) {
            LazyColumn(Modifier.heightIn(max=240.dp)) {
                items(results, key = { it.massarCode }) { student ->
                    val kind = byCode[student.massarCode].orEmpty().firstOrNull { it.kind != "CLASS_CHANGE" }?.kind
                    val (status, tint) = when(kind) {
                        "ARRIVAL" -> "وافد" to Color(0xFF2169AC)
                        "RETURN" -> "مرجع" to Color(0xFF8053A4)
                        "INTEGRATED" -> "مدمج" to Color(0xFF8053A4)
                        "DISMISSED" -> "مفصول" to Color(0xFFB83E3E)
                        "DEPARTURE" -> "مغادر" to Color(0xFFB83E3E)
                        "NON_ATTENDANCE" -> "غير ملتحق" to Color(0xFFB47B18)
                        "DROPOUT" -> "منقطع" to Color(0xFFB83E3E)
                        else -> "يزاول دراسته" to Color(0xFF18784B)
                    }
                    Row(Modifier.fillMaxWidth().clickable { q=""; selectedClass=""; onStudent(student) }.padding(horizontal=7.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text((student.givenName+" "+student.surname).trim(),fontFamily=font,fontWeight=FontWeight.Bold,fontSize=12.sp,color=Navy,maxLines=1,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            Text(student.massarCode,fontSize=10.sp,color=Color(0xFF536875),maxLines=1)
                        }
                        Text(status,Modifier.background(tint.copy(alpha=0.10f),RoundedCornerShape(5.dp)).padding(horizontal=3.dp,vertical=2.dp),fontFamily=font,fontSize=9.sp,color=tint,maxLines=1)
                        Text(student.className,fontSize=9.sp,color=Navy,maxLines=1)
                        Text(student.ordinal?.toString() ?: "—",Modifier.background(Color(0xFFE5EDF4),RoundedCornerShape(5.dp)).padding(3.dp),fontSize=10.sp,color=Navy)
                    }
                    HorizontalDivider(color=Color(0xFFE2E9ED))
                }
            }
            if (selectedClass.isBlank()) TextButton(onClick={go()},modifier=Modifier.fillMaxWidth()) { Text("عرض جميع النتائج (${results.size})",fontFamily=font,color=Navy,fontSize=12.sp) }
        }
    }
    }
}

@Composable
private fun HomeAlerts(dao:SchoolDao,year:String,open:(String)->Unit) {
    val records by remember(year){dao.conduct(year)}.collectAsState(emptyList())
    val slips by remember(year){dao.slipRows(year,"","")}.collectAsState(emptyList())
    val pending=records.filter { it.kind=="مخالفات" && !it.closed }
    val repeated=slips.filter { it.reason=="غياب" }.distinctBy { it.id to it.massar }.groupBy { it.massar }.values.filter { it.size>=3 }
    var show by remember { mutableStateOf(false) }
    val count=pending.size+repeated.size
    Box {
        IconButton(onClick={show=true}) { Icon(Icons.Default.Notifications,"التنبيهات",tint=Color.White) }
        if(count>0) Text(count.toString(),Modifier.align(Alignment.TopEnd).background(Color(0xFFD84343),CircleShape).padding(horizontal=5.dp),color=Color.White,fontSize=10.sp)
    }
    if(show) AlertDialog(onDismissRequest={show=false},title={Text("التنبيهات")},text={
        Column(Modifier.heightIn(max=360.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            if(count==0) Text("لا توجد تنبيهات")
            pending.forEach { r -> TextButton(onClick={show=false;open("conduct")}) { Text("مخالفة قيد المعالجة • "+r.studentName+" • "+r.section) } }
            repeated.forEach { rs -> TextButton(onClick={show=false;open("slips")}) { Text("غياب متكرر • "+rs.first().displayName+" • "+rs.size+" غيابات") } }
        }
    },confirmButton={TextButton(onClick={show=false}){Text("إغلاق")}})
}

@Composable
private fun QuickActions(font: androidx.compose.ui.text.font.FontFamily, open: (String) -> Unit) {
    var other by rememberSaveable { mutableStateOf(false) }
    if(other) AlertDialog(onDismissRequest={other=false},title={Text("تسجيل آخر")},text={Column { listOf("إعفاء من التربية البدنية" to "quickPe","نقل إلى المستشفى" to "quickHospital","تسجيل التزام سلوك" to "quickBehavior","تسجيل التزام غياب" to "quickAbsence").forEach { (label,route) -> Card(onClick={other=false;open(route)},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFF0F5F7)),shape=RoundedCornerShape(12.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){Icon(when(route){"quickPe"->Icons.Default.Favorite;"quickHospital"->Icons.Default.LocalHospital;"quickBehavior"->Icons.Default.EditNote;else->Icons.Default.CalendarMonth},null,tint=Teal);Text(label,color=Navy,fontSize=13.sp)}} } }},confirmButton={TextButton(onClick={other=false}){Text("إلغاء")}})
    Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("إجراءات سريعة", color = Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = font, modifier = Modifier.padding(horizontal = 2.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickButton("تسجيل الغياب", Icons.Default.CheckCircle, true, font, Modifier.weight(1f)) { open("slips") }
            QuickButton("إضافة مخالفة", Icons.Default.Warning, false, font, Modifier.weight(1f)) { open("quickIncident") }
            QuickButton("تسجيل آخر", Icons.Default.Schedule, false, font, Modifier.weight(1f)) { other=true }
        }
    }
}

@Composable
private fun QuickButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, primary: Boolean, font: androidx.compose.ui.text.font.FontFamily, modifier: Modifier, onClick: () -> Unit) {
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val bg = if (primary) Color(0xFF11678B) else Color.White
    val fg = if (primary) Color.White else Navy
    Column(modifier.pressScale(src).height(62.dp).clip(RoundedCornerShape(16.dp)).background(bg)
        .border(1.dp, if (primary) bg else Color(0xFFDFE9EC), RoundedCornerShape(16.dp))
        .clickable(interactionSource = src, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(22.dp))
        Text(label, color = fg, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = font, maxLines = 1)
    }
}

@Composable
private fun animatedCount(target: Int): Int {
    val a = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(target) { a.animateTo(target.toFloat(), androidx.compose.animation.core.tween(900)) }
    return a.value.toInt()
}

private data class HomeTile(val title: String, val subtitle: String, val route: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val color: Color)

@Composable
private fun HomeStat(label: String, count: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, background: Color, modifier: Modifier, scale: Float = 1f) {
    Card(modifier = modifier.heightIn(min = (72 * scale).dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = background), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Column(Modifier.fillMaxWidth().heightIn(min = (72 * scale).dp).padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(animatedCount(count).toString(), fontSize = (23 * scale).sp, color = accent, fontWeight = FontWeight.Black)
            Text(label, fontSize = 10.sp, color = Color(0xFF111D30), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}

@Composable
internal fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier.heightIn(min = 60.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 22.sp, color = Teal, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 11.sp, color = Color(0xFF627484), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun StudentsScreen(updateRoster:()->Unit,dao:SchoolDao,year:String,profileSearch: Boolean, rows: List<StudentListRow>, classes: List<ClassSummary>, section: String, members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>, onSection: (String) -> Unit, query: String, onSearch: (String) -> Unit, onStudent: (StudentListRow) -> Unit, onBack: () -> Unit) {
    var level by rememberSaveable { mutableStateOf("") }
    val movements by remember(year){dao.movements(year)}.collectAsState(initial=emptyList())
    val byCode=remember(movements){movements.groupBy {it.massar}}
    val additional=if(query.isBlank()) emptyList() else byCode.values.mapNotNull { events ->
        val m=events.first()
        val q=query.trim()
        if(m.massar.contains(q,true) || m.fullName.contains(q,true) || m.ordinal?.toString()==q)
            StudentListRow(m.massar,"",m.fullName,"","",null,m.level,m.section,m.ordinal)
        else null
    }
    val sections = classes.filter { level.isEmpty() || it.levelName == level }.map { it.className }.distinct().sorted()
    val visible = (rows+additional).distinctBy { it.massarCode }.filter { (level.isEmpty() || it.levelName == level) && (section.isEmpty() || it.className == section) }

    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle(if (profileSearch) "بطاقة التلميذ" else "لائحة التلاميذ", onBack)
        OutlinedButton(onClick=updateRoster){Text("تحيين لائحة التلاميذ")}
        val total=classes.sumOf { it.studentCount }
        Text("إجمالي التلاميذ: $total"+if(query.isNotBlank() || section.isNotBlank() || level.isNotBlank()) "    •    نتائج البحث: ${visible.size}" else "",
            style=MaterialTheme.typography.labelLarge,color=Navy)
        SearchBox(query,onSearch,"الاسم أو رمز مسار أو الرقم الترتيبي")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RosterFilter("حسب المستوى", level, classes.map { it.levelName }.filter { it.isNotBlank() }.distinct().sorted(), Modifier.weight(1f)) {
                level = it
                onSection("")
            }
            RosterFilter("حسب القسم", section, sections, Modifier.weight(1f)) { onSection(it) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (!profileSearch && section.isNotBlank()) {
                item { ClassOverview(members.filter { it.className == section }, assignments.filter { it.className == section }) }
            }
            if (visible.isEmpty()) item { EmptyCard("لا يوجد تلاميذ ضمن هذا الاختيار.") }
            items(visible, key = { it.massarCode }) { student ->
                StudentResult(student,byCode[student.massarCode].orEmpty().map { when(it.kind){
                    "ARRIVAL" -> "وافد"
                    "DEPARTURE" -> "مغادر"
                    "DROPOUT" -> "منقطع"
                    else -> "غير ملتحق"
                } }.distinct().joinToString(" • ")) { onStudent(student) }
            }
        }
    }

}

@Composable
private fun ClassesScreen(classes: List<ClassSummary>, selected: String, members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>, onSelect: (String) -> Unit, onStudent: (StudentListRow) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle(if (selected.isBlank()) "الأقسام والمستويات" else selected, onBack)
        if (selected.isNotBlank()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item { ClassOverview(members.filter { it.className == selected }, assignments.filter { it.className == selected }) }
                item { Text("لائحة التلاميذ", color = Navy, fontWeight = FontWeight.Bold) }
                items(members, key = { it.massarCode }) { student ->
                    StudentResult(student) { onStudent(student) }
                }
            }
        } else if (classes.isEmpty()) {
            EmptyCard("ستظهر الأقسام تلقائياً بعد استيراد ملف التلاميذ.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("الأقسام: "+classes.size+"   •   المستويات: "+classes.distinctBy { it.levelName }.size) }
                classes.groupBy { it.levelName }.forEach { (level, levelClasses) ->
                    item { Text(level, fontWeight = FontWeight.Bold, color = Teal, modifier = Modifier.padding(top = 6.dp)) }
                    items(levelClasses, key = { it.className }) { summary ->
                    Card(Modifier.fillMaxWidth().clickable { onSelect(summary.className) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(summary.className, color = Navy, fontWeight = FontWeight.SemiBold)
                            Text("${summary.studentCount} تلميذاً", color = Color(0xFF627484), fontSize = 12.sp)
                        }
                    }
                    }
                }
            }
        }
    }
}

@Composable
private fun StaffScreen(employees: List<EmployeeEntity>, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf<EmployeeEntity?>(null) }
    chosen?.let { e ->
        BackHandler { chosen = null }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PageTitle("بطاقة الموظف") { chosen = null }
            ProfileHeading(e.nameArabic.ifBlank { e.nameFrench }, e.nameFrench)
            EmployeeTaskField(e.ppr)
            ProfilePhones(listOf("الهاتف المحمول" to e.mobile, "الهاتف الثابت" to e.landline))
            ProfileGrid("الملف المهني", listOf("رقم التأجير" to e.ppr, "المادة" to (e.disciplineLabelArabic ?: e.disciplineLabelFrench),
                "الإطار" to e.cadreLabel, "الدرجة" to e.gradeLabel, "الرتبة" to e.echelon, "الوضعية" to e.statusLabel,
                "الوضع الإداري" to e.positionLabel, "الوظيفة" to e.functionLabel, "تاريخ التوظيف" to e.recruitmentDate,
                "تاريخ الترسيم" to e.titularizationDate, "الجنس" to e.gender))
            ProfileGrid("العنوان", listOf("المدينة" to e.city, "عنوان السكن" to e.address))
            var showId by remember(e.ppr) { mutableStateOf(false) }
            OutlinedButton(onClick={showId=!showId},enabled=!e.nationalId.isNullOrBlank()) {
                Text(if(e.nationalId.isNullOrBlank()) "رقم البطاقة غير متوفر" else if(showId) "إخفاء رقم البطاقة" else "إظهار رقم البطاقة الوطنية")
            }
            if(showId) Text(e.nationalId.orEmpty())
        }
        return
    }
    val filtered = employees.filter {
        query.isBlank() || it.ppr.contains(query, true) || it.nameArabic.contains(query, true) ||
            it.nameFrench.contains(query, true) || it.disciplineLabelArabic.orEmpty().contains(query, true) ||
            it.disciplineLabelFrench.orEmpty().contains(query, true)
    }
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("الأساتذة والموظفون", onBack)
        Text("عدد السجلات: ${employees.size}", color = Teal, fontWeight = FontWeight.SemiBold)
        SearchBox(query,{query=it},"الاسم أو رقم التأجير أو المادة")
        if (employees.isEmpty()) EmptyCard("استورد ملف الموارد البشرية من الإعدادات لعرض الموظفين.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.ppr }) { employee ->
                Card(modifier = Modifier.clickable { chosen = employee }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(employee.nameArabic.ifBlank { employee.nameFrench }, color = Navy, fontWeight = FontWeight.Bold)
                        Text("PPR: ${employee.ppr}", color = Color(0xFF627484), fontSize = 11.sp)
                        val discipline = employee.disciplineLabelArabic ?: employee.disciplineLabelFrench
                        if (!discipline.isNullOrBlank()) Text("المادة/التخصص: $discipline", color = Teal, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun TeachingScreen(assignments: List<TeacherAssignmentEntity>, employees:List<EmployeeEntity>, rename:(String,String)->Unit, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf("") }
    var editing by remember { mutableStateOf<TeacherAssignmentEntity?>(null) }
    var name by rememberSaveable { mutableStateOf("") }
    editing?.let { row ->
        AlertDialog(onDismissRequest={editing=null},title={Text("تسمية الأستاذ")},text={
            Column {
                OutlinedTextField(name,{name=it},label={Text("الاسم المعروض")})
                RosterFilter("اختر من لائحة الأساتذة","",employees.map { it.nameArabic.ifBlank { it.nameFrench } }.filter { it.isNotBlank() }.distinct(),Modifier.fillMaxWidth()){if(it.isNotBlank())name=it}
            }
        },confirmButton={Button(enabled=name.isNotBlank(),onClick={rename(row.teacherCode,name.trim());editing=null}){Text("حفظ")}},
        dismissButton={androidx.compose.material3.TextButton(onClick={editing=null}){Text("إلغاء")}})
    }
    var subject by rememberSaveable { mutableStateOf("") }
    val matches=assignments.filter {
        (section.isEmpty() || it.className==section) && (subject.isEmpty() || it.subjectName==subject) &&
            listOf(it.teacherName,it.subjectName,it.className).any { label -> label.contains(query.trim(),true) }
    }
    Column(Modifier.fillMaxSize().padding(pageInset()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        PageTitle("توزيع الأقسام على الأساتذة",onBack)
        Text("الأساتذة: "+matches.distinctBy { it.teacherCode }.size+"   •   الأقسام: "+matches.distinctBy { it.className }.size)
        SearchBox(query,{query=it},"اسم الأستاذ أو المادة أو القسم")
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            RosterFilter("حسب القسم",section,assignments.filter { subject.isEmpty() || it.subjectName==subject }.map { it.className }.distinct().sorted(),Modifier.weight(1f)){section=it}
            RosterFilter("حسب المادة",subject,assignments.filter { section.isEmpty() || it.className==section }.map { it.subjectName }.distinct().sorted(),Modifier.weight(1f)){subject=it}
        }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            if(matches.isEmpty()) item { EmptyCard("لا توجد إسنادات ضمن هذا الاختيار") }
            items(matches.groupBy { it.teacherCode to it.subjectName }.values.sortedWith(compareBy({ arabicConductSubject(it.first().subjectName) }, { it.first().teacherName })),key={it.first().teacherCode+"|"+it.first().subjectName}) { records ->
                val first=records.first()
                Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal=10.dp),verticalAlignment=Alignment.CenterVertically) {
                        Text(first.teacherName,Modifier.weight(1f),fontWeight=FontWeight.Bold,color=Navy)
                        Text(records.map { arabicConductSubject(it.subjectName) }.distinct().joinToString("، "),Modifier.weight(0.8f),color=Teal,fontSize=13.sp)
                        IconButton(onClick={editing=first;name=first.teacherName}) {Icon(Icons.Default.Edit,"تعديل اسم الأستاذ")}
                    }
                    FlowRow(Modifier.padding(start=12.dp,end=12.dp,bottom=10.dp),horizontalArrangement=Arrangement.spacedBy(5.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        records.map { it.className }.distinct().sorted().forEach {
                            Text(it,Modifier.background(Pale,RoundedCornerShape(8.dp)).padding(horizontal=7.dp,vertical=3.dp),fontSize=12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatisticsScreen(
    dao: SchoolDao,
    counts: DashboardCounts,
    year: String,
    students: List<StudentListRow>,
    employees: List<EmployeeEntity>,
    services: List<EmployeeServiceEntity>,
    onInstitution: () -> Unit,
    onBack: () -> Unit
) {
    val movements by remember(year){dao.movements(year)}.collectAsState(emptyList())
    val pe by remember(year){dao.watchSetting("health.$year.الإعفاء من التربية البدنية")}.collectAsState(null)
    val hospital by remember(year){dao.watchSetting("health.$year.نقل التلميذ إلى المستشفى")}.collectAsState(null)
    fun rows(raw:String?):List<org.json.JSONObject> = runCatching { val a=org.json.JSONArray(raw ?: "[]"); (0 until a.length()).map { a.getJSONObject(it) } }.getOrDefault(emptyList())
    val exemptions=rows(pe).distinctBy { it.optString("massar") }
    val transfers=rows(hospital)
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        PageTitle("الإحصائيات",onBack)
        Button(onClick=onInstitution,modifier=Modifier.fillMaxWidth()){Text("معلومات المؤسسة")}
        Text("الموسم الدراسي $year",color=Navy,fontSize=12.sp)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { ConductStatistics(dao,year) }
            item { MetricGroup("حركية التلاميذ",MovementKind.entries.map { k -> k.label to movements.filter { it.kind==k.name }.distinctBy { it.massar }.size },Color(0xFF16856D)) }
            item { MetricGroup("الإعفاء من التربية البدنية",listOf("المجموع" to exemptions.size,"الإناث" to exemptions.count { it.optString("gender").isFemaleValue() },"الذكور" to exemptions.count { it.optString("gender").isMaleValue() }),Color(0xFF148FA3)) }
            item { MetricGroup("النقل إلى المستشفى",listOf("عدد التلاميذ" to transfers.distinctBy { it.optString("massar") }.size,"الإناث" to transfers.filter { it.optString("gender").isFemaleValue() }.distinctBy { it.optString("massar") }.size),Color(0xFFB65D45)) }
        }
    }
}

@Composable
internal fun MetricGroup(title:String,metrics:List<Pair<String,Int>>,accent:Color=Color(0xFF11678B)) {
    Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Text(title,color=Navy,fontWeight=FontWeight.Bold,fontSize=15.sp)
            metrics.chunked(2).forEach { pair -> Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                pair.forEach { (label,value) -> Column(Modifier.weight(1f).background(accent.copy(alpha=0.08f),RoundedCornerShape(10.dp)).padding(8.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                    Text(value.toString(),color=accent,fontWeight=FontWeight.Bold,fontSize=23.sp)
                    Text(label,color=Navy,fontSize=11.sp,textAlign=TextAlign.Center)
                } }
                if(pair.size==1) Spacer(Modifier.weight(1f))
            } }
        }
    }
}

internal fun String.isFemaleValue(): Boolean = trim().lowercase() in setOf("أنثى", "انثى", "f", "féminin", "feminin", "female")
internal fun String.isMaleValue(): Boolean = trim().lowercase() in setOf("ذكر", "m", "masculin", "male")
private fun percentage(value: Int, total: Int): String = if (total == 0) "0%" else "${(value * 100.0 / total).let { String.format(java.util.Locale.ROOT, "%.1f", it) }}%"

@Composable
private fun StatLine(label: String, value: Int, maxValue: Int) {
    val fraction = if (maxValue <= 0) 0f else (value.toFloat() / maxValue).coerceIn(0f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = Ink, modifier = Modifier.weight(1f))
            Text(value.toString(), fontSize = 12.sp, color = Teal, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0xFFE4EBF0), RoundedCornerShape(8.dp))) {
            Box(Modifier.fillMaxWidth(fraction).height(6.dp).background(Teal, RoundedCornerShape(8.dp)))
        }
    }
}

@Composable
private fun FitSchoolName(name:String,color:Color,size:androidx.compose.ui.unit.TextUnit,font:androidx.compose.ui.text.font.FontFamily?=null) {
    androidx.compose.foundation.text.BasicText(name,Modifier.fillMaxWidth(),style=androidx.compose.ui.text.TextStyle(
        color=color,fontSize=size,fontFamily=font,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center),
        maxLines=1,softWrap=false,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        autoSize=androidx.compose.foundation.text.TextAutoSize.StepBased(minFontSize=9.sp,maxFontSize=size,stepSize=0.5.sp))
}

@Composable
private fun SettingsRow(label:String,detail:String,icon:androidx.compose.ui.graphics.vector.ImageVector,enabled:Boolean=true,click:()->Unit) {
    Row(Modifier.fillMaxWidth().clickable(enabled=enabled,onClick=click).padding(12.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
        Box(Modifier.size(38.dp).background(Color(0xFFE6F4EF),RoundedCornerShape(10.dp)),contentAlignment=Alignment.Center){
            Icon(icon,null,tint=Teal)
        }
        Column(Modifier.weight(1f)){
            Text(label,color=Navy,fontWeight=FontWeight.Bold)
            if(detail.isNotBlank()) Text(detail,color=Color(0xFF556C79),fontSize=12.sp)
        }
        Icon(Icons.Default.ChevronLeft,null,tint=Teal)
    }
}

@Composable
private fun SettingsScreen(
    counts: DashboardCounts,
    schoolName: String,
    schoolLevel: String,
    onSchoolLevel: (String) -> Unit,
    onSchoolName: (String) -> Unit,
    province: String,
    onProvince: (String) -> Unit,
    academy: String,
    onAcademy: (String) -> Unit,
    schoolYear: String,
    availableYears: List<String>,
    onSchoolYear: (String) -> Unit,
    onImport: (ImportType) -> Unit,
    onBackupExport: () -> Unit,
    onBackupImport: () -> Unit,
    movementImport: @Composable () -> Unit,
    timetableImport: @Composable () -> Unit,
    onFamily: () -> Unit,
    onGuardianExport: () -> Unit,
    error: String,
    status: String,
    isLoading: Boolean,
    onBack: () -> Unit
) {
    var section by rememberSaveable { mutableStateOf("") }
    val imports=listOf("معلومات التلاميذ","حركية التلاميذ","استعمال الزمن","الموظفون","توزيع الأساتذة")
    fun closeSection(){
        if(section in imports)section="استيراد البيانات" else if(section.isNotBlank())section="" else onBack()
    }
    BackHandler(enabled=section.isNotBlank()){closeSection()}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pageInset()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Navy,Color(0xFF11678B))),RoundedCornerShape(20.dp)).padding(12.dp),
            horizontalAlignment=Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick=::closeSection){Icon(Icons.AutoMirrored.Filled.ArrowBack,"رجوع",tint=Color.White)}
                Image(painterResource(R.drawable.moasasati_foreground),"شعار مؤسستي",Modifier.size(34.dp))
                Text("مؤسستي",Modifier.padding(horizontal=6.dp),color=Color.White,fontWeight=FontWeight.Bold)
            }
            Text(section.ifBlank {"الإعدادات"},color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Bold)
            FitSchoolName(schoolName,Color.White,16.sp)
        }
        if(section.isEmpty()){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                for(importing in listOf(true,false)){
                    val label=if(importing)"استيراد البيانات" else "تصدير البيانات"
                    val tint=if(importing)Color.White else Navy
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if(importing)Teal else Color(0xFFD5EEF9))
                        .clickable { if(importing)section=label else onGuardianExport() }.padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally){
                        Icon(if(importing)Icons.Default.FileDownload else Icons.Default.FileUpload,null,tint=tint)
                        Text(label,color=tint,fontWeight=FontWeight.Bold)
                    }
                }
            }
            Text("المؤسسة",color=Navy,fontWeight=FontWeight.Bold)
            Column(Modifier.background(Color.White,RoundedCornerShape(16.dp))){
                SettingsRow("بيانات المؤسسة","الاسم والمديرية والأكاديمية",Icons.Default.Apartment){section="معلومات المؤسسة"}
                HorizontalDivider()
                SettingsRow("الموسم الدراسي",schoolYear,Icons.Default.CalendarMonth){section="الموسم الدراسي"}
            }
            Text("النسخ الاحتياطي",color=Navy,fontWeight=FontWeight.Bold)
            Column(Modifier.background(Color.White,RoundedCornerShape(16.dp))){
                SettingsRow("حفظ نسخة احتياطية","",Icons.Default.Save,!isLoading,onBackupExport)
                HorizontalDivider()
                SettingsRow("استعادة نسخة احتياطية","استبدال البيانات من ملف محفوظ",Icons.Default.Restore,!isLoading,onBackupImport)
            }
        }
        if(section=="استيراد البيانات"){
            Column(Modifier.background(Color.White,RoundedCornerShape(16.dp))){
                imports.forEachIndexed {i,label->
                    SettingsRow(label,"",Icons.Default.FolderOpen,!isLoading){section=label}
                    if(i<imports.lastIndex) HorizontalDivider()
                }
            }
        }
        when (section) {
            "معلومات المؤسسة" -> {
        InstitutionPeopleFields()
        OutlinedTextField(value = schoolName, onValueChange = onSchoolName, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المؤسسة") }, singleLine = true)
        Text("السلك التعليمي", fontWeight = FontWeight.Bold, color = Navy)
        listOf("التعليم الابتدائي", "الثانوي الإعدادي", "الثانوي التأهيلي").forEach { level ->
            Row(Modifier.fillMaxWidth().clickable { onSchoolLevel(level) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = schoolLevel == level, onClick = { onSchoolLevel(level) })
                Text(level, color = Navy)
            }
        }
        Text("يمكن تغيير اسم المؤسسة والسلك دون تغيير تصميم الواجهة.", color = Teal, fontSize = 12.sp)
        OutlinedTextField(value = province, onValueChange = onProvince, modifier = Modifier.fillMaxWidth(), label = { Text("المديرية الإقليمية") }, singleLine = true)
        OutlinedTextField(value = academy, onValueChange = onAcademy, modifier = Modifier.fillMaxWidth(), label = { Text("الأكاديمية الجهوية") }, singleLine = true)
            }
            "الموسم الدراسي" -> {
                var draft by rememberSaveable(schoolYear) { mutableStateOf(schoolYear) }
                Text("الموسم النشط: $schoolYear", color=Teal, fontWeight=FontWeight.Bold)
                (availableYears+schoolYear).distinct().sortedDescending().forEach { year ->
                    Row(Modifier.fillMaxWidth().clickable(enabled=!isLoading) { draft=year },verticalAlignment=Alignment.CenterVertically) {
                        RadioButton(selected=draft==year,onClick={draft=year},enabled=!isLoading)
                        Text(year)
                    }
                }
                OutlinedTextField(value=draft,onValueChange={draft=it},modifier=Modifier.fillMaxWidth(),label={Text("الموسم الدراسي")},singleLine=true,enabled=!isLoading,isError=AcademicSeason.parse(draft)==null)
                Button(enabled=!isLoading && AcademicSeason.parse(draft)!=null && draft!=schoolYear,onClick={onSchoolYear(draft)},modifier=Modifier.fillMaxWidth()){Text("اعتماد الموسم الدراسي")}
                Text("يمكن اختيار موسم محفوظ أو إضافة موسم جديد. لا تُحذف بيانات المواسم السابقة.",color=Teal,fontSize=12.sp)
            }
            "معلومات التلاميذ" -> {
                ImportButton("استيراد لائحة التلاميذ", "XLSX • الاستيراد الأولي أو اللائحة المحينة", !isLoading) { onImport(ImportType.STUDENTS) }
                ImportButton("أولياء الأمور — Excel", "ملف أو عدة ملفات أقسام", !isLoading, onFamily)
            }
            "حركية التلاميذ" -> {
                Text("تُكتشف التغييرات تلقائياً عند استيراد لائحة التلاميذ المحينة.", fontSize = 12.sp, color = Teal)
                movementImport()
            }
            "استعمال الزمن" -> timetableImport()
            "الموظفون" -> ImportButton("لائحة الموظفين — XML", "البيانات الإدارية", !isLoading) { onImport(ImportType.EMPLOYEES) }
            "توزيع الأساتذة" -> ImportButton("مستخرج حصص الأساتذة — Excel", "XLSX • المادة والقسم", !isLoading) { onImport(ImportType.TEACHING) }

        }
        if (isLoading) Text("جارٍ تحليل الملف…", color = Teal, fontWeight = FontWeight.SemiBold)
        if (error.isNotBlank()) Text(error, color = Color(0xFFB3261E), fontSize = 13.sp)
        if (status.isNotBlank()) Text(status, color = Teal, fontSize = 13.sp)
        Text("تُحفظ البيانات محلياً على الجهاز. لن تُعتمد أي تغييرات قبل مراجعة المعاينة.", color = Color(0xFF627484), fontSize = 12.sp)
    }
}

@Composable
private fun ImportButton(title: String, subtitle: String, enabled: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Navy, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color(0xFF627484), fontSize = 11.sp)
        }
    }
}

@Composable
private fun ImportPreviewDialog(review: ImportReview, busy: Boolean, choices: MutableMap<String,String>, activeYear:String, error:String, onYearChange:(String)->Unit, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    val targetYear=when(review){is ImportReview.Students->review.plan.schoolYear;is ImportReview.Teaching->review.plan.schoolYear;else->null}
    var draft by remember(targetYear,review.fileName){mutableStateOf(targetYear.orEmpty())}
    val yearReady=targetYear==null || (AcademicSeason.parse(targetYear)!=null && AcademicSeason.parse(draft)==AcademicSeason.parse(targetYear))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("معاينة الاستيراد", color = Navy, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الملف: ${review.fileName}", color = Color(0xFF627484), fontSize = 12.sp)
                if(targetYear!=null){
                    Text("الموسم النشط: $activeYear",color=Teal)
                    OutlinedTextField(value=draft,onValueChange={draft=it},label={Text("موسم الاستيراد")},singleLine=true,enabled=!busy,isError=AcademicSeason.parse(draft)==null,modifier=Modifier.fillMaxWidth())
                    OutlinedButton(enabled=!busy && AcademicSeason.parse(draft)!=null && AcademicSeason.parse(draft)!=AcademicSeason.parse(targetYear),onClick={onYearChange(draft)}){Text("تحديث المعاينة")}
                    if(!yearReady) Text("حدد الموسم الصحيح وحدّث المعاينة قبل الحفظ.",color=Color(0xFFB3261E))
                    if(targetYear!=activeYear) Text("لن يتغير الموسم النشط عند استيراد هذا الملف.",color=Teal,fontSize=12.sp)
                }
                if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
                when (review) {
                    is ImportReview.Students -> {
                        Text("الموسم الدراسي: ${review.plan.schoolYear}")
                        Text("الأوراق/الأقسام: ${review.plan.sectionCount}")
                        Text("التلاميذ المقروءون: ${review.plan.students.size}")
                        Text("جدد: ${review.diff.newStudents} • تحديث بيانات: ${review.diff.updatedProfiles}")
                        Text("انتقال بين الأقسام: ${review.diff.sectionTransfers} • دون تغيير: ${review.diff.unchangedStudents}")
                        review.diff.transferDetails.forEach { transfer ->
                            Text("${transfer.massarCode}: ${transfer.oldClass} ← ${transfer.newClass}", color = Teal, fontSize = 12.sp)
                        }
                        Text("موجودون سابقاً وغير واردين في هذا الملف: ${review.diff.notInNewFile} — تحفظ ملفاتهم في الأرشيف")
                        review.diff.changes.filter { it.kind != "CLASS_CHANGE" }.forEach { m ->
                            Text(m.fullName+" • "+m.section+" • "+m.massar)
                            val options=if(m.kind=="ARRIVAL") listOf("ARRIVAL" to "وافد","RETURN" to "مرجع") else listOf("DEPARTURE" to "مغادر","NON_ATTENDANCE" to "غير ملتحق","DROPOUT" to "منقطع")
                            options.forEach { (code,label) -> Row(verticalAlignment=Alignment.CenterVertically) { RadioButton(selected=choices[m.massar]==code,onClick={choices[m.massar]=code});Text(label) } }
                        }
                        Text("المؤسسة: ${review.plan.institution.orEmpty()}")
                    }
                    is ImportReview.Employees -> {
                        Text("الموظفون: ${review.plan.employees.size}")
                        Text("جدد: ${review.diff.newEmployees} • تحديثات: ${review.diff.updatedEmployees} • دون تغيير: ${review.diff.unchangedEmployees}")
                        Text("موظفون سابقون غير واردين في هذا الملف: ${review.diff.notInNewFile} (سيبقون محفوظين كبيانات سابقة)")
                        Text("جداول مرجعية: ${review.plan.referenceValues.size} • سجلات الأنشطة: ${review.plan.activityCount}")
                        Text("صفوف الخدمات: ${review.plan.serviceRecordCount} • موظفون مرتبطون بها: ${review.plan.employeesWithServiceRows} • دون صفوف مطابقة: ${review.plan.employeesWithoutServiceRows}")
                        Text("لن تُستورد أرقام الهوية والعناوين وأرقام الاتصال في هذه النسخة.", color = Teal, fontSize = 12.sp)
                    }
                    is ImportReview.Teaching -> {
                        Text("الموسم الدراسي: ${review.plan.schoolYear}")
                        Text("الأقسام: ${review.plan.sectionCount} • أعمدة المجموعات: ${review.plan.subgroupCount}")
                        Text("المواد: ${review.plan.subjectCount} • معرفات الأساتذة: ${review.plan.teacherCount}")
                        Text("إسنادات المادة والقسم/المجموعة: ${review.plan.assignments.size}")
                        Text("مجموع القيم المقروءة: ${review.plan.statedLessonTotal}")
                        Text("جديدة: ${review.diff.newAssignments} • متغيرة: ${review.diff.changedAssignments} • دون تغيير: ${review.diff.unchangedAssignments}")
                        Text("غير واردة في الملف الجديد: ${review.diff.noLongerListed} (ستُحفظ كسجلات غير حالية)")
                    }
                }
                val warnings = when (review) {
                    is ImportReview.Students -> review.plan.warnings
                    is ImportReview.Employees -> review.plan.warnings
                    is ImportReview.Teaching -> review.plan.warnings
                }
                if (warnings.isNotEmpty()) {
                    Text("ملاحظات (${warnings.size})", color = Color(0xFFB26A00), fontWeight = FontWeight.Bold)
                    warnings.take(8).forEach { Text("• $it", fontSize = 12.sp, color = Color(0xFF6B5A3C)) }
                    if (warnings.size > 8) Text("… وهناك ${warnings.size - 8} ملاحظات أخرى.", fontSize = 12.sp)
                }
            }
        },
        confirmButton = { Button(onClick = onConfirm, enabled = !busy && yearReady && (review !is ImportReview.Students || review.diff.changes.filter { it.kind != "CLASS_CHANGE" }.all { it.massar in choices })) { Text(if (busy) "جارٍ الحفظ…" else "تأكيد الاستيراد") } },
        dismissButton = { OutlinedButton(onClick = onDismiss, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
internal fun PageTitle(title: String, onBack: () -> Unit) {
    val brush=Brush.horizontalGradient(listOf(Color(0xFF093853), Color(0xFF11678B)))
    Box(Modifier.fillMaxWidth().background(brush,RoundedCornerShape(18.dp))) {
        Text(title,Modifier.align(Alignment.Center).padding(horizontal=44.dp,vertical=12.dp),color=Color.White,
            fontWeight=FontWeight.Bold,fontSize=19.sp,textAlign=TextAlign.Center)
        IconButton(onClick=onBack,modifier=Modifier.align(Alignment.CenterEnd)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack,"رجوع",tint=Color.White)
        }
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Text(message, Modifier.fillMaxWidth().padding(18.dp), color = Color(0xFF526777), fontSize = 14.sp, lineHeight = 22.sp)
    }
}

@Composable
internal fun RosterFilter(all: String, selected: String, options: List<String>, modifier: Modifier, select: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected.ifEmpty { all } + " ▾", maxLines = 2)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            (listOf("") + options).forEach { option ->
                DropdownMenuItem(text = { Text(option.ifEmpty { all }) }, onClick = {
                    select(option)
                    expanded = false
                })
            }
        }
    }
}

@Composable
private fun ClassOverview(members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>) {
    val girls = members.count { it.gender.isFemaleValue() }
    val boys = members.count { it.gender.isMaleValue() }
    val unknown = members.size - girls - boys
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            SummaryCard("التلاميذ", members.size.toString(), Modifier.weight(1f))
            SummaryCard("الإناث", girls.toString(), Modifier.weight(1f))
            SummaryCard("الذكور", boys.toString(), Modifier.weight(1f))
        }
        if (unknown > 0) Text("جنس غير محدد: $unknown", fontSize = 12.sp)
        Text("المواد والأساتذة", color = Navy, fontWeight = FontWeight.Bold)
        if (assignments.isEmpty()) Text("لا توجد إسنادات لهذا القسم. يمكن استيراد مستخرج الحصص من الإعدادات.", fontSize = 13.sp)
        androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
            val columns = ((maxWidth.value + 8f) / 158f).toInt().coerceIn(1, 6)
            val subjects = assignments.groupBy { it.subjectName }.toList()
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                subjects.chunked(columns).forEach { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        line.forEach { (subject, lessons) ->
                            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(subject, color = Navy, fontWeight = FontWeight.SemiBold)
                                    lessons.distinctBy { it.teacherCode }.forEach { lesson ->
                                        Text(lesson.teacherName, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                        repeat(columns - line.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun pageInset() = if (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp <= 360) 10.dp else 14.dp

@Composable
private fun FamilyProfile(dao:SchoolDao,year:String,student: StudentListRow, contacts: List<FamilyContact>, onSchedule:()->Unit, back: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pageInset()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PageTitle("بطاقة التلميذ", back)
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StudentAvatar(student.massarCode,editable=true)
            Box(Modifier.weight(1f)){ProfileHeading(student.givenName+" "+student.surname, student.className+"   •   "+student.levelName)}
        }
        val roles = listOf("الأب","الأم")
        val scope=rememberCoroutineScope()
        var roleEdit by rememberSaveable(student.massarCode){mutableStateOf("")}
        var number by rememberSaveable(student.massarCode){mutableStateOf("")}
        var failure by remember { mutableStateOf("") }
        fun editPhone(role:String,initial:String) { roleEdit=role;number=initial;failure="" }
        ProfilePhones(roles.map { role -> "هاتف $role" to contacts.find { it.role==role }?.phone }) { index -> editPhone(roles[index],contacts.find { it.role==roles[index] }?.phone.orEmpty()) }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
            Column { Text("رمز مسار", color=Teal); Text(student.massarCode,fontWeight=FontWeight.Bold) }
            IconButton(onClick={
                val clipboard=context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("مسار",student.massarCode))
                if(android.os.Build.VERSION.SDK_INT<33) android.widget.Toast.makeText(context,"تم نسخ رمز مسار",android.widget.Toast.LENGTH_SHORT).show()
            }) { Icon(Icons.Default.ContentCopy, contentDescription="نسخ رمز مسار", tint=Teal) }
        }
        ProfileGrid("المعلومات الشخصية", listOf("الرقم الترتيبي" to student.ordinal?.toString(),"الجنس" to student.gender,
            "تاريخ الازدياد" to student.birthDate,"مكان الازدياد" to student.birthPlace))
        val history by remember(year,student.massarCode) { dao.studentMovements(year,student.massarCode) }.collectAsState(initial=emptyList())
        if(history.isNotEmpty()) {
            Text("حركية التلميذ",fontWeight=FontWeight.Bold,color=Navy)
            history.forEach { movement ->
                if(movement.kind=="ARRIVAL") {
                    Text("المؤسسة الأصلية: "+movement.origin.ifBlank {"غير متوفر"})
                    Text("تاريخ الالتحاق بالمؤسسة: "+movement.eventDate.ifBlank {"غير متوفر"})
                }
                Text(listOf(ma.salah.eddine.schoolmanager.importing.MovementKind.valueOf(movement.kind).label,movement.eventDate,movement.level)
                    .filter(String::isNotBlank).joinToString("  •  "))
            }
        }
        OutlinedButton(onClick=onSchedule) { Text("استعمال زمن القسم") }
        ProfileCells(roles.size) { index ->
            val role=roles[index]
            val contact = contacts.find { it.role == role }
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(role, color = Teal, fontWeight = FontWeight.Bold)
                    Text("اسم $role: ${contact?.name.orEmpty().ifBlank { "غير متوفر" }}")
                    Text("عنوان $role: ${contact?.address.orEmpty().ifBlank { "غير متوفر" }}")
                    val key="family.id.$year.${student.massarCode}.$role"
                    val cin by remember(key){dao.watchSetting(key)}.collectAsState(initial=null)
                    var editingId by remember(key){mutableStateOf(false)}
                    var idDraft by remember(key){mutableStateOf("")}
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("رقم البطاقة: "+cin.orEmpty().ifBlank { "غير متوفر" },Modifier.weight(1f))
                        IconButton(onClick={idDraft=cin.orEmpty();editingId=true}) { Icon(Icons.Default.Edit,"تعديل البطاقة") }
                    }
                    if(editingId) AlertDialog(onDismissRequest={editingId=false},title={Text("رقم البطاقة الوطنية")},text={OutlinedTextField(idDraft,{idDraft=it},singleLine=true)},confirmButton={TextButton(onClick={scope.launch { dao.saveSetting(AppSettingEntity(key,idDraft.trim()));editingId=false }}){Text("حفظ")}},dismissButton={TextButton(onClick={editingId=false}){Text("إلغاء")}})

                }
            }
        }
        val father=contacts.firstOrNull { it.role=="الأب" }
        var suggested by remember(student.massarCode){mutableStateOf(emptyList<String>())}
        LaunchedEffect(year,student.massarCode,father) {
            suggested=if(father!=null && father.name.trim().contains(" ") && father.phone.isBlank())
                dao.familyForYear(year).filter { it.role=="الأب" && it.massar!=student.massarCode && it.name.trim()==father.name.trim() && it.phone.isNotBlank() }.map { it.phone }.distinct()
            else emptyList()
        }
        for(candidate in suggested) {
            Text("اسم الأب مطابق لبطاقة تلميذ آخر. تحقق من صلة القرابة قبل اعتماد الرقم.")
            OutlinedButton(onClick={editPhone("الأب",candidate)}) { Text("مراجعة الرقم $candidate") }
        }
        if(roleEdit.isNotEmpty()) AlertDialog(onDismissRequest={roleEdit=""},title={Text("هاتف $roleEdit")},text={
            Column { OutlinedTextField(number,{number=it},singleLine=true,label={Text("رقم الهاتف")});if(failure.isNotBlank()) Text(failure) }
        },confirmButton={TextButton(onClick={
            val role=roleEdit;val updated=number.trim()
            scope.launch {
                runCatching {
                    val c=dao.family(year,student.massarCode).firstOrNull { it.role==role } ?: FamilyContact(year,student.massarCode,role,"","","")
                    dao.storeFamily(listOf(c.copy(phone=updated)))
                }.onSuccess {roleEdit=""}.onFailure {failure="تعذر حفظ الرقم"}
            }
        }) {Text("حفظ")}},dismissButton={TextButton(onClick={roleEdit=""}){Text("إلغاء")}})
        PersonalConduct(dao,year,student.massarCode)
        PersonalSlips(dao,year,student.massarCode)
    }
}

@Composable
private fun ProfilePhones(numbers:List<Pair<String,String?>>, edit: ((Int)->Unit)? = null) {
    val context=LocalContext.current
    ProfileCells(numbers.size) { index ->
        val (label,raw)=numbers[index]
        val number=raw.orEmpty().trim()
        Column(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp))
            .clickable(enabled=number.isNotEmpty(), onClickLabel="فتح لوحة الاتصال") {
                val intent=android.content.Intent(android.content.Intent.ACTION_DIAL,Uri.fromParts("tel",number,null))
                try { context.startActivity(intent) } catch (_:android.content.ActivityNotFoundException) {
                    android.widget.Toast.makeText(context,"تطبيق الاتصال غير متوفر",android.widget.Toast.LENGTH_SHORT).show()
                }
            }.padding(12.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(label,color=Teal,style=MaterialTheme.typography.labelMedium,modifier=Modifier.weight(1f))
                if(edit!=null) IconButton(onClick={edit(index)},modifier=Modifier.size(30.dp)) { Icon(Icons.Default.Edit,"تعديل",modifier=Modifier.size(16.dp),tint=Teal) }
            }
            Text(number.ifBlank { "غير متوفر" },color=Navy,fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
private fun ProfileHeading(name:String, subtitle:String) {
    Column(Modifier.fillMaxWidth().background(Navy,RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text(name,color=Color.White,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        if(subtitle.isNotBlank() && subtitle!=name) Text(subtitle,color=Color.White)
    }
}

@Composable
private fun ProfileCells(count:Int, content:@Composable (Int)->Unit) {
    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
        val columns=if(maxWidth>=310.dp && androidx.compose.ui.platform.LocalDensity.current.fontScale<=1.3f && count>1) 2 else 1
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            for(start in 0 until count step columns) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    repeat(columns) { col ->
                        Box(Modifier.weight(1f)) { if(start+col<count) content(start+col) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileGrid(title:String, fields:List<Pair<String,String?>>) {
    Text(title,color=Navy,fontWeight=FontWeight.Bold)
    ProfileCells(fields.size) { i ->
        val (label,value)=fields[i]
        Column(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).padding(12.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(label,color=Teal,style=MaterialTheme.typography.labelMedium,modifier=Modifier.weight(1f))
            }
            Text(value.orEmpty().ifBlank { "غير متوفر" },color=Ink)
        }
    }
}


private val BarOrange = Color(0xFFF28C28)

@Composable
private fun BarItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val tint = if (active) Color(0xFF11678B) else Color(0xFF344C58)
    Column(modifier.clickable(onClick = onClick).padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, color = tint, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun AppBottomBar(route: String, navigate: (String) -> Unit) {
    val imeBottom = WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current)
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    var showMore by rememberSaveable { mutableStateOf(false) }
    val go: (String) -> Unit = { r -> haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress); navigate(r) }
    val top = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    val homeFont = androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Font(R.font.neo_sans_arabic))
    if (imeBottom > 0) return
    Box(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().shadow(10.dp, top).background(Color.White, top).padding(top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.Bottom) {
            BarItem("الرئيسية", Icons.Default.Home, route == "home", Modifier.weight(1f)) { go("home") }
            BarItem("الغياب", Icons.Default.EditNote, route == "slips", Modifier.weight(1f)) { go("slips") }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(28.dp))
                Text("التلاميذ", color = BarOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            BarItem("استعمال الزمن", Icons.Default.CalendarMonth, route == "timetable", Modifier.weight(1f)) { go("timetable") }
            BarItem("الإعدادات", Icons.Default.Settings, route == "settings", Modifier.weight(1f)) { go("settings") }
        }
        Box(Modifier.align(Alignment.TopCenter).offset(y = (-22).dp).size(58.dp).shadow(6.dp, CircleShape)
            .background(if(route == "students" || route == "profiles") Color(0xFF11678B) else BarOrange, CircleShape).border(4.dp, Color(0xFFF4F7FC), CircleShape).clickable { go("students") },
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Groups, contentDescription = "التلاميذ", tint = Color.White, modifier = Modifier.size(28.dp))
        }
    }
    if (showMore) {
        androidx.compose.material3.ModalBottomSheet(onDismissRequest = { showMore = false }, containerColor = Color.White) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المزيد", color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp, fontFamily = homeFont)
                AllHomeTiles.filter { it.route !in MainHomeRoutes }.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        pair.forEach { tile ->
                            Row(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(tile.color.copy(alpha = 0.09f))
                                .clickable { showMore = false; navigate(tile.route) }.padding(horizontal = 10.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(tile.icon, null, tint = tile.color, modifier = Modifier.size(24.dp))
                                Column {
                                    Text(tile.title, color = Navy, fontWeight = FontWeight.Bold, fontFamily = homeFont, fontSize = 13.sp)
                                    Text(tile.subtitle, color = Color(0xFF536875), fontFamily = homeFont, fontSize = 10.sp)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun SplashIntro() {
    val appear = remember { androidx.compose.animation.core.Animatable(0f) }
    val progress = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, androidx.compose.animation.core.tween(900, easing = androidx.compose.animation.core.FastOutSlowInEasing)) }
    LaunchedEffect(Unit) { progress.animateTo(1f, androidx.compose.animation.core.tween(2800, easing = androidx.compose.animation.core.LinearEasing)) }
    val pulse = androidx.compose.animation.core.rememberInfiniteTransition()
    val ring by pulse.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(
        androidx.compose.animation.core.tween(1800, easing = androidx.compose.animation.core.LinearEasing)))
    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFFE3F3F7), Color.White))), contentAlignment = Alignment.Center) {
        androidx.compose.foundation.Canvas(Modifier.size(280.dp)) {
            val r = size.minDimension / 2
            listOf(0f, 0.5f).forEachIndexed { i, off ->
                val t = (ring + off) % 1f
                drawCircle(color = if (i == 0) Color(0xFF1F7AA8) else Color(0xFFF28C28), radius = r * (0.5f + 0.5f * t),
                    alpha = (1f - t) * 0.35f * appear.value, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
            }
        }
        Image(painterResource(R.drawable.moasasati_logo), "شعار مؤسستي",
            Modifier.height(270.dp).graphicsLayer {
                alpha = appear.value
                val sc = 0.8f + 0.2f * appear.value
                scaleX = sc; scaleY = sc
                translationY = (1f - appear.value) * 40f
            })
        Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp).width(160.dp).height(4.dp)
            .clip(RoundedCornerShape(2.dp)).background(Color(0xFFDCE8EE))) {
            Box(Modifier.fillMaxWidth(progress.value).height(4.dp)
                .background(Brush.horizontalGradient(listOf(Color(0xFF1F5F8B), Color(0xFF3FA34D), Color(0xFFF28C28)))))
        }
    }
}
