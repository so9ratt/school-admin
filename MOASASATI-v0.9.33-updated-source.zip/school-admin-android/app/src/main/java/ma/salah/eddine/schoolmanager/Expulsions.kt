package ma.salah.eddine.schoolmanager

import android.app.TimePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ma.salah.eddine.schoolmanager.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.UUID

private const val expulsionKind="الطرد من الحصة"
private val expulsionReasons=listOf("عدم إحضار الدفتر","عدم إحضار الأدوات المدرسية","سلوك غير مناسب","سبب آخر")
private val expulsionClock=DateTimeFormatter.ofPattern("HH:mm",java.util.Locale.ROOT)

@Composable
internal fun ExpulsionScreen(dao:SchoolDao,year:String,school:String,academy:String,province:String,back:()->Unit) {
    val scope=rememberCoroutineScope()
    val context=LocalContext.current
    val records by remember(dao,year){dao.conduct(year)}.collectAsState(emptyList())
    val rows=records.filter { it.kind==expulsionKind }
    val roster by produceState(emptyList<StudentListRow>(),dao,year){value=dao.studentsForYear(year)}
    var adding by rememberSaveable {mutableStateOf(false)}
    var section by rememberSaveable {mutableStateOf("")}
    var date by rememberSaveable {mutableStateOf(LocalDate.now().toString())}
    var time by rememberSaveable {mutableStateOf(LocalTime.now().format(expulsionClock))}
    var teacherKey by rememberSaveable {mutableStateOf("")}
    var query by rememberSaveable {mutableStateOf("")}
    var reasonFilter by rememberSaveable {mutableStateOf("")}
    var teacherFilter by rememberSaveable {mutableStateOf("")}
    var subjectFilter by rememberSaveable {mutableStateOf("")}
    var dateFilter by rememberSaveable {mutableStateOf(false)}
    var from by rememberSaveable {mutableStateOf(LocalDate.now().toString())}
    var to by rememberSaveable {mutableStateOf(LocalDate.now().toString())}
    val selected=remember {mutableStateMapOf<String,String>()}
    val notes=remember {mutableStateMapOf<String,String>()}
    var busy by remember {mutableStateOf(false)}
    var message by remember {mutableStateOf("")}
    val staff by produceState(emptyList<TeacherAssignmentEntity>(),dao,year,section){value=if(section.isBlank()) emptyList() else dao.assignmentsForClass(year,section).map { row -> row.copy(teacherName=dao.setting("fet.label.الأستاذ."+row.teacherCode.filterNot(Char::isWhitespace).uppercase()) ?: row.teacherName) }.distinctBy { it.teacherCode to it.subjectName }.sortedWith(compareBy({arabicConductSubject(it.subjectName)},{it.teacherName}))}
    val teacher=staff.firstOrNull {it.teacherCode+"|"+it.subjectName==teacherKey}
    val suggestion by produceState<String?>(null,year,section,date,teacherKey){value=null;if(teacher!=null)value=suggestedLessonTime(dao,year,date,section,teacher.teacherCode,teacher.subjectName)}
    var manualTime by rememberSaveable(year,section,date,teacherKey){mutableStateOf(false)}
    LaunchedEffect(suggestion,year,section,date,teacherKey){if(!manualTime && suggestion!=null)time=suggestion!!}
    fun close(){if(adding){adding=false;selected.clear();notes.clear();section="";query="";teacherKey=""}else back()}
    BackHandler { if(!busy)close() }
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        PageTitle("إخراج التلاميذ من الحصة"){if(!busy)close()}
        Text("الموسم الدراسي $year")
        if(message.isNotBlank()) Text(message)
        if(adding) {
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                item { RosterFilter("حسب القسم",section,schoolSections(roster.map {it.className}),Modifier.fillMaxWidth()){section=it;selected.clear();notes.clear();teacherKey="";query=""} }
                item { Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){DayPicker(date){date=it};OutlinedButton(onClick={val t=LocalTime.parse(time);TimePickerDialog(context,{_,h,m->time=LocalTime.of(h,m).format(expulsionClock);manualTime=true},t.hour,t.minute,true).show()}){Text(time)}} }
                item { RosterFilter("الأستاذ والمادة",teacher?.let {it.teacherName+" • "+arabicConductSubject(it.subjectName)}.orEmpty(),staff.map {it.teacherName+" • "+arabicConductSubject(it.subjectName)}.distinct(),Modifier.fillMaxWidth()){label->teacherKey=staff.singleOrNull {it.teacherName+" • "+arabicConductSubject(it.subjectName)==label}?.let {it.teacherCode+"|"+it.subjectName}.orEmpty()} }
                item { if(suggestion!=null) TextButton(onClick={time=suggestion!!;manualTime=true}){Text("اعتماد توقيت الحصة: ${suggestion!!}")} else Text("يمكن إدخال توقيت الحصة يدوياً") }
                item { SearchBox(query,{query=it},"اسم التلميذ أو رمز مسار أو الرقم الترتيبي") }
                items(roster.filter {it.className==section && (it.massarCode in selected || pupilPrefix(query,it.givenName,it.surname,it.massarCode,it.ordinal?.toString().orEmpty()))},key={it.massarCode}){s ->
                    OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp)) {
                        Row { Checkbox(s.massarCode in selected,{checked->if(checked)selected[s.massarCode]="" else {selected.remove(s.massarCode);notes.remove(s.massarCode)}});Text("${s.ordinal ?: "—"}. ${s.givenName} ${s.surname}",Modifier.padding(top=12.dp)) }
                        if(s.massarCode in selected) {
                            RosterFilter("سبب الإخراج",selected[s.massarCode].orEmpty(),expulsionReasons,Modifier.fillMaxWidth()){selected[s.massarCode]=it}
                            OutlinedTextField(notes[s.massarCode].orEmpty(),{notes[s.massarCode]=it},label={Text("ملاحظة / توضيح السبب")},modifier=Modifier.fillMaxWidth())
                        }
                    } }
                }
            }
            Button(enabled=!busy && teacher!=null && selected.isNotEmpty() && selected.all { (code,reason)->reason.isNotBlank() && (reason!="سبب آخر" || !notes[code].isNullOrBlank()) },modifier=Modifier.fillMaxWidth(),onClick={
                val t=teacher ?: return@Button
                val id=UUID.randomUUID().toString()
                val batch=roster.filter {it.massarCode in selected && it.className==section}.map { s ->
                    ConductRecord(id+":"+s.massarCode,year,expulsionKind,s.massarCode,s.givenName+" "+s.surname,section,s.levelName,date,time,t.teacherName,arabicConductSubject(t.subjectName),t.teacherCode,selected.getValue(s.massarCode),notes[s.massarCode].orEmpty(),"","","","","",true,false,false)
                }
                busy=true;scope.launch {runCatching {dao.recordClassExpulsions(batch)}.onSuccess {close();message="تم حفظ ${batch.size} حالة"}.onFailure {message="تعذر الحفظ"};busy=false}
            }){Text("حفظ الإخراج (${selected.size})")}
        } else {
            val visible=rows.filter { (section.isBlank() || it.section==section) && (teacherFilter.isBlank() || it.teacher==teacherFilter) && (subjectFilter.isBlank() || it.subject==subjectFilter) && (reasonFilter.isBlank() || it.reasons==reasonFilter) && (!dateFilter || it.date in from..to) && pupilPrefix(query,it.studentName,it.massar) }
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){
                item { Button(onClick={adding=true;section="";query=""}){Text("تسجيل إخراج التلاميذ من الحصة")} }
                item { Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){SummaryCard("الحوادث",visible.map {it.id.substringBefore(":")}.distinct().size.toString(),Modifier.weight(1f));SummaryCard("الحالات",visible.size.toString(),Modifier.weight(1f));SummaryCard("التلاميذ",visible.map {it.massar}.distinct().size.toString(),Modifier.weight(1f))} }
                item { SearchBox(query,{query=it},"بحث عن تلميذ") }
                item { RosterFilter("جميع الأقسام",section,schoolSections(rows.map {it.section}),Modifier.fillMaxWidth()){section=it} }
                item { RosterFilter("جميع الأساتذة",teacherFilter,rows.map {it.teacher}.distinct().sorted(),Modifier.fillMaxWidth()){teacherFilter=it} }
                item { RosterFilter("جميع المواد",subjectFilter,rows.map {it.subject}.distinct().sorted(),Modifier.fillMaxWidth()){subjectFilter=it} }
                item { RosterFilter("جميع الأسباب",reasonFilter,expulsionReasons,Modifier.fillMaxWidth()){reasonFilter=it} }
                item { Row {Checkbox(dateFilter,{dateFilter=it});Text("حسب الفترة",Modifier.padding(top=12.dp))};if(dateFilter)Row {DayPicker(from){from=it;if(to<it)to=it};DayPicker(to){to=it;if(from>it)from=it}} }
                item { TableExport("إخراج التلاميذ من الحصة",school,academy,province,year,listOf("الاسم","مسار","القسم","التاريخ","الحصة","المادة","الأستاذ","السبب","ملاحظة"),listOf(ExportGroup("الحالات: ${visible.size} • التلاميذ: ${visible.map {it.massar}.distinct().size} • الحوادث: ${visible.map {it.id.substringBefore(":")}.distinct().size}",visible.map {listOf(it.studentName,it.massar,it.section,it.date,it.time,it.subject,it.teacher,it.reasons,it.proposed)}))) }
                if(visible.isEmpty()) item {Text("لا توجد سجلات")}
                items(visible,key={it.id}){r->OutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(9.dp)){Text(r.studentName+" • "+r.section);Text(r.date+" • "+r.time+" • "+r.teacher+" • "+r.subject);Text(r.reasons);if(r.proposed.isNotBlank())Text(r.proposed)}}}
            }
        }
    }
}
