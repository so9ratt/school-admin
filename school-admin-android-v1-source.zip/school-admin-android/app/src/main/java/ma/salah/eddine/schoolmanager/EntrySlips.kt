package ma.salah.eddine.schoolmanager

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ma.salah.eddine.schoolmanager.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.UUID

private val clockFormat = DateTimeFormatter.ofPattern("HH:mm", java.util.Locale.ROOT)
private val reasons = listOf("غياب", "تأخر")

@Composable
private fun DayPicker(date: String, change: (String) -> Unit) {
    val context = LocalContext.current
    OutlinedButton(onClick = {
        val d = LocalDate.parse(date)
        DatePickerDialog(context, { _, y, m, day -> change(LocalDate.of(y,m+1,day).toString()) },
            d.year,d.monthValue-1,d.dayOfMonth).show()
    }) { Text(date) }
}

@Composable
private fun SlipStats(rows: List<SlipRow>, personal: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        SummaryCard("الأوراق", rows.distinctBy { it.id }.size.toString(), Modifier.weight(1f))
        for (reason in reasons) {
            val group = rows.filter { it.reason == reason }
            val count = if (personal) group.distinctBy { it.id }.size else group.distinctBy { it.massar }.size
            SummaryCard(if (personal) "أوراق $reason" else if (reason=="غياب") "المتغيبون" else "المتأخرون",count.toString(),Modifier.weight(1f))
        }
    }
}

@Composable
private fun SlipList(rows: List<SlipRow>, open: (String) -> Unit) {
    if (rows.isEmpty()) Text("لا توجد أوراق مسجّلة")
    rows.groupBy { it.id }.forEach { (id, students) ->
        val slip = students.first()
        OutlinedCard(Modifier.fillMaxWidth().clickable { open(id) }) {
            Column(Modifier.padding(12.dp)) {
                Text("${slip.date}   ${slip.time}   •   ${slip.reason}", style=MaterialTheme.typography.titleMedium)
                Text(slip.section + "   •   " + students.joinToString("، ") { it.displayName })
            }
        }
    }
}

@Composable
private fun SlipDetails(dao: SchoolDao, id: String, close: () -> Unit) {
    var slip by remember(id) { mutableStateOf<EntrySlip?>(null) }
    var students by remember(id) { mutableStateOf(emptyList<SlipStudent>()) }
    LaunchedEffect(id) { students=dao.recipients(id); slip=dao.slip(id) }
    AlertDialog(onDismissRequest=close,title={Text("تفاصيل ورقة الدخول")},text={
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            slip?.let { d ->
                Text("${d.date}   ${d.time}   •   ${d.reason}   •   ${d.section}")
                students.forEach { Text("${it.ordinal ?: "—"}. ${it.displayName}") }
                HorizontalDivider()
                Text("التلميذ المعني بحضور ولي الأمر: "+students.firstOrNull { it.massar==d.guardianStudent }?.displayName.orEmpty())
                Text("صفة الحاضر: "+d.relation)
                Text("اسم الحاضر: "+d.guardianName.ifBlank { "غير مسجل" })
                if (d.identity.isNotBlank()) Text("رقم البطاقة الوطنية: "+d.identity)
            }
        }
    },confirmButton={TextButton(onClick=close){Text("إغلاق")}})
}

@Composable
internal fun PersonalSlips(dao: SchoolDao, year: String, student: String) {
    val rows by remember(dao,year,student) { dao.slipRows(year,"",student) }.collectAsState(initial=emptyList())
    var expanded by rememberSaveable(student) { mutableStateOf(false) }
    var id by remember { mutableStateOf("") }
    Text("أوراق الدخول • $year")
    SlipStats(rows,true)
    if(rows.isNotEmpty()) TextButton(onClick={expanded=!expanded}) {Text(if(expanded) "طيّ السجل" else "عرض سجل التلميذ")}
    if(expanded) SlipList(rows){id=it}
    if(id.isNotEmpty()) SlipDetails(dao,id){id=""}
}

@Composable
internal fun SlipsScreen(dao: SchoolDao, year: String, sections: List<String>, back: () -> Unit) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var tab by rememberSaveable { mutableStateOf("تسجيل ورقة") }
    var date by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    var customTime by rememberSaveable { mutableStateOf("") }
    var reason by rememberSaveable { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var chosen by rememberSaveable { mutableStateOf(arrayListOf<String>()) }
    var owner by rememberSaveable { mutableStateOf("") }
    var guardian by rememberSaveable { mutableStateOf("") }
    var identity by rememberSaveable { mutableStateOf("") }
    var relation by rememberSaveable { mutableStateOf("") }
    var other by rememberSaveable { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var details by remember { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("") }
    var lookupClass by rememberSaveable { mutableStateOf("") }
    var lookup by rememberSaveable { mutableStateOf("") }
    var roster by remember(year) { mutableStateOf(emptyList<StudentListRow>()) }
    LaunchedEffect(year) { roster=dao.studentsForYear(year) }
    val daily by remember(year,date) { dao.slipRows(year,date,"") }.collectAsState(initial=emptyList())
    val selected=roster.filter { it.massarCode in chosen && it.className==section }
    val effectiveOwner=if(selected.size==1) selected.first().massarCode else owner
    fun matches(s:StudentListRow,input:String):Boolean {
        val q=input.trim().map { it.digitToIntOrNull()?.digitToChar() ?: it }.joinToString("")
        return if(q.toIntOrNull()!=null) s.ordinal==q.toIntOrNull()
        else listOf(s.massarCode,s.givenName+" "+s.surname,s.surname+" "+s.givenName).any { it.contains(q,true) }
    }
    BackHandler(onBack=back)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
        Text("ورقة الدخول",style=MaterialTheme.typography.titleLarge)
        DayPicker(date){date=it}
        SlipStats(daily)
        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            listOf("تسجيل ورقة","سجل اليوم","بحث").forEach {
                FilterChip(selected=tab==it,onClick={tab=it},label={Text(it)})
            }
        }
        if(message.isNotEmpty()) Text(message)
        when(tab) {
            "سجل اليوم" -> SlipList(daily){details=it}
            "بحث" -> {
                RosterFilter("حسب القسم",lookupClass,sections,Modifier.fillMaxWidth()){lookupClass=it;lookup=""}
                OutlinedTextField(filter,{filter=it;lookup=""},label={Text("الاسم أو مسار أو الرقم الترتيبي")})
                if(lookup.isNotBlank()) {
                    Text(roster.firstOrNull { it.massarCode==lookup }?.let { it.givenName+" "+it.surname }.orEmpty())
                    PersonalSlips(dao,year,lookup)
                } else if(filter.isNotBlank() || lookupClass.isNotBlank()) {
                    roster.filter { (lookupClass.isBlank() || it.className==lookupClass) && matches(it,filter) }.forEach { s ->
                        TextButton(onClick={lookup=s.massarCode}) {Text("${s.ordinal ?: "—"}. ${s.givenName} ${s.surname} • ${s.className}")}
                    }
                }
            }
            else -> {
                OutlinedButton(onClick={
                    val t=if(customTime.isEmpty()) LocalTime.now() else LocalTime.parse(customTime)
                    TimePickerDialog(context,{_,h,m->customTime=LocalTime.of(h,m).format(clockFormat)},t.hour,t.minute,true).show()
                }) {Text("وقت التسليم: "+customTime.ifBlank { LocalTime.now().format(clockFormat)+" (تلقائي)" })}
                Row { reasons.forEach { r ->
                    Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(reason==r,{reason=r}); Text(r) }
                } }
                RosterFilter("حسب القسم",section,sections,Modifier.fillMaxWidth()){
                    if(section!=it){section=it;chosen=arrayListOf();owner="";guardian="";identity="";relation="";other="";query=""}
                }
                if(section.isNotBlank()) {
                    OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("أدخل الرقم الترتيبي أو الاسم")},singleLine=true)
                    val candidates=roster.filter { it.className==section && (it.massarCode in chosen || (query.isNotBlank() && matches(it,query))) }
                    candidates.forEach { s ->
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(s.massarCode in chosen,{checked->
                                chosen=ArrayList(if(checked) chosen+s.massarCode else chosen-s.massarCode)
                                if(!checked && owner==s.massarCode) owner=""
                                query=""
                            })
                            Text("${s.ordinal ?: "—"}. ${s.givenName} ${s.surname}")
                        }
                    }
                }
                if(selected.isNotEmpty()) {
                    Text("حضر ولي أمر أي تلميذ؟")
                    selected.forEach { s ->
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            RadioButton(effectiveOwner==s.massarCode,{owner=s.massarCode})
                            Text(s.givenName+" "+s.surname)
                        }
                    }
                    RosterFilter("صفة الحاضر",relation,listOf("الأب","الأم","الأخ","الأخت","العم","أخرى"),Modifier.fillMaxWidth()){relation=it}
                    if(relation=="أخرى") OutlinedTextField(other,{other=it},label={Text("الصفة")},singleLine=true)
                    OutlinedTextField(guardian,{guardian=it},label={Text("اسم ولي الأمر")},singleLine=true)
                    OutlinedTextField(identity,{identity=it},label={Text("رقم البطاقة الوطنية (اختياري)")},singleLine=true)
                }
                Button(enabled=!busy && reason in reasons && selected.any { it.massarCode==effectiveOwner } &&
                    relation.isNotBlank() && (relation!="أخرى" || other.isNotBlank()),onClick={
                    busy=true
                    val id=UUID.randomUUID().toString()
                    val slip=EntrySlip(id,year,date,customTime.ifBlank { LocalTime.now().format(clockFormat) },section,reason,effectiveOwner,
                        guardian.trim(),if(relation=="أخرى") other.trim() else relation,identity.trim())
                    val people=selected.map { SlipStudent(id,it.massarCode,it.givenName+" "+it.surname,it.ordinal) }
                    scope.launch {
                        runCatching { dao.recordSlip(slip,people) }.onSuccess {
                            chosen=arrayListOf();owner="";guardian="";identity="";relation="";other="";query="";customTime="";message="حُفظت الورقة • "+slip.time
                        }.onFailure {message="تعذّر حفظ الورقة. حاول مجدداً."}
                        busy=false
                    }
                }) {Text("حفظ الورقة")}
            }
        }
    }
    if(details.isNotBlank()) SlipDetails(dao,details){details=""}
}
