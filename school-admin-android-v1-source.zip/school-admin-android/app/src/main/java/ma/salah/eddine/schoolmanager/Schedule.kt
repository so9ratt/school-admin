package ma.salah.eddine.schoolmanager

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.*
import ma.salah.eddine.schoolmanager.importing.FetReader
import java.util.UUID

private val days = linkedMapOf("lundi" to "الاثنين","mardi" to "الثلاثاء","mercredi" to "الأربعاء",
    "jeudi" to "الخميس","vendredi" to "الجمعة","samedi" to "السبت")
private val subjects = mapOf("0011" to "العربية","0012" to "الفرنسية","0013" to "الإنجليزية","0014" to "الإسبانية",
    "0018" to "الاجتماعيات","0019" to "الرياضيات","0020" to "علوم الحياة والأرض","0023" to "الفيزياء والكيمياء",
    "0024" to "إسلاميات","0026" to "التربية البدنية","0030" to "المعلوميات","0036" to "الفلسفة")
private fun roomKey(code:String) = if(code=="P-E-007") "P-A-001" else code
private val rooms = buildMap<String,String> {
    val floors = listOf(1 to listOf("LAB1","LAB2","S4","S3","S2","S1"), 101 to listOf("LAB3","LAB4","S5","S6","S7","S8","S9","S10","S11","S12","HG"),
        201 to listOf("LAB5","LAB6","S20","S19","S18","S17","S16","S15","S14","S13"))
    for ((first,names) in floors) names.forEachIndexed { index,name -> put("P-E-"+(first+index).toString().padStart(3,'0'),name) }
    put("P-A-001","P-A-001")
}
private fun ScheduledLesson.start() = (if(day.endsWith("_m")) 8 else 14) + hour - 1
private fun ScheduledLesson.code(type:String) = when(type) {
    "الأستاذ" -> teacher
    "المادة" -> subject
    "القاعة" -> roomKey(room)
    else -> section.substringBefore(':')
}
private fun teacherKey(code:String) = code.filterNot(Char::isWhitespace).uppercase()

@Composable
internal fun FetImport(dao:SchoolDao,year:String,openReview:()->Unit) {
    val context=LocalContext.current
    val scope= rememberCoroutineScope()
    var batch by remember(year) { mutableStateOf(emptyList<ScheduledLesson>()) }
    var previous by remember { mutableStateOf(emptyList<ScheduledLesson>()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null) scope.launch {
            busy=true
            runCatching {
                withContext(Dispatchers.IO) {
                    val revision=UUID.randomUUID().toString()
                    val stream=context.contentResolver.openInputStream(uri) ?: error("تعذر فتح الملف")
                    stream.use { FetReader.read(it) }.map { l -> ScheduledLesson(revision,l.id,teacherKey(l.teacher),l.subject,l.students,l.room,l.day,l.hour.drop(1).toInt(),l.duration) }
                } to dao.currentSchedule("fet.current.$year")
            }.onSuccess { (incoming,old) -> previous=old; batch=incoming; message="" }.onFailure { message=it.message ?: "ملف غير صالح" }
            busy=false
        }
    }
    OutlinedButton(onClick={picker.launch(arrayOf("*/*"))},enabled=!busy && year.isNotBlank(),modifier=Modifier.fillMaxWidth()) {
        Text(if(busy) "جارٍ تجهيز الجدول…" else "استيراد استعمال الزمن — FET")
    }
    if(message.isNotBlank()) Text(message)
    if(batch.isNotEmpty()) {
        val changes=remember(batch,previous) {
            val old=previous.associateBy { it.activity }
            val ids=batch.map { it.activity }.toSet()
            listOf(batch.count { it.activity !in old },batch.count { row -> old[row.activity]?.let { it.copy(revision=row.revision)!=row }==true },old.keys.count { it !in ids })
        }
        AlertDialog(onDismissRequest={if(!busy)batch=emptyList()},title={Text("معاينة استعمال الزمن")},text={
            Text("الموسم: $year\nالأنشطة: ${batch.size} • الفترات: ${batch.sumOf { it.duration }}\nالأقسام: ${batch.distinctBy { it.code("القسم") }.size} • الأساتذة: ${batch.distinctBy { it.teacher }.size}\nدون قاعة: ${batch.count { it.room.isBlank() }}\nجديدة: ${changes[0]} • متغيرة: ${changes[1]} • غائبة: ${changes[2]}\nسيصبح هذا الجدول معتمداً للموسم بعد التأكيد.")
        },confirmButton={Button(enabled=!busy,onClick={
            busy=true
            scope.launch {
                runCatching { dao.saveSchedule(year,batch) }.onSuccess {batch=emptyList(); openReview()}.onFailure {batch=emptyList();message=it.message ?: "تعذر حفظ الجدول"}
                busy=false
            }
        }) { Text("حفظ ومراجعة التسميات") }},dismissButton={TextButton(enabled=!busy,onClick={batch=emptyList()}) {Text("إلغاء")}})
    }
}

@Composable
internal fun WeekScreen(dao:SchoolDao,year:String,initialClass:String,review:Boolean,back:()->Unit) {
    val scope=rememberCoroutineScope()
    var lessons by remember(year) { mutableStateOf(emptyList<ScheduledLesson>()) }
    var labels by remember { mutableStateOf(emptyMap<String,String>()) }
    var teacherNames by remember { mutableStateOf(emptyMap<String,String>()) }
    var editing by rememberSaveable { mutableStateOf(review) }
    var mode by rememberSaveable { mutableStateOf("القسم") }
    var selection by rememberSaveable { mutableStateOf(initialClass) }
    var dayFilter by rememberSaveable { mutableStateOf("") }
    var hourFilter by rememberSaveable { mutableStateOf("") }
    var editKey by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var value by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(year) {
        lessons=dao.currentSchedule("fet.current.$year")
        labels=dao.scheduleLabels().associate { it.key to it.value }
        teacherNames=dao.assignments(year).groupBy { teacherKey(it.teacherCode) }.mapNotNull { (code,rows) ->
            rows.map { it.teacherName.trim() }.filter { it.isNotEmpty() && teacherKey(it)!=code }.distinct().singleOrNull()?.let {code to it}
        }.toMap()
    }
    fun key(type:String,code:String)="fet.label.$type.$code"
    fun name(type:String,code:String):String {
        if(code.isBlank()) return "غير محددة"
        return labels[key(type,code)] ?: when(type) {
            "الأستاذ" -> teacherNames[code] ?: "أستاذ يحتاج إلى تسمية"
            "المادة" -> subjects[code] ?: "مادة $code"
            "القاعة" -> rooms[code] ?: code
            else -> code
        }
    }
    fun close() { if(editing) {editing=false;query=""} else back() }
    BackHandler(onBack=::close)
    val options=remember(mode,lessons,labels,teacherNames) { lessons.map { it.code(mode) }.filter { it.isNotBlank() }.distinct().sortedBy { name(mode,it) } }
    val subset=remember(lessons,mode,selection,dayFilter,hourFilter) {
        lessons.filter { (selection.isEmpty() || it.code(mode)==selection) &&
            (dayFilter.isEmpty() || days[it.day.substringBefore('_')]==dayFilter) &&
            (hourFilter.isEmpty() || hourFilter.substringBefore(':').toInt() in it.start() until it.start()+it.duration) }
            .sortedWith(compareBy({days.keys.indexOf(it.day.substringBefore('_'))},{it.start()},{it.section}))
    }
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(if(editing) "مراجعة الرموز والتسميات" else "استعمال الزمن",fontWeight=FontWeight.Bold)
            TextButton(onClick=::close) { Text("رجوع") }
        }
        if(lessons.isEmpty()) { Text("استوردي ملف استعمال الزمن من الإعدادات للموسم $year."); return@Column }
        RosterFilter("طريقة العرض",mode,listOf("القسم","الأستاذ","المادة","القاعة"),Modifier.fillMaxWidth()) {
            if(it.isNotBlank()) {mode=it;selection="";query=""}
        }
        if(editing) {
            OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("بحث في التسميات")})
            LazyColumn {
                items(options.filter { name(mode,it).contains(query,true) || it.contains(query,true) },key={it}) { code ->
                    val hint=if(mode=="الأستاذ") lessons.filter {it.teacher==code}.map {it.section.substringBefore(':')}.distinct().joinToString("، ") else code
                    TextButton(onClick={editKey=key(mode,code);value=labels[editKey] ?: if(mode=="الأستاذ") teacherNames[code].orEmpty() else name(mode,code) }) {
                        Text("${name(mode,code)} • $hint" + if(mode=="الأستاذ" && teacherNames[code]==null) " • …${code.takeLast(4)}" else "")
                    }
                }
            }
        } else {
            var choosing by remember { mutableStateOf(false) }
            OutlinedButton(onClick={choosing=true},modifier=Modifier.fillMaxWidth()) { Text(if(selection.isEmpty()) "اختيار $mode" else name(mode,selection)) }
            if(choosing) AlertDialog(onDismissRequest={choosing=false;query=""},title={Text("اختيار $mode")},text={
                Column { OutlinedTextField(query,{query=it},label={Text("بحث")}); LazyColumn {
                    item { TextButton(onClick={selection="";choosing=false;query=""}) {Text("عرض الجميع")} }
                    items(options.filter {name(mode,it).contains(query,true)}) {code ->
                        TextButton(onClick={selection=code;choosing=false;query=""}) {Text(name(mode,code))}
                    }
                } }
            },confirmButton={TextButton(onClick={choosing=false;query=""}) {Text("إغلاق")}})
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                RosterFilter("حسب اليوم",dayFilter,days.values.toList(),Modifier.weight(1f)){dayFilter=it}
                RosterFilter("حسب الساعة",hourFilter,listOf(8,9,10,11,14,15,16,17).map { "%02d:00".format(java.util.Locale.ROOT,it) },Modifier.weight(1f)){hourFilter=it}
            }
            TextButton(onClick={editing=true}) {Text("مراجعة الرموز والتسميات")}
            LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                if(subset.isEmpty()) item {Text("لا توجد حصص ضمن هذا الاختيار")}
                subset.groupBy { it.day.substringBefore('_') }.forEach { (day,rows) ->
                    item {Text(days[day].orEmpty(),fontWeight=FontWeight.Bold)}
                    items(rows,key={it.activity}) { l ->
                        val group=l.section.substringAfter(':',"").removePrefix("G")
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
                            Text("%02d:00 – %02d:00".format(java.util.Locale.ROOT,l.start(),l.start()+l.duration)+" • "+name("المادة",l.subject),fontWeight=FontWeight.Bold)
                            Text(name("الأستاذ",l.teacher)+" • "+name("القسم",l.code("القسم"))+if(group.isBlank()) "" else " • المجموعة $group")
                            Text("القاعة: "+name("القاعة",l.code("القاعة")))
                        } }
                    }
                }
            }
        }
    }
    if(editKey.isNotBlank()) AlertDialog(onDismissRequest={editKey=""},title={Text("تعديل الاسم المعروض")},text={
        Column { OutlinedTextField(value,{value=it},label={Text("الاسم")}); if(error.isNotEmpty()) Text(error) }
    },confirmButton={Button(enabled=value.isNotBlank(),onClick={
        val setting=AppSettingEntity(editKey,value.trim())
        scope.launch {
            runCatching { dao.saveSetting(setting) }.onSuccess {labels=labels+(setting.key to setting.value);editKey="";error=""}.onFailure {error="تعذر حفظ الاسم"}
        }
    }) {Text("حفظ")}},dismissButton={TextButton(onClick={editKey=""}){Text("إلغاء")}})
}
