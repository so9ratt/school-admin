package ma.salah.eddine.schoolmanager.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey val massarCode: String,
    val surname: String,
    val givenName: String,
    val gender: String,
    val birthDate: String,
    val birthPlace: String?
)

@Entity(tableName = "school_classes", primaryKeys = ["schoolYear", "className"], indices = [Index(value = ["levelName"])])
data class SchoolClassEntity(
    val schoolYear: String,
    val className: String,
    val levelName: String
)

@Entity(tableName = "subjects")
data class SubjectEntity(@PrimaryKey val name: String)

@Entity(
    tableName = "enrollments",
    foreignKeys = [
        ForeignKey(entity = StudentEntity::class, parentColumns = ["massarCode"], childColumns = ["massarCode"]),
        ForeignKey(entity = SchoolClassEntity::class, parentColumns = ["schoolYear", "className"], childColumns = ["schoolYear", "className"])
    ],
    indices = [Index(value = ["massarCode", "schoolYear"], unique = true), Index(value = ["schoolYear", "className"])]
)
data class EnrollmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val massarCode: String,
    val schoolYear: String,
    val className: String
)

@Entity(tableName = "employees")
data class EmployeeEntity(
    @PrimaryKey val ppr: String,
    val nameArabic: String,
    val nameFrench: String,
    val gender: String?,
    val disciplineCode: String?,
    val disciplineLabelFrench: String?,
    val disciplineLabelArabic: String?,
    val statusCode: String?,
    val statusLabel: String?,
    val positionCode: String?,
    val positionLabel: String?,
    val gradeCode: String?,
    val gradeLabel: String?,
    val cadreCode: String?,
    val cadreLabel: String?,
    val echelon: String?,
    val recruitmentDate: String?,
    val titularizationDate: String?,
    val activityCode: String?,
    val functionCode: String?,
    val functionLabel: String?,
    val institutionCode: String?,
    val isCurrent: Boolean = true
)

@Entity(tableName = "reference_values", primaryKeys = ["tableName", "code"])
data class ReferenceValueEntity(
    val tableName: String,
    val code: String,
    val labelFrench: String?,
    val labelArabic: String?
)

@Entity(tableName = "employee_services", indices = [Index(value = ["employeePpr"]), Index(value = ["activityCode"])])
data class EmployeeServiceEntity(
    @PrimaryKey val serviceCode: String,
    val employeePpr: String?,
    val activityCode: String,
    val disciplineCode: String?,
    val disciplineLabelFrench: String?,
    val trackCode: String?,
    val trackLabel: String?,
    val levelCode: String?,
    val levelLabel: String?,
    val teachingHours: String?,
    val extraHours: String?,
    val classCount: String?,
    val statisticalCode: String?,
    val isCurrent: Boolean = true
)

@Entity(
    tableName = "teacher_assignments",
    foreignKeys = [
        ForeignKey(entity = SchoolClassEntity::class, parentColumns = ["schoolYear", "className"], childColumns = ["schoolYear", "className"]),
        ForeignKey(entity = SubjectEntity::class, parentColumns = ["name"], childColumns = ["subjectName"])
    ],
    indices = [
        Index(value = ["schoolYear", "className"]),
        Index(value = ["teacherCode", "schoolYear"]),
        Index(value = ["subjectName", "schoolYear"]),
        Index(value = ["schoolYear", "teacherCode", "subjectName", "className", "subgroupName"], unique = true)
    ]
)
data class TeacherAssignmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val schoolYear: String,
    val teacherCode: String,
    val teacherName: String,
    val subjectName: String,
    val className: String,
    val subgroupName: String,
    val lessonCount: Int,
    val isCurrent: Boolean = true
)

@Entity(tableName = "app_settings")
data class AppSettingEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "import_history")
data class ImportHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceType: String,
    val fileName: String,
    val importedAt: Long,
    val recordsRead: Int,
    val recordsCreated: Int,
    val recordsUpdated: Int,
    val warnings: Int
)

data class StudentListRow(
    val massarCode: String,
    val surname: String,
    val givenName: String,
    val gender: String,
    val birthDate: String,
    val birthPlace: String?,
    val levelName: String,
    val className: String
)

data class ClassSummary(
    val className: String,
    val levelName: String,
    val studentCount: Int
)
