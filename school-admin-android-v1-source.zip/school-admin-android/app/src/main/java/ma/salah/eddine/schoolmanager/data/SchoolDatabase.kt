package ma.salah.eddine.schoolmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        FamilyContact::class,
        StudentEntity::class,
        SchoolClassEntity::class,
        SubjectEntity::class,
        EnrollmentEntity::class,
        EmployeeEntity::class,
        EmployeeServiceEntity::class,
        ReferenceValueEntity::class,
        TeacherAssignmentEntity::class,
        AppSettingEntity::class,
        ImportHistoryEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class SchoolDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao

    companion object {
        @Volatile private var instance: SchoolDatabase? = null

        fun get(context: Context): SchoolDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                SchoolDatabase::class.java,
                "salah_eddine_school.db"
            ).addMigrations(object : androidx.room.migration.Migration(1,2) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE IF NOT EXISTS family_contacts (year TEXT NOT NULL, massar TEXT NOT NULL, role TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, kind TEXT NOT NULL, PRIMARY KEY(year,massar,role))")
                }
            }).build().also { instance = it }
        }
    }
}
