package ma.salah.eddine.schoolmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ScheduledLesson::class,
        FamilyContact::class,
        StudentEntity::class,
        SchoolClassEntity::class,
        SubjectEntity::class,
        EnrollmentEntity::class,
        EmployeeEntity::class,
        EmployeeServiceEntity::class,
        ReferenceValueEntity::class,
        TeacherAssignmentEntity::class,
        AppSettingEntity::class,
        ImportHistoryEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class SchoolDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao

    companion object {
        @Volatile private var instance: SchoolDatabase? = null

        fun get(context: Context): SchoolDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                SchoolDatabase::class.java,
                "salah_eddine_school.db"
            ).addMigrations(object : androidx.room.migration.Migration(1,2) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE IF NOT EXISTS family_contacts (year TEXT NOT NULL, massar TEXT NOT NULL, role TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, kind TEXT NOT NULL, PRIMARY KEY(year,massar,role))")
                }
            }, object : androidx.room.migration.Migration(2,3) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("ALTER TABLE enrollments ADD COLUMN ordinal INTEGER")
                    db.execSQL("CREATE TABLE scheduled_lessons (revision TEXT NOT NULL, activity TEXT NOT NULL, teacher TEXT NOT NULL, subject TEXT NOT NULL, section TEXT NOT NULL, room TEXT NOT NULL, day TEXT NOT NULL, hour INTEGER NOT NULL, duration INTEGER NOT NULL, PRIMARY KEY(revision,activity))")
                }
            }).build().also { instance = it }
        }
    }
}
