package ma.salah.eddine.schoolmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        StudentEntity::class,
        SchoolClassEntity::class,
        SubjectEntity::class,
        EnrollmentEntity::class,
        EmployeeEntity::class,
        EmployeeServiceEntity::class,
        ReferenceValueEntity::class,
        TeacherAssignmentEntity::class,
        AppSettingEntity::class,
        ImportHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SchoolDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao

    companion object {
        @Volatile private var instance: SchoolDatabase? = null

        fun get(context: Context): SchoolDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                SchoolDatabase::class.java,
                "salah_eddine_school.db"
            ).build().also { instance = it }
        }
    }
}
