package ma.salah.eddine.schoolmanager.importing

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Small, bounded XLSX reader for the simple tabular workbooks used by this app. */
class XlsxDocument private constructor(
    val sheets: List<XlsxSheet>
) {
    companion object {
        private const val MAX_UNCOMPRESSED_BYTES = 64L * 1024 * 1024
        private const val MAX_ENTRIES = 2_000
        private const val REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

        fun read(input: InputStream): XlsxDocument {
            val entries = linkedMapOf<String, ByteArray>()
            var total = 0L
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        require(entries.size < MAX_ENTRIES) { "يحتوي الملف على عدد كبير من المكونات." }
                        val output = ByteArrayOutputStream()
                        val buffer = ByteArray(8_192)
                        while (true) {
                            val n = zip.read(buffer)
                            if (n < 0) break
                            total += n
                            require(total <= MAX_UNCOMPRESSED_BYTES) { "حجم ملف Excel بعد فك الضغط أكبر من الحد المسموح." }
                            output.write(buffer, 0, n)
                        }
                        entries[entry.name] = output.toByteArray()
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }

            val workbook = entries["xl/workbook.xml"]
                ?: throw IllegalArgumentException("تعذر العثور على بنية المصنف داخل ملف XLSX.")
            val rels = entries["xl/_rels/workbook.xml.rels"]
                ?: throw IllegalArgumentException("تعذر العثور على روابط أوراق العمل داخل الملف.")
            val sharedStrings = entries["xl/sharedStrings.xml"]?.let(::parseSharedStrings).orEmpty()
            val targets = parseRelationships(rels)
            val sheetNames = parseSheetNames(workbook)
            val sheets = sheetNames.mapNotNull { (name, relId) ->
                val target = targets[relId] ?: return@mapNotNull null
                val path = normalizeWorkbookTarget(target)
                val bytes = entries[path] ?: return@mapNotNull null
                XlsxSheet(name, parseWorksheet(bytes, sharedStrings))
            }
            require(sheets.isNotEmpty()) { "لم أجد أي ورقة قابلة للقراءة في ملف XLSX." }
            return XlsxDocument(sheets)
        }

        private fun normalizeWorkbookTarget(target: String): String {
            val clean = target.removePrefix("/")
            return if (clean.startsWith("xl/")) clean else "xl/$clean"
        }

        private fun parser(bytes: ByteArray): XmlPullParser = Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
            setInput(ByteArrayInputStream(bytes), "UTF-8")
        }

        private fun parseRelationships(bytes: ByteArray): Map<String, String> {
            val result = mutableMapOf<String, String>()
            val p = parser(bytes)
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && p.name == "Relationship") {
                    val id = p.getAttributeValue(null, "Id")
                    val target = p.getAttributeValue(null, "Target")
                    if (id != null && target != null) result[id] = target
                }
                event = p.next()
            }
            return result
        }

        private fun parseSheetNames(bytes: ByteArray): List<Pair<String, String>> {
            val result = mutableListOf<Pair<String, String>>()
            val p = parser(bytes)
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && p.name == "sheet") {
                    val name = p.getAttributeValue(null, "name")
                    val id = p.getAttributeValue(REL_NS, "id")
                    if (name != null && id != null) result += name to id
                }
                event = p.next()
            }
            return result
        }

        private fun parseSharedStrings(bytes: ByteArray): List<String> {
            val result = mutableListOf<String>()
            val p = parser(bytes)
            var inSi = false
            var inText = false
            var current = StringBuilder()
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "si" -> { inSi = true; current = StringBuilder() }
                        "t" -> if (inSi) inText = true
                    }
                    XmlPullParser.TEXT, XmlPullParser.CDSECT -> if (inSi && inText) current.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name) {
                        "t" -> inText = false
                        "si" -> { result += current.toString(); inSi = false }
                    }
                }
                event = p.next()
            }
            return result
        }

        private fun parseWorksheet(bytes: ByteArray, shared: List<String>): Map<CellAddress, String> {
            val cells = mutableMapOf<CellAddress, String>()
            val p = parser(bytes)
            var inCell = false
            var cellType: String? = null
            var address: CellAddress? = null
            var value = StringBuilder()
            var inValue = false
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "c" -> {
                            inCell = true
                            address = p.getAttributeValue(null, "r")?.let(::parseAddress)
                            cellType = p.getAttributeValue(null, "t")
                            value = StringBuilder()
                        }
                        "v", "t" -> if (inCell) inValue = true
                    }
                    XmlPullParser.TEXT, XmlPullParser.CDSECT -> if (inCell && inValue) value.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name) {
                        "v", "t" -> inValue = false
                        "c" -> {
                            val raw = value.toString()
                            val decoded = if (cellType == "s") {
                                raw.toIntOrNull()?.let(shared::getOrNull).orEmpty()
                            } else raw
                            if (address != null && decoded.isNotEmpty()) cells[address!!] = decoded
                            inCell = false
                            address = null
                        }
                    }
                }
                event = p.next()
            }
            return cells
        }

        private fun parseAddress(value: String): CellAddress? {
            val match = Regex("^([A-Z]+)([0-9]+)$").matchEntire(value) ?: return null
            var column = 0
            for (char in match.groupValues[1]) column = column * 26 + (char - 'A' + 1)
            val row = match.groupValues[2].toIntOrNull() ?: return null
            return CellAddress(row, column)
        }
    }
}

data class CellAddress(val row: Int, val column: Int)

class XlsxSheet(val name: String, private val cells: Map<CellAddress, String>) {
    fun cell(row: Int, column: Int): String? = cells[CellAddress(row, column)]
    fun populatedCells(): Map<CellAddress, String> = cells
}
