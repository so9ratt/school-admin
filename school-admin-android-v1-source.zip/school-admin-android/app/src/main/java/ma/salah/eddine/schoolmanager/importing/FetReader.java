package ma.salah.eddine.schoolmanager.importing;

import java.io.*;
import java.util.*;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

/** Reads assigned starting times, not optional scheduling preferences. */
public final class FetReader extends DefaultHandler {
    public static final class Lesson {
        public String id, teacher, subject, students, room, day, hour;
        public int duration;
    }
    private final Map<String,Lesson> activities = new LinkedHashMap<>();
    private final Map<String,String> times = new HashMap<>(), rooms = new HashMap<>();
    private final Map<String,String> fields = new HashMap<>();
    private final StringBuilder text = new StringBuilder();
    private final List<String> path = new ArrayList<>();
    private String record = "";

    public static List<Lesson> read(InputStream stream) throws Exception {
        FetReader handler = new FetReader();
        XMLReader xml = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
        xml.setEntityResolver((pub, sys) -> { throw new SAXException("مرجع XML خارجي غير مدعوم"); });
        xml.setContentHandler(handler);
        xml.parse(new InputSource(stream));
        check(!handler.activities.isEmpty(), "لم يتم العثور على أنشطة FET");
        for (Lesson lesson : handler.activities.values()) {
            String time = handler.times.get(lesson.id);
            check(time != null, "لم يتم توزيع جميع الأنشطة. اختاري ملف data_and_timetable.fet");
            String[] parts = time.split("/");
            lesson.day = parts[0]; lesson.hour = parts[1];
            check(lesson.duration + Integer.parseInt(lesson.hour.substring(1)) <= 5, "حصة تتجاوز نصف اليوم");
            lesson.room = handler.rooms.getOrDefault(lesson.id, "");
        }
        return new ArrayList<>(handler.activities.values());
    }
    private static void check(boolean ok,String reason) throws SAXException {
        if (!ok) throw new SAXException(reason);
    }
    @Override public void startElement(String uri,String local,String tag,Attributes attrs) throws SAXException {
        path.add(tag);
        check(path.size() < 64, "تداخل XML غير صالح");
        if(path.size()==1) check(tag.equals("fet"), "الملف ليس مشروع FET");
        if(path.size()==3 && ((path.get(1).equals("Activities_List") && tag.equals("Activity")) ||
           (path.get(1).equals("Time_Constraints_List") && tag.equals("ConstraintActivityPreferredStartingTime")) ||
           (path.get(1).equals("Space_Constraints_List") && tag.equals("ConstraintActivityPreferredRoom")))) {
            record=tag; fields.clear();
        }
        text.setLength(0);
    }
    @Override public void characters(char[] data,int start,int len) {
        if (!record.isEmpty() && path.size()==4) text.append(data,start,len);
    }
    @Override public void endElement(String uri,String local,String tag) throws SAXException {
        if(!record.isEmpty() && path.size()==4) {
            String old=fields.put(tag,text.toString().trim());
            if (old!=null && (tag.equals("Students") || tag.equals("Teacher")))
                throw new SAXException("يتضمن النشاط أكثر من أستاذ أو مجموعة؛ يلزم مراجعة صيغة الملف");
        }
        if(!record.isEmpty() && path.size()==3) { finish(); record=""; }
        path.remove(path.size()-1);
    }
    private String get(String key) { return fields.getOrDefault(key,""); }
    private void finish() throws SAXException {
        if(get("Active").equalsIgnoreCase("false")) return;
        if(record.equals("Activity")) {
            Lesson l=new Lesson(); l.id=get("Id"); l.teacher=get("Teacher"); l.subject=get("Subject");
            l.students=get("Students"); l.duration=Integer.parseInt(get("Duration"));
            check(l.duration>0 && !l.id.isEmpty() && !l.teacher.isEmpty() && !l.students.isEmpty() && !l.subject.isEmpty(),"نشاط غير مكتمل");
            check(activities.put(l.id,l)==null,"رقم نشاط مكرر");
        } else if("100".equals(get("Weight_Percentage")) || "100.0".equals(get("Weight_Percentage"))) {
            boolean timed=record.equals("ConstraintActivityPreferredStartingTime");
            String value=get("Room");
            if(timed) {
                String day=get("Preferred_Day").toLowerCase(Locale.ROOT), hour=get("Preferred_Hour");
                check(day.matches("(lundi|mardi|mercredi|jeudi|vendredi|samedi)_[ms]") && hour.matches("H[1-4]"),"توقيت غير معروف");
                value=day+"/"+hour;
            }
            String before=(timed ? times : rooms).put(get("Activity_Id"),value);
            check(before==null || before.equals(value),"تعارض في توقيت أو قاعة نشاط");
        }
    }
}
