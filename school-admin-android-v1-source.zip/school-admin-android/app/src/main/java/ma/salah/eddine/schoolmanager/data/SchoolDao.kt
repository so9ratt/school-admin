package ma.salah.eddine.schoolmanager.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert

@Dao
abstract class SchoolDao {
    @Query("SELECT * FROM family_contacts WHERE year = :year")
    abstract suspend fun familyForYear(year:String):List<FamilyContact>
    @Query("SELECT * FROM family_contacts WHERE year = :year AND massar = :massar")
    abstract suspend fun family(year:String,massar:String):List<FamilyContact>
    @Upsert
    abstract suspend fun storeFamily(rows:List<FamilyContact>)

    @Query("SELECT * FROM students ORDER BY surname, givenName")
    abstract suspend fun allStudents(): List<StudentEntity>

    @Query("SELECT * FROM students WHERE massarCode = :code LIMIT 1")
    abstract suspend fun student(code: String): StudentEntity?

    @Query("SELECT * FROM enrollments WHERE schoolYear = :year")
    abstract suspend fun enrollments(year: String): List<EnrollmentEntity>

    @Query("SELECT * FROM school_classes WHERE schoolYear = :year")
    abstract suspend fun schoolClasses(year: String): List<SchoolClassEntity>

    @Query("""
        SELECT s.massarCode, s.surname, s.givenName, s.gender, s.birthDate, s.birthPlace,
               c.levelName, e.className
        FROM students s JOIN enrollments e ON e.massarCode = s.massarCode
        JOIN school_classes c ON c.schoolYear = e.schoolYear AND c.className = e.className
        WHERE e.schoolYear = :year
        AND (:query = '' OR s.massarCode LIKE '%' || :query || '%'
             OR s.surname LIKE '%' || :query || '%' OR s.givenName LIKE '%' || :query || '%'
             OR s.birthDate LIKE '%' || :query || '%'
             OR (s.surname || ' ' || s.givenName) LIKE '%' || :query || '%')
        ORDER BY s.surname, s.givenName
    """)
    abstract suspend fun studentsForYear(year: String, query: String = ""): List<StudentListRow>

    @Query("SELECT DISTINCT className FROM enrollments WHERE schoolYear = :year ORDER BY className")
    abstract suspend fun classNames(year: String): List<String>

    @Query("SELECT c.className, c.levelName, COUNT(e.massarCode) AS studentCount FROM school_classes c LEFT JOIN enrollments e ON e.schoolYear = c.schoolYear AND e.className = c.className WHERE c.schoolYear = :year GROUP BY c.className, c.levelName ORDER BY c.levelName, c.className")
    abstract suspend fun classSummaries(year: String): List<ClassSummary>

    @Query("""
        SELECT s.massarCode, s.surname, s.givenName, s.gender, s.birthDate, s.birthPlace,
               c.levelName, e.className
        FROM students s JOIN enrollments e ON e.massarCode = s.massarCode
        JOIN school_classes c ON c.schoolYear = e.schoolYear AND c.className = e.className
        WHERE e.schoolYear = :year AND e.className = :className
        ORDER BY s.surname, s.givenName
    """)
    abstract suspend fun studentsInClass(year: String, className: String): List<StudentListRow>

    @Query("SELECT * FROM employees WHERE isCurrent = 1 ORDER BY nameArabic, nameFrench")
    abstract suspend fun allEmployees(): List<EmployeeEntity>

    @Query("SELECT * FROM employee_services WHERE isCurrent = 1 ORDER BY employeePpr, disciplineLabelFrench, levelCode")
    abstract suspend fun allEmployeeServices(): List<EmployeeServiceEntity>

    @Query("SELECT DISTINCT employeePpr FROM employee_services WHERE isCurrent = 1 AND employeePpr IS NOT NULL")
    abstract suspend fun employeesWithServices(): List<String>

    @Query("SELECT * FROM employee_services WHERE employeePpr = :ppr AND isCurrent = 1 ORDER BY disciplineLabelFrench, levelCode")
    abstract suspend fun employeeServices(ppr: String): List<EmployeeServiceEntity>

    @Query("SELECT * FROM teacher_assignments WHERE schoolYear = :year AND isCurrent = 1 ORDER BY subjectName, teacherName")
    abstract suspend fun assignments(year: String): List<TeacherAssignmentEntity>

    @Query("SELECT * FROM teacher_assignments WHERE schoolYear = :year AND className = :className AND isCurrent = 1 ORDER BY subjectName, teacherName")
    abstract suspend fun assignmentsForClass(year: String, className: String): List<TeacherAssignmentEntity>

    @Query("SELECT * FROM teacher_assignments WHERE schoolYear = :year AND teacherCode = :teacherCode AND isCurrent = 1 ORDER BY subjectName, className")
    abstract suspend fun assignmentsForTeacher(year: String, teacherCode: String): List<TeacherAssignmentEntity>

    @Query("SELECT * FROM reference_values")
    abstract suspend fun allReferenceValues(): List<ReferenceValueEntity>

    @Query("SELECT value FROM app_settings WHERE key = :key LIMIT 1")
    abstract suspend fun setting(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun saveSetting(setting: AppSettingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putStudents(items: List<StudentEntity>)

    @Upsert
    abstract suspend fun putClasses(items: List<SchoolClassEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun ensureClasses(items: List<SchoolClassEntity>)

    @Upsert
    abstract suspend fun putSubjects(items: List<SubjectEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putEnrollments(items: List<EnrollmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putEmployees(items: List<EmployeeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putEmployeeServices(items: List<EmployeeServiceEntity>)

    @Query("UPDATE employees SET isCurrent = 0")
    abstract suspend fun archiveEmployees()

    @Query("UPDATE employee_services SET isCurrent = 0")
    abstract suspend fun archiveEmployeeServices()

    @Transaction
    open suspend fun replaceCurrentEmployeeData(employees: List<EmployeeEntity>, services: List<EmployeeServiceEntity>) {
        archiveEmployees()
        archiveEmployeeServices()
        putEmployees(employees)
        putEmployeeServices(services)
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putReferences(items: List<ReferenceValueEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putAssignments(items: List<TeacherAssignmentEntity>)

    @Insert
    abstract suspend fun addImportHistory(item: ImportHistoryEntity)

    @Query("UPDATE teacher_assignments SET isCurrent = 0 WHERE schoolYear = :year")
    abstract suspend fun archiveAssignmentsForYear(year: String)

    @Transaction
    open suspend fun replaceAssignmentsForYear(year: String, items: List<TeacherAssignmentEntity>) {
        archiveAssignmentsForYear(year)
        putAssignments(items)
    }

    @Transaction
    open suspend fun commitStudentImport(
        students: List<StudentEntity>,
        classes: List<SchoolClassEntity>,
        enrollments: List<EnrollmentEntity>,
        settings: List<AppSettingEntity>,
        history: ImportHistoryEntity
    ) {
        putClasses(classes)
        putStudents(students)
        putEnrollments(enrollments)
        settings.forEach { saveSetting(it) }
        addImportHistory(history)
    }

    @Transaction
    open suspend fun commitEmployeeImport(
        employees: List<EmployeeEntity>,
        services: List<EmployeeServiceEntity>,
        references: List<ReferenceValueEntity>,
        history: ImportHistoryEntity
    ) {
        replaceCurrentEmployeeData(employees, services)
        putReferences(references)
        addImportHistory(history)
    }

    @Transaction
    open suspend fun commitTeachingImport(
        year: String,
        classes: List<SchoolClassEntity>,
        subjects: List<SubjectEntity>,
        assignments: List<TeacherAssignmentEntity>,
        history: ImportHistoryEntity
    ) {
        ensureClasses(classes)
        putSubjects(subjects)
        replaceAssignmentsForYear(year, assignments)
        saveSetting(AppSettingEntity("schoolYear", year))
        addImportHistory(history)
    }

    @Query("""
        SELECT
          (SELECT COUNT(*) FROM students s JOIN enrollments e ON e.massarCode = s.massarCode WHERE e.schoolYear = :year) AS studentCount,
          (SELECT COUNT(*) FROM enrollments WHERE schoolYear = :year) AS enrollmentCount,
          (SELECT COUNT(*) FROM school_classes WHERE schoolYear = :year) AS classCount,
          (SELECT COUNT(*) FROM employees WHERE isCurrent = 1) AS employeeCount,
          (SELECT COUNT(DISTINCT teacherCode) FROM teacher_assignments WHERE schoolYear = :year AND isCurrent = 1) AS scheduleTeacherCount
    """)
    abstract suspend fun dashboardCounts(year: String): DashboardCounts
}

data class DashboardCounts(
    val studentCount: Int,
    val enrollmentCount: Int,
    val classCount: Int,
    val employeeCount: Int,
    val scheduleTeacherCount: Int
)
