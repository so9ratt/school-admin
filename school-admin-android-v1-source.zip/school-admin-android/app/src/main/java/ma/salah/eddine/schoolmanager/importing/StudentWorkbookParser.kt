package ma.salah.eddine.schoolmanager.importing

import java.io.InputStream
import java.time.LocalDate

data class StudentImportRecord(
    val massarCode: String,
    val surname: String,
    val givenName: String,
    val gender: String,
    val birthDate: String,
    val birthPlace: String?,
    val levelName: String,
    val className: String
)

data class StudentSectionRecord(val className: String, val levelName: String)

data class StudentWorkbookPlan(
    val academy: String?,
    val province: String?,
    val institution: String?,
    val schoolYear: String,
    val sectionCount: Int,
    val sections: List<StudentSectionRecord>,
    val students: List<StudentImportRecord>,
    val warnings: List<String>
)

object StudentWorkbookParser {
    fun parse(input: InputStream): StudentWorkbookPlan {
        val workbook = XlsxDocument.read(input)
        val warnings = mutableListOf<String>()
        val all = mutableListOf<StudentImportRecord>()
        val sections = mutableListOf<StudentSectionRecord>()
        val seen = mutableSetOf<String>()
        var academy: String? = null
        var province: String? = null
        var institution: String? = null
        var schoolYear = ""
        var validSheets = 0

        workbook.sheets.forEach { sheet ->
            val currentAcademy = clean(sheet.cell(5, 3))
            val currentProvince = clean(sheet.cell(6, 3))
            val currentInstitution = clean(sheet.cell(6, 7))
            val currentYear = clean(sheet.cell(7, 7))
            val level = clean(sheet.cell(7, 3))
            val className = clean(sheet.cell(8, 3))
            if (className.isBlank() || level.isBlank()) {
                warnings += "الورقة «${sheet.name}»: بيانات القسم أو المستوى غير مكتملة، وتم تجاوزها."
                return@forEach
            }
            sections += StudentSectionRecord(className, level)
            if (sheet.name.trim() != className) {
                warnings += "الورقة «${sheet.name}»: اسم الورقة لا يطابق اسم القسم «$className»."
            }
            if (validSheets == 0) {
                academy = currentAcademy.takeIf { it.isNotBlank() }
                province = currentProvince.takeIf { it.isNotBlank() }
                institution = currentInstitution.takeIf { it.isNotBlank() }
                schoolYear = currentYear
            } else {
                if (currentAcademy.isNotBlank() && academy != currentAcademy) warnings += "توجد أكاديميات مختلفة بين الأوراق."
                if (currentInstitution.isNotBlank() && institution != currentInstitution) warnings += "توجد أسماء مؤسسات مختلفة بين الأوراق."
                if (currentYear.isNotBlank() && schoolYear != currentYear) warnings += "توجد مواسم دراسية مختلفة بين الأوراق."
            }
            validSheets++

            val rows = sheet.populatedCells().keys.asSequence()
                .filter { it.row >= 11 }
                .map { it.row }
                .distinct()
                .sorted()
            rows.forEach rowLoop@{ row ->
                val rawCode = clean(sheet.cell(row, 2))
                if (rawCode.isBlank()) {
                    if ((1..7).any { !clean(sheet.cell(row, it)).isBlank() }) {
                        warnings += "الورقة «${sheet.name}»، الصف $row: توجد بيانات دون رمز مسار."
                    }
                    return@rowLoop
                }
                if (!rawCode.all { it.isLetterOrDigit() }) {
                    warnings += "الورقة «${sheet.name}»، الصف $row: رمز مسار غير صالح."
                    return@rowLoop
                }
                val surname = clean(sheet.cell(row, 3))
                val givenName = clean(sheet.cell(row, 4))
                val gender = clean(sheet.cell(row, 5))
                val birthDate = normalizeBirthDate(clean(sheet.cell(row, 6)))
                val birthPlace = clean(sheet.cell(row, 7)).takeIf { it.isNotBlank() }
                if (surname.isBlank() || givenName.isBlank() || gender.isBlank() || birthDate.isBlank()) {
                    warnings += "الورقة «${sheet.name}»، الصف $row: بعض البيانات الأساسية ناقصة."
                }
                if (birthDate.isNotBlank() && !Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(birthDate)) {
                    warnings += "الورقة «${sheet.name}»، الصف $row: صيغة تاريخ الازدياد غير معروفة وسيتم الاحتفاظ بها كما وردت."
                }
                if (!seen.add(rawCode)) {
                    warnings += "رمز مسار مكرر في الملف: تمت قراءة أول سجل فقط ($rawCode)."
                    return@rowLoop
                }
                all += StudentImportRecord(rawCode, surname, givenName, gender, birthDate, birthPlace, level, className)
            }
        }
        require(validSheets > 0) { "لم أجد أوراقاً تحتوي على اسم قسم ومستوى في المواضع المتوقعة." }
        require(schoolYear.isNotBlank()) { "تعذر استخراج الموسم الدراسي من الملف." }
        return StudentWorkbookPlan(academy, province, institution, schoolYear, validSheets, sections.distinctBy { it.className }, all, warnings.distinct())
    }

    private fun normalizeBirthDate(value: String): String {
        if (Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(value)) return value
        val serial = value.toDoubleOrNull() ?: return value
        if (serial < 1 || serial > 100_000) return value
        return runCatching { LocalDate.of(1899, 12, 30).plusDays(serial.toLong()).toString() }.getOrDefault(value)
    }

    private fun clean(value: String?): String = value.orEmpty().replace(Regex("\\s+"), " ").trim()
}
