package ma.salah.eddine.schoolmanager

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.res.painterResource
import androidx.activity.compose.BackHandler
import ma.salah.eddine.schoolmanager.importing.FamilyBatch
import ma.salah.eddine.schoolmanager.importing.FamilyReview
import ma.salah.eddine.schoolmanager.importing.FamilyFile
import ma.salah.eddine.schoolmanager.data.FamilyContact
import ma.salah.eddine.schoolmanager.data.SchoolDao
import android.os.Bundle
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.AppSettingEntity
import ma.salah.eddine.schoolmanager.data.ClassSummary
import ma.salah.eddine.schoolmanager.data.DashboardCounts
import ma.salah.eddine.schoolmanager.data.EmployeeEntity
import ma.salah.eddine.schoolmanager.data.EmployeeServiceEntity
import ma.salah.eddine.schoolmanager.data.StudentListRow
import ma.salah.eddine.schoolmanager.data.TeacherAssignmentEntity
import ma.salah.eddine.schoolmanager.data.SchoolDatabase
import ma.salah.eddine.schoolmanager.importing.EmployeeImportDiff
import ma.salah.eddine.schoolmanager.importing.EmployeeImportPlan
import ma.salah.eddine.schoolmanager.importing.EmployeeXmlParser
import ma.salah.eddine.schoolmanager.importing.ImportCoordinator
import ma.salah.eddine.schoolmanager.importing.StudentImportDiff
import ma.salah.eddine.schoolmanager.importing.StudentWorkbookParser
import ma.salah.eddine.schoolmanager.importing.StudentWorkbookPlan
import ma.salah.eddine.schoolmanager.importing.TeacherLoadPlan
import ma.salah.eddine.schoolmanager.importing.TeacherLoadWorkbookParser
import ma.salah.eddine.schoolmanager.importing.TeachingImportDiff

private val Navy = Color(0xFF103F63)
private val Teal = Color(0xFF16829A)
private val Pale = Color(0xFFF3F8FA)
private val Ink = Color(0xFF173447)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SchoolApp() }
    }
}

private data class Module(val title: String, val subtitle: String, val route: String)

private val modules = listOf(
    Module("الإحصائيات", "مؤشرات المؤسسة", "statistics"),
    Module("لائحة التلاميذ", "الأقسام والمواد والأساتذة", "students"),
    Module("بطاقة التلميذ", "البحث بالاسم أو مسار أو القسم", "profiles"),
    Module("الأقسام والمستويات", "لوائح الأقسام", "classes"),
    Module("الأساتذة", "الموظفون والخدمات", "staff"),
    Module("توزيع الأقسام على الأساتذة", "توزيع الحصص", "teaching"),
    Module("استعمال الزمن", "الجداول الأسبوعية", "timetable"),
    Module("ورقة الدخول", "الغياب والتأخر وسجل التسليم", "slips"),
    Module("الإعدادات", "المؤسسة واستيراد الملفات", "settings")
)

private enum class ImportType { STUDENTS, EMPLOYEES, TEACHING }

private sealed interface ImportReview {
    val fileName: String
    data class Students(val plan: StudentWorkbookPlan, val diff: StudentImportDiff, override val fileName: String) : ImportReview
    data class Employees(val plan: EmployeeImportPlan, val diff: EmployeeImportDiff, override val fileName: String) : ImportReview
    data class Teaching(val plan: TeacherLoadPlan, val diff: TeachingImportDiff, override val fileName: String) : ImportReview
}

@Composable
private fun SchoolApp() {
    val context = LocalContext.current
    val dao = remember { SchoolDatabase.get(context).schoolDao() }
    var route by rememberSaveable { mutableStateOf("home") }
    var schoolName by rememberSaveable { mutableStateOf("الثانوية التأهيلية صلاح الدين الأيوبي") }
    var province by rememberSaveable { mutableStateOf("تاوريرت") }
    var academy by rememberSaveable { mutableStateOf("الشرق") }
    var schoolYear by rememberSaveable { mutableStateOf("2026/2027") }
    var counts by remember { mutableStateOf(DashboardCounts(0, 0, 0, 0, 0)) }
    var classSummaries by remember { mutableStateOf(emptyList<ClassSummary>()) }
    var selectedClass by rememberSaveable { mutableStateOf("") }
    var search by rememberSaveable { mutableStateOf("") }
    var studentRows by remember { mutableStateOf(emptyList<StudentListRow>()) }
    var classMembers by remember { mutableStateOf(emptyList<StudentListRow>()) }
    var classAssignments by remember { mutableStateOf(emptyList<TeacherAssignmentEntity>()) }
    var employeeRows by remember { mutableStateOf(emptyList<EmployeeEntity>()) }
    var employeeServiceRows by remember { mutableStateOf(emptyList<EmployeeServiceEntity>()) }
    var assignmentRows by remember { mutableStateOf(emptyList<TeacherAssignmentEntity>()) }
    var refreshKey by remember { mutableStateOf(0) }
    var importType by remember { mutableStateOf(ImportType.STUDENTS) }
    var review by remember { mutableStateOf<ImportReview?>(null) }
    var importError by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun displayName(uri: Uri): String {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment ?: "ملف مستورد"
    }

    var familyReview by remember { mutableStateOf<FamilyReview?>(null) }
    var scheduleClass by rememberSaveable { mutableStateOf("") }
    var scheduleReview by rememberSaveable { mutableStateOf(false) }
    var profile by remember { mutableStateOf<StudentListRow?>(null) }
    val familyPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            isLoading = true
            statusMessage = ""
            importError = ""
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        val files = mutableListOf<FamilyFile>()
                        val errors = mutableListOf<String>()
                        for (uri in uris.distinct()) {
                            val name = displayName(uri)
                            runCatching {
                                context.contentResolver.openInputStream(uri)?.use { FamilyBatch.parse(name,it) } ?: error("تعذر فتح الملف")
                            }.onSuccess { files += it }.onFailure { errors += "$name — ${it.message}" }
                        }
                        FamilyBatch.review(dao,files,schoolYear,errors)
                    }
                }.onSuccess { familyReview = it }.onFailure { importError = it.message ?: "تعذرت المعاينة" }
                isLoading = false
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val type = importType
            val fileName = displayName(uri)
            isLoading = true
            importError = ""
            scope.launch {
                val result = runCatching {
                    withContext(Dispatchers.IO) {
                        when (type) {
                            ImportType.STUDENTS -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(StudentWorkbookParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                ImportReview.Students(plan, ImportCoordinator.compareStudents(dao, plan), fileName)
                            }
                            ImportType.EMPLOYEES -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(EmployeeXmlParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                ImportReview.Employees(plan, ImportCoordinator.compareEmployees(dao, plan), fileName)
                            }
                            ImportType.TEACHING -> {
                                val plan = context.contentResolver.openInputStream(uri)?.use(TeacherLoadWorkbookParser::parse)
                                    ?: error("تعذر فتح الملف المختار.")
                                ImportReview.Teaching(plan, ImportCoordinator.compareTeaching(dao, plan), fileName)
                            }
                        }
                    }
                }
                result.onSuccess { review = it }.onFailure { importError = it.message ?: "تعذر تحليل الملف." }
                isLoading = false
            }
        }
    }

    fun chooseImport(type: ImportType) {
        importType = type
        importError = ""
        val mimeTypes = when (type) {
            ImportType.STUDENTS, ImportType.TEACHING -> arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            ImportType.EMPLOYEES -> arrayOf("application/xml", "text/xml", "text/*", "application/*")
        }
        picker.launch(mimeTypes)
    }

    fun confirmImport() {
        val chosen = review ?: return
        isLoading = true
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    when (chosen) {
                        is ImportReview.Students -> ImportCoordinator.importStudents(dao, chosen.plan, chosen.fileName, chosen.diff)
                        is ImportReview.Employees -> ImportCoordinator.importEmployees(dao, chosen.plan, chosen.fileName, chosen.diff)
                        is ImportReview.Teaching -> ImportCoordinator.importTeaching(dao, chosen.plan, chosen.fileName, chosen.diff)
                    }
                }
            }
            result.onSuccess {
                statusMessage = "تم اعتماد البيانات وحفظها على الجهاز."
                review = null
                refreshKey++
            }.onFailure { importError = it.message ?: "تعذر حفظ البيانات." }
            isLoading = false
        }
    }

    LaunchedEffect(refreshKey) {
        val saved = withContext(Dispatchers.IO) {
            listOf("schoolName", "province", "academy", "schoolYear").map { dao.setting(it) }
        }
        saved[0]?.let { schoolName = it }
        saved[1]?.let { province = it }
        saved[2]?.let { academy = it }
        saved[3]?.let { schoolYear = it }
        withContext(Dispatchers.IO) {
            dao.saveSetting(AppSettingEntity("schoolName", schoolName))
            dao.saveSetting(AppSettingEntity("province", province))
            dao.saveSetting(AppSettingEntity("academy", academy))
            dao.saveSetting(AppSettingEntity("schoolYear", schoolYear))
        }
    }

    LaunchedEffect(schoolYear, route, selectedClass, search, refreshKey) {
        val loaded = withContext(Dispatchers.IO) {
            val dashboard = dao.dashboardCounts(schoolYear)
            val classes = dao.classSummaries(schoolYear)
            val members = if (selectedClass.isNotBlank()) dao.studentsInClass(schoolYear, selectedClass) else emptyList()
            val aliases = dao.scheduleLabels().associate { it.key to it.value }
            fun named(rows: List<TeacherAssignmentEntity>) = rows.map { row -> aliases["fet.label.الأستاذ."+row.teacherCode.filterNot(Char::isWhitespace).uppercase()]?.let { row.copy(teacherName=it) } ?: row }
            val classLoad = if (selectedClass.isNotBlank()) dao.assignmentsForClass(schoolYear, selectedClass) else emptyList()
            val students = if (route == "students" || route == "profiles") dao.studentsForYear(schoolYear, search.trim().map { it.digitToIntOrNull()?.digitToChar() ?: it }.joinToString("")) else emptyList()
            val employees = if (route in setOf("teaching","staff")) dao.allEmployees() else emptyList()
            val statsEmployees = if (route == "statistics") dao.allEmployees() else emptyList()
            val services = if (route == "statistics") dao.allEmployeeServices() else emptyList()
            val assignments = if (route == "teaching") dao.assignments(schoolYear) else emptyList()
            val statsStudents = if (route == "statistics") dao.studentsForYear(schoolYear) else students
            ScreenData(dashboard, classes, members, named(classLoad), students, employees, named(assignments), statsStudents, statsEmployees, services)
        }
        counts = loaded.counts
        classSummaries = loaded.classes
        classMembers = loaded.members
        classAssignments = loaded.classAssignments
        if (route == "students" || route == "profiles") studentRows = loaded.students
        if (route in setOf("teaching","staff")) employeeRows = loaded.employees
        if (route == "teaching") assignmentRows = loaded.assignments
        if (route == "statistics") {
            studentRows = loaded.statsStudents
            employeeRows = loaded.statsEmployees
            employeeServiceRows = loaded.services
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Navy,
                secondary = Teal,
                background = Pale,
                surface = Color.White,
                primaryContainer = Color(0xFFDCEFF4),
                secondaryContainer = Color(0xFFE4F4E9),
                surfaceVariant = Color(0xFFEAF2F5),
                onSurfaceVariant = Navy,
                onPrimary = Color.White,
                onBackground = Ink,
                onSurface = Ink
            )
        ) {
            Surface(modifier = Modifier.fillMaxSize(), color = Pale) {
                Column(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
                    Header(schoolName, province, academy, route != "home") {
                        profile = null
                        route = "home"
                        selectedClass = ""
                        search = ""
                    }
                    BackHandler(enabled=route!="home"){ if(profile!=null) profile=null else route="home" }
                    val student = profile
                    if (student != null) {
                        var family by remember(student, schoolYear) { mutableStateOf(emptyList<FamilyContact>()) }
                        LaunchedEffect(student,schoolYear) { family = dao.family(schoolYear,student.massarCode) }
                        BackHandler { profile = null }
                        FamilyProfile(dao, schoolYear, student, family, onSchedule = { scheduleClass=student.className; scheduleReview=false; profile=null; route="timetable" }) { profile = null }
                    } else when (route) {
                        "home" -> HomeScreen(counts, schoolYear, modules) { scheduleClass = ""; scheduleReview = false; selectedClass = ""; search = ""; route = it }
                        "students", "profiles" -> StudentsScreen(route == "profiles", studentRows, classSummaries, selectedClass, classMembers, classAssignments, { selectedClass = it }, search, onSearch = { search = it }, onStudent = { profile = it }, onBack = { route = "home" })
                        "classes" -> ClassesScreen(classSummaries, selectedClass, classMembers, classAssignments,
                            onSelect = { selectedClass = it }, onStudent = { profile = it }, onBack = { if (selectedClass.isNotBlank()) selectedClass = "" else route = "home" })
                        "staff" -> StaffScreen(employeeRows) { route = "home" }
                        "slips" -> SlipsScreen(dao,schoolYear,classSummaries.map { it.className }) { route="home" }
                        "teaching" -> TeachingScreen(assignmentRows,employeeRows,{code,name ->
                            scope.launch { dao.saveSetting(AppSettingEntity("fet.label.الأستاذ."+code.filterNot(Char::isWhitespace).uppercase(),name));refreshKey++ }
                        }) { route = "home" }
                        "statistics" -> StatisticsScreen(counts, schoolYear, studentRows, employeeRows, employeeServiceRows) { route = "home" }
                        "timetable" -> WeekScreen(dao,schoolYear,scheduleClass,scheduleReview) { route = "home" }
                        "settings" -> SettingsScreen(
                            counts = counts,
                            schoolName = schoolName,
                            onSchoolName = { value -> schoolName = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("schoolName", value)) } },
                            province = province,
                            onProvince = { value -> province = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("province", value)) } },
                            academy = academy,
                            onAcademy = { value -> academy = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("academy", value)) } },
                            schoolYear = schoolYear,
                            onSchoolYear = { value -> schoolYear = value; scope.launch(Dispatchers.IO) { dao.saveSetting(AppSettingEntity("schoolYear", value)) } },
                            onImport = ::chooseImport,
                            timetableImport = { FetImport(dao,schoolYear) { scheduleClass=""; scheduleReview=true; route="timetable" } },
                            onFamily = { familyPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) },
                            error = importError,
                            status = statusMessage,
                            isLoading = isLoading,
                            onBack = { route = "home" }
                        )
                        else -> HomeScreen(counts, schoolYear, modules) { scheduleClass = ""; scheduleReview = false; selectedClass = ""; search = ""; route = it }
                    }
                }
            }
            familyReview?.let { batch ->
                AlertDialog(onDismissRequest = { if (!isLoading) familyReview = null },
                    title = { Text("معاينة ملفات أولياء الأمور") },
                    text = {
                        LazyColumn(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            item { Text("سجلات الاتصال الجديدة أو المتغيرة: ${batch.contacts.size}") }
                            items(batch.notes) { Text(it, fontSize = 13.sp) }
                        }
                    },
                    dismissButton = { OutlinedButton(onClick = { familyReview = null }, enabled = !isLoading) { Text("إغلاق") } },
                    confirmButton = { Button(enabled = !isLoading && batch.contacts.isNotEmpty(), onClick = {
                        isLoading = true
                        scope.launch {
                            runCatching { dao.storeFamily(batch.contacts) }.onSuccess {
                                statusMessage = "تم حفظ بيانات الأسرة على الجهاز."
                            }.onFailure { importError = it.message ?: "تعذر حفظ بيانات الأسرة" }
                            familyReview = null
                            isLoading = false
                        }
                    }) { Text("تأكيد حفظ المطابقات") } })
            }
            if (review != null) {
                ImportPreviewDialog(review!!, isLoading, onDismiss = { if (!isLoading) review = null }, onConfirm = ::confirmImport)
            }
        }
    }
}

private data class ScreenData(
    val counts: DashboardCounts,
    val classes: List<ClassSummary>,
    val members: List<StudentListRow>,
    val classAssignments: List<TeacherAssignmentEntity>,
    val students: List<StudentListRow>,
    val employees: List<EmployeeEntity>,
    val assignments: List<TeacherAssignmentEntity>,
    val statsStudents: List<StudentListRow>,
    val statsEmployees: List<EmployeeEntity>,
    val services: List<EmployeeServiceEntity>
)

@Composable
private fun Header(schoolName: String, province: String, academy: String, showBack: Boolean, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (showBack) {
            IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = Navy)
            }
        }
        Image(painterResource(R.drawable.moasasati_foreground), "شعار مؤسستي", Modifier.size(48.dp))
        Column(Modifier.weight(1f)) {
            Text("مؤسستي", color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(schoolName, color = Teal, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun HomeScreen(counts: DashboardCounts, year: String, modulesList: List<Module>, open: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(pageInset()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                SummaryCard("التلاميذ", counts.studentCount.toString(), Modifier.weight(1f))
                SummaryCard("الأقسام", counts.classCount.toString(), Modifier.weight(1f))
                SummaryCard("الموظفون", counts.employeeCount.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الموسم الدراسي $year", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Navy)
                Text("مؤسستي • إدارة مدرسية ذكية", color = Teal, fontSize = 12.sp)
            }
        }
        items(modulesList.chunked(2)) { line ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                line.forEach { module ->
                    Card(Modifier.weight(1f).clickable { open(module.route) },
                        colors=CardDefaults.cardColors(containerColor=if(module.route=="statistics") Navy else Color.White),
                        shape=RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().heightIn(min=86.dp).padding(12.dp),verticalArrangement=Arrangement.Center) {
                            Text(module.title,fontSize=16.sp,fontWeight=FontWeight.Bold,color=if(module.route=="statistics") Color.White else Navy)
                            Text(module.subtitle,fontSize=12.sp,color=if(module.route=="statistics") Color.White else Teal)
                        }
                    }
                }
                if(line.size==1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
internal fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier.heightIn(min = 60.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 22.sp, color = Teal, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 11.sp, color = Color(0xFF627484), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun StudentsScreen(profileSearch: Boolean, rows: List<StudentListRow>, classes: List<ClassSummary>, section: String, members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>, onSection: (String) -> Unit, query: String, onSearch: (String) -> Unit, onStudent: (StudentListRow) -> Unit, onBack: () -> Unit) {
    var level by rememberSaveable { mutableStateOf("") }
    val sections = classes.filter { level.isEmpty() || it.levelName == level }.map { it.className }.distinct().sorted()
    val visible = rows.filter { (level.isEmpty() || it.levelName == level) && (section.isEmpty() || it.className == section) }

    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle(if (profileSearch) "بطاقة التلميذ" else "لائحة التلاميذ", onBack)
        Text("التلاميذ: "+visible.size,style=MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = query,
            onValueChange = onSearch,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("الاسم أو مسار أو الرقم الترتيبي") },
            singleLine = true
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RosterFilter("حسب المستوى", level, classes.map { it.levelName }.filter { it.isNotBlank() }.distinct().sorted(), Modifier.weight(1f)) {
                level = it
                onSection("")
            }
            RosterFilter("حسب القسم", section, sections, Modifier.weight(1f)) { onSection(it) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (!profileSearch && section.isNotBlank()) {
                item { ClassOverview(members.filter { it.className == section }, assignments.filter { it.className == section }) }
            }
            if (visible.isEmpty()) item { EmptyCard("لا يوجد تلاميذ ضمن هذا الاختيار.") }
            items(visible, key = { it.massarCode }) { student ->
                Card(modifier = Modifier.clickable { onStudent(student) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("${student.ordinal ?: "—"}. ${student.givenName} ${student.surname}", color = Navy, fontWeight = FontWeight.Bold)
                        Text("${student.className} • ${student.levelName}", color = Teal, fontSize = 12.sp)
                        Text("مسار: ${student.massarCode}", color = Color(0xFF627484), fontSize = 11.sp)
                    }
                }
            }
        }
    }

}

@Composable
private fun ClassesScreen(classes: List<ClassSummary>, selected: String, members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>, onSelect: (String) -> Unit, onStudent: (StudentListRow) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle(if (selected.isBlank()) "الأقسام والمستويات" else selected, onBack)
        if (selected.isNotBlank()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item { ClassOverview(members.filter { it.className == selected }, assignments.filter { it.className == selected }) }
                item { Text("لائحة التلاميذ", color = Navy, fontWeight = FontWeight.Bold) }
                items(members, key = { it.massarCode }) { student ->
                    Card(modifier = Modifier.clickable { onStudent(student) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${student.ordinal ?: "—"}. ${student.givenName} ${student.surname}", color = Navy, fontWeight = FontWeight.SemiBold)
                            Text(student.massarCode, color = Color(0xFF627484), fontSize = 11.sp)
                        }
                    }
                }
            }
        } else if (classes.isEmpty()) {
            EmptyCard("ستظهر الأقسام تلقائياً بعد استيراد ملف التلاميذ.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("الأقسام: "+classes.size+"   •   المستويات: "+classes.distinctBy { it.levelName }.size) }
                classes.groupBy { it.levelName }.forEach { (level, levelClasses) ->
                    item { Text(level, fontWeight = FontWeight.Bold, color = Teal, modifier = Modifier.padding(top = 6.dp)) }
                    items(levelClasses, key = { it.className }) { summary ->
                    Card(Modifier.fillMaxWidth().clickable { onSelect(summary.className) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(summary.className, color = Navy, fontWeight = FontWeight.SemiBold)
                            Text("${summary.studentCount} تلميذاً", color = Color(0xFF627484), fontSize = 12.sp)
                        }
                    }
                    }
                }
            }
        }
    }
}

@Composable
private fun StaffScreen(employees: List<EmployeeEntity>, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf<EmployeeEntity?>(null) }
    chosen?.let { e ->
        BackHandler { chosen = null }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PageTitle("بطاقة الموظف") { chosen = null }
            listOf("الاسم بالعربية" to e.nameArabic, "الاسم بالفرنسية" to e.nameFrench, "رقم التأجير" to e.ppr,
                "المادة" to (e.disciplineLabelArabic ?: e.disciplineLabelFrench), "الإطار" to e.cadreLabel,
                "الدرجة" to e.gradeLabel, "الرتبة" to e.echelon, "الوضعية" to e.statusLabel,
                "الوضع الإداري" to e.positionLabel, "الوظيفة" to e.functionLabel, "الجنس" to e.gender,
                "تاريخ التوظيف" to e.recruitmentDate, "تاريخ الترسيم" to e.titularizationDate).forEach { (label,value) ->
                Text("$label: ${value?.takeIf { it.isNotBlank() } ?: "غير متوفر"}")
            }
        }
        return
    }
    val filtered = employees.filter {
        query.isBlank() || it.ppr.contains(query, true) || it.nameArabic.contains(query, true) ||
            it.nameFrench.contains(query, true) || it.disciplineLabelArabic.orEmpty().contains(query, true) ||
            it.disciplineLabelFrench.orEmpty().contains(query, true)
    }
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("الأساتذة والموظفون", onBack)
        Text("عدد السجلات: ${employees.size}", color = Teal, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("ابحث بالاسم أو PPR أو المادة") }, singleLine = true)
        if (employees.isEmpty()) EmptyCard("استورد ملف الموارد البشرية من الإعدادات لعرض الموظفين.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.ppr }) { employee ->
                Card(modifier = Modifier.clickable { chosen = employee }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(employee.nameArabic.ifBlank { employee.nameFrench }, color = Navy, fontWeight = FontWeight.Bold)
                        Text("PPR: ${employee.ppr}", color = Color(0xFF627484), fontSize = 11.sp)
                        val discipline = employee.disciplineLabelArabic ?: employee.disciplineLabelFrench
                        if (!discipline.isNullOrBlank()) Text("المادة/التخصص: $discipline", color = Teal, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TeachingScreen(assignments: List<TeacherAssignmentEntity>, employees:List<EmployeeEntity>, rename:(String,String)->Unit, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf("") }
    var editing by remember { mutableStateOf<TeacherAssignmentEntity?>(null) }
    var name by rememberSaveable { mutableStateOf("") }
    editing?.let { row ->
        AlertDialog(onDismissRequest={editing=null},title={Text("تسمية الأستاذ")},text={
            Column {
                OutlinedTextField(name,{name=it},label={Text("الاسم المعروض")})
                RosterFilter("اختر من لائحة الأساتذة","",employees.map { it.nameArabic.ifBlank { it.nameFrench } }.filter { it.isNotBlank() }.distinct(),Modifier.fillMaxWidth()){if(it.isNotBlank())name=it}
            }
        },confirmButton={Button(enabled=name.isNotBlank(),onClick={rename(row.teacherCode,name.trim());editing=null}){Text("حفظ")}},
        dismissButton={androidx.compose.material3.TextButton(onClick={editing=null}){Text("إلغاء")}})
    }
    val matches = assignments.filter { (section.isBlank() || section == it.className) &&
        (query.isBlank() || it.teacherName.contains(query,true) || it.className.contains(query,true) || it.subjectName.contains(query,true)) }
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("توزيع الأقسام على الأساتذة", onBack)
        Text("الأساتذة: "+matches.distinctBy { it.teacherCode }.size+"   •   الأقسام: "+matches.distinctBy { it.className }.size)
        OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("الأستاذ أو المادة أو القسم")})
        RosterFilter("حسب القسم",section,assignments.map { it.className }.distinct().sorted(),Modifier.fillMaxWidth()) { section=it }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)) {
            items(matches.groupBy { it.teacherCode }.values.toList()) { records ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text(records.first().teacherName, fontWeight=FontWeight.Bold)
                        androidx.compose.material3.TextButton(onClick={editing=records.first();name=records.first().teacherName}) { Text("تعديل اسم الأستاذ") }
                        Text(records.map { if(section.isBlank()) it.className else it.subjectName }.distinct().sorted().joinToString("، "))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatisticsScreen(
    counts: DashboardCounts,
    year: String,
    students: List<StudentListRow>,
    employees: List<EmployeeEntity>,
    services: List<EmployeeServiceEntity>,
    onBack: () -> Unit
) {
    val girls = students.count { it.gender.isFemaleValue() }
    val boys = students.count { it.gender.isMaleValue() }
    val unknownGender = students.size - girls - boys
    val total = students.size
    val levelCounts = students.groupingBy { it.levelName }.eachCount().toList().sortedByDescending { it.second }
    val classCounts = students.groupingBy { it.className }.eachCount().toList().sortedByDescending { it.second }
    val distinctClasses = students.map { it.className }.distinct().size
    val average = if (distinctClasses == 0) 0.0 else total.toDouble() / distinctClasses
    val linkedEmployeeCodes = services.mapNotNull { it.employeePpr }.distinct().size
    val disciplineCounts = employees.groupingBy { it.disciplineLabelArabic ?: it.disciplineLabelFrench ?: "غير محدد" }.eachCount()
        .toList().sortedByDescending { it.second }
    Column(Modifier.fillMaxSize().padding(pageInset()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("الإحصائيات", onBack)
        Text("الموسم الدراسي $year", color = Color(0xFF627484))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { SummaryCard("مجموع التلاميذ", total.toString(), Modifier.fillMaxWidth()) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("التوزيع حسب الجنس", color = Navy, fontWeight = FontWeight.Bold)
                        StatLine("الإناث (${percentage(girls, total)})", girls, total)
                        StatLine("الذكور (${percentage(boys, total)})", boys, total)
                        if (unknownGender > 0) StatLine("غير محدد (${percentage(unknownGender, total)})", unknownGender, total)
                    }
                }
            }
            item { SummaryCard("الأقسام", distinctClasses.toString(), Modifier.fillMaxWidth()) }
            item { SummaryCard("متوسط التلاميذ في القسم", String.format("%.1f", average), Modifier.fillMaxWidth()) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("التلاميذ حسب المستوى", color = Navy, fontWeight = FontWeight.Bold)
                        if (levelCounts.isEmpty()) Text("لا توجد بيانات بعد.", color = Color(0xFF627484))
                        levelCounts.forEach { (label, count) -> StatLine(label, count, total) }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("الأقسام الأكثر اكتظاظاً", color = Navy, fontWeight = FontWeight.Bold)
                        if (classCounts.isEmpty()) Text("لا توجد بيانات بعد.", color = Color(0xFF627484))
                        classCounts.forEach { (label, count) -> StatLine(label, count, classCounts.firstOrNull()?.second ?: 1) }
                    }
                }
            }
            item { SummaryCard("موظفون في XML", counts.employeeCount.toString(), Modifier.fillMaxWidth()) }
            item { SummaryCard("موظفون مرتبطون بصفوف خدمات XML", linkedEmployeeCodes.toString(), Modifier.fillMaxWidth()) }
            item { SummaryCard("معرفات أساتذة في مستخرج الحصص", counts.scheduleTeacherCount.toString(), Modifier.fillMaxWidth()) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("الموظفون حسب التخصص", color = Navy, fontWeight = FontWeight.Bold)
                        disciplineCounts.forEach { (label, count) -> StatLine(label, count, counts.employeeCount) }
                    }
                }
            }
        }
    }
}

private fun String.isFemaleValue(): Boolean = trim().lowercase() in setOf("أنثى", "انثى", "f", "féminin", "feminin", "female")
private fun String.isMaleValue(): Boolean = trim().lowercase() in setOf("ذكر", "m", "masculin", "male")
private fun percentage(value: Int, total: Int): String = if (total == 0) "0%" else "${(value * 100.0 / total).let { String.format(java.util.Locale.ROOT, "%.1f", it) }}%"

@Composable
private fun StatLine(label: String, value: Int, maxValue: Int) {
    val fraction = if (maxValue <= 0) 0f else (value.toFloat() / maxValue).coerceIn(0f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = Ink, modifier = Modifier.weight(1f))
            Text(value.toString(), fontSize = 12.sp, color = Teal, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0xFFE4EBF0), RoundedCornerShape(8.dp))) {
            Box(Modifier.fillMaxWidth(fraction).height(6.dp).background(Teal, RoundedCornerShape(8.dp)))
        }
    }
}

@Composable
private fun SettingsScreen(
    counts: DashboardCounts,
    schoolName: String,
    onSchoolName: (String) -> Unit,
    province: String,
    onProvince: (String) -> Unit,
    academy: String,
    onAcademy: (String) -> Unit,
    schoolYear: String,
    onSchoolYear: (String) -> Unit,
    onImport: (ImportType) -> Unit,
    timetableImport: @Composable () -> Unit,
    onFamily: () -> Unit,
    error: String,
    status: String,
    isLoading: Boolean,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(pageInset()).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("الإعدادات", onBack)
        Text("التلاميذ: ${counts.studentCount}   •   الأقسام: ${counts.classCount}   •   الموظفون: ${counts.employeeCount}")
        OutlinedTextField(value = schoolName, onValueChange = onSchoolName, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المؤسسة") }, singleLine = true)
        OutlinedTextField(value = province, onValueChange = onProvince, modifier = Modifier.fillMaxWidth(), label = { Text("المديرية الإقليمية") }, singleLine = true)
        OutlinedTextField(value = academy, onValueChange = onAcademy, modifier = Modifier.fillMaxWidth(), label = { Text("الأكاديمية الجهوية") }, singleLine = true)
        OutlinedTextField(value = schoolYear, onValueChange = onSchoolYear, modifier = Modifier.fillMaxWidth(), label = { Text("الموسم الدراسي") }, singleLine = true)
        Text("استيراد البيانات", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.padding(top = 4.dp))
        ImportButton("لائحة التلاميذ — Excel", "XLSX • الأقسام والبيانات الشخصية الدراسية", !isLoading) { onImport(ImportType.STUDENTS) }
        ImportButton("أولياء الأمور — Excel", "اختيار ملف أو عدة ملفات أقسام دفعة واحدة", !isLoading, onFamily)
        ImportButton("لائحة الموظفين — XML", "XML • بيانات إدارية وجداول مرجعية", !isLoading) { onImport(ImportType.EMPLOYEES) }
        ImportButton("مستخرج حصص الأساتذة — Excel", "XLSX • المادة والقسم وG1 وG2", !isLoading) { onImport(ImportType.TEACHING) }
        timetableImport()
        if (isLoading) Text("جارٍ تحليل الملف…", color = Teal, fontWeight = FontWeight.SemiBold)
        if (error.isNotBlank()) Text(error, color = Color(0xFFB3261E), fontSize = 13.sp)
        if (status.isNotBlank()) Text(status, color = Teal, fontSize = 13.sp)
        Text("تُحفظ البيانات محلياً على الجهاز. لن تُعتمد أي تغييرات قبل مراجعة المعاينة.", color = Color(0xFF627484), fontSize = 12.sp)
    }
}

@Composable
private fun ImportButton(title: String, subtitle: String, enabled: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = Navy, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color(0xFF627484), fontSize = 11.sp)
        }
    }
}

@Composable
private fun ImportPreviewDialog(review: ImportReview, busy: Boolean, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("معاينة الاستيراد", color = Navy, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الملف: ${review.fileName}", color = Color(0xFF627484), fontSize = 12.sp)
                when (review) {
                    is ImportReview.Students -> {
                        Text("الموسم الدراسي: ${review.plan.schoolYear}")
                        Text("الأوراق/الأقسام: ${review.plan.sectionCount}")
                        Text("التلاميذ المقروءون: ${review.plan.students.size}")
                        Text("جدد: ${review.diff.newStudents} • تحديث بيانات: ${review.diff.updatedProfiles}")
                        Text("انتقال بين الأقسام: ${review.diff.sectionTransfers} • دون تغيير: ${review.diff.unchangedStudents}")
                        review.diff.transferDetails.take(8).forEach { transfer ->
                            Text("${transfer.massarCode}: ${transfer.oldClass} ← ${transfer.newClass}", color = Teal, fontSize = 12.sp)
                        }
                        Text("موجودون سابقاً وغير واردين في هذا الملف: ${review.diff.notInNewFile} (لن يُحذفوا)")
                        Text("المؤسسة: ${review.plan.institution.orEmpty()}")
                    }
                    is ImportReview.Employees -> {
                        Text("الموظفون: ${review.plan.employees.size}")
                        Text("جدد: ${review.diff.newEmployees} • تحديثات: ${review.diff.updatedEmployees} • دون تغيير: ${review.diff.unchangedEmployees}")
                        Text("موظفون سابقون غير واردين في هذا الملف: ${review.diff.notInNewFile} (سيبقون محفوظين كبيانات سابقة)")
                        Text("جداول مرجعية: ${review.plan.referenceValues.size} • سجلات الأنشطة: ${review.plan.activityCount}")
                        Text("صفوف الخدمات: ${review.plan.serviceRecordCount} • موظفون مرتبطون بها: ${review.plan.employeesWithServiceRows} • دون صفوف مطابقة: ${review.plan.employeesWithoutServiceRows}")
                        Text("لن تُستورد أرقام الهوية والعناوين وأرقام الاتصال في هذه النسخة.", color = Teal, fontSize = 12.sp)
                    }
                    is ImportReview.Teaching -> {
                        Text("الموسم الدراسي: ${review.plan.schoolYear}")
                        Text("الأقسام: ${review.plan.sectionCount} • أعمدة المجموعات: ${review.plan.subgroupCount}")
                        Text("المواد: ${review.plan.subjectCount} • معرفات الأساتذة: ${review.plan.teacherCount}")
                        Text("إسنادات المادة والقسم/المجموعة: ${review.plan.assignments.size}")
                        Text("مجموع القيم المقروءة: ${review.plan.statedLessonTotal}")
                        Text("جديدة: ${review.diff.newAssignments} • متغيرة: ${review.diff.changedAssignments} • دون تغيير: ${review.diff.unchangedAssignments}")
                        Text("غير واردة في الملف الجديد: ${review.diff.noLongerListed} (ستُحفظ كسجلات غير حالية)")
                    }
                }
                val warnings = when (review) {
                    is ImportReview.Students -> review.plan.warnings
                    is ImportReview.Employees -> review.plan.warnings
                    is ImportReview.Teaching -> review.plan.warnings
                }
                if (warnings.isNotEmpty()) {
                    Text("ملاحظات (${warnings.size})", color = Color(0xFFB26A00), fontWeight = FontWeight.Bold)
                    warnings.take(8).forEach { Text("• $it", fontSize = 12.sp, color = Color(0xFF6B5A3C)) }
                    if (warnings.size > 8) Text("… وهناك ${warnings.size - 8} ملاحظات أخرى.", fontSize = 12.sp)
                }
            }
        },
        confirmButton = { Button(onClick = onConfirm, enabled = !busy) { Text(if (busy) "جارٍ الحفظ…" else "تأكيد الاستيراد") } },
        dismissButton = { OutlinedButton(onClick = onDismiss, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
private fun PageTitle(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("رجوع", color = Teal, modifier = Modifier.clickable(onClick = onBack).padding(6.dp))
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Text(message, Modifier.fillMaxWidth().padding(18.dp), color = Color(0xFF526777), fontSize = 14.sp, lineHeight = 22.sp)
    }
}

@Composable
internal fun RosterFilter(all: String, selected: String, options: List<String>, modifier: Modifier, select: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected.ifEmpty { all } + " ▾", maxLines = 2)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            (listOf("") + options).forEach { option ->
                DropdownMenuItem(text = { Text(option.ifEmpty { all }) }, onClick = {
                    select(option)
                    expanded = false
                })
            }
        }
    }
}

@Composable
private fun ClassOverview(members: List<StudentListRow>, assignments: List<TeacherAssignmentEntity>) {
    val girls = members.count { it.gender.isFemaleValue() }
    val boys = members.count { it.gender.isMaleValue() }
    val unknown = members.size - girls - boys
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            SummaryCard("التلاميذ", members.size.toString(), Modifier.weight(1f))
            SummaryCard("الإناث", girls.toString(), Modifier.weight(1f))
            SummaryCard("الذكور", boys.toString(), Modifier.weight(1f))
        }
        if (unknown > 0) Text("جنس غير محدد: $unknown", fontSize = 12.sp)
        Text("المواد والأساتذة", color = Navy, fontWeight = FontWeight.Bold)
        if (assignments.isEmpty()) Text("لا توجد إسنادات لهذا القسم. يمكن استيراد مستخرج الحصص من الإعدادات.", fontSize = 13.sp)
        androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
            val columns = ((maxWidth.value + 8f) / 158f).toInt().coerceIn(1, 6)
            val subjects = assignments.groupBy { it.subjectName }.toList()
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                subjects.chunked(columns).forEach { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        line.forEach { (subject, lessons) ->
                            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(subject, color = Navy, fontWeight = FontWeight.SemiBold)
                                    lessons.distinctBy { it.teacherCode }.forEach { lesson ->
                                        Text(lesson.teacherName, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                        repeat(columns - line.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun pageInset() = if (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp <= 360) 10.dp else 14.dp

@Composable
private fun FamilyProfile(dao:SchoolDao,year:String,student: StudentListRow, contacts: List<FamilyContact>, onSchedule:()->Unit, back: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pageInset()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PageTitle("بطاقة التلميذ", back)
        Text("${student.ordinal ?: "—"}. ${student.givenName} ${student.surname}", color = Navy, fontWeight = FontWeight.Bold)
        PersonalSlips(dao,year,student.massarCode)
        Text("مسار: ${student.massarCode} • ${student.gender}")
        Text("${student.levelName} • ${student.className}")
        Text("الازدياد: ${student.birthDate} • ${student.birthPlace ?: "غير متوفر"}")
        OutlinedButton(onClick=onSchedule) { Text("استعمال زمن القسم") }
        val roles = listOf("الأب","الأم")
        for (role in roles) {
            val contact = contacts.find { it.role == role }
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(role, color = Teal, fontWeight = FontWeight.Bold)
                    Text("اسم $role: ${contact?.name.orEmpty().ifBlank { "غير متوفر" }}")
                    Text("الهاتف: ${contact?.phone.orEmpty().ifBlank { "غير متوفر" }}")
                    if (contact != null && contact.phone.isNotBlank()) OutlinedButton(onClick = {
                        val intent = android.content.Intent(android.content.Intent.ACTION_DIAL, Uri.fromParts("tel",contact.phone,null))
                        try { context.startActivity(intent) } catch (_: android.content.ActivityNotFoundException) {
                            android.widget.Toast.makeText(context,"تطبيق الاتصال غير متوفر",android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("فتح لوحة الاتصال") }
                }
            }
        }
    }
}
