package ma.salah.eddine.schoolmanager.importing

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import ma.salah.eddine.schoolmanager.data.EmployeeEntity
import ma.salah.eddine.schoolmanager.data.EmployeeServiceEntity
import ma.salah.eddine.schoolmanager.data.ReferenceValueEntity

data class EmployeeImportPlan(
    val employees: List<EmployeeEntity>,
    val services: List<EmployeeServiceEntity>,
    val referenceValues: List<ReferenceValueEntity>,
    val activityCount: Int,
    val serviceRecordCount: Int,
    val employeesWithServiceRows: Int,
    val employeesWithoutServiceRows: Int,
    val warnings: List<String>
)

object EmployeeXmlParser {
    private data class XmlRecord(val tag: String, val fields: Map<String, String>)

    fun parse(input: InputStream): EmployeeImportPlan {
        val records = readRootRecords(input)
        val people = records.filter { it.tag == "DATAIDENTIFPERSONNEL" }
        require(people.isNotEmpty()) { "لم أجد سجلات DATAIDENTIFPERSONNEL في ملف XML." }
        val activityRecords = records.filter { it.tag == "ACTIVITE" }
        val allTables = records.filter { it.tag.startsWith("R_") }
        val referenceRecords = allTables.filter { it.tag != "R_TABSERV" }
        val dictionaries = referenceRecords.groupBy { it.tag }
        val referenceValues = referenceRecords.mapNotNull { record ->
            val key = when (record.tag) {
                "R_Discip" -> "CD_Discip"
                "R_Position" -> "CD_Position"
                "R_Statut" -> "CD_Statut"
                "R_SitFam" -> "Sit_Fam"
                "R_FONCT" -> "CD_Fonc"
                "R_MODEAFFE" -> "CD_MODAFFE"
                "R_MOD_ACCES_GRADE" -> "MODAVGRA"
                "R_CentreForm" -> "NOM_ETABL"
                else -> record.fields.keys.firstOrNull { it.startsWith("CD_") } ?: return@mapNotNull null
            }
            val code = record.fields[key].orEmpty().trim()
            if (code.isBlank()) return@mapNotNull null
            val french = record.fields.entries.firstOrNull { it.key.startsWith("LL_") || it.key.startsWith("LIB_") || it.key.startsWith("DESL") }?.value?.trim()
            val arabic = record.fields.entries.firstOrNull { it.key.startsWith("LA_") }?.value?.trim()
            ReferenceValueEntity(record.tag, code, french?.takeIf { it.isNotBlank() }, arabic?.takeIf { it.isNotBlank() })
        }

        val activityByPpr = activityRecords.mapNotNull { record ->
            val ppr = record.fields["PPR"]?.trim().orEmpty()
            if (ppr.isBlank()) null else ppr to record.fields
        }.toMap()
        val services = allTables.filter { it.tag == "R_TABSERV" }
        val servicesByActivity = services.groupBy { it.fields["CD_ACTIVITES"]?.trim().orEmpty() }
        val pprByActivity = activityRecords.mapNotNull { record ->
            val ppr = record.fields["PPR"]?.trim().orEmpty()
            val code = record.fields["CD_ACTIVITES"]?.trim().orEmpty()
            if (ppr.isBlank() || code.isBlank()) null else code to ppr
        }.toMap()
        val warnings = mutableListOf<String>()
        val employees = people.mapNotNull { record ->
            val fields = record.fields
            val ppr = fields["PPR"]?.trim().orEmpty()
            val nameArabic = clean(fields["NOMA"])
            val nameFrench = clean(fields["NOML"])
            if (ppr.isBlank() || (nameArabic.isBlank() && nameFrench.isBlank())) {
                warnings += "يوجد سجل موظف ينقصه PPR أو الاسم، وتم تجاوزه."
                return@mapNotNull null
            }
            val activity = activityByPpr[ppr].orEmpty()
            val discipline = fields["CD_DISCIP"]
            val status = fields["CD_STATUT"]
            val position = fields["CD_POSITION"]
            val grade = fields["CD_GRADE"]
            val cadre = fields["CD_CADRE"]
            val function = activity["CD_FONC"]
            EmployeeEntity(
                ppr = ppr,
                nameArabic = nameArabic,
                nameFrench = nameFrench,
                gender = fields["GENRE"],
                disciplineCode = discipline,
                disciplineLabelFrench = lookup(dictionaries, "R_Discip", "CD_Discip", discipline, "LL_DISCIP"),
                disciplineLabelArabic = lookup(dictionaries, "R_Discip", "CD_Discip", discipline, "LA_DISCIP"),
                statusCode = status,
                statusLabel = lookup(dictionaries, "R_Statut", "CD_Statut", status, "LL_STATUT"),
                positionCode = position,
                positionLabel = lookup(dictionaries, "R_Position", "CD_Position", position, "LL_POSITION"),
                gradeCode = grade,
                gradeLabel = lookup(dictionaries, "R_GRADE", "CD_GRADE", grade, "LL_GRADE"),
                cadreCode = cadre,
                cadreLabel = lookup(dictionaries, "R_CADRE", "CD_CADRE", cadre, "LL_CADRE"),
                echelon = fields["ECHELON"],
                recruitmentDate = fields["DATE_REC"],
                titularizationDate = fields["DT_TITUL"],
                activityCode = activity["CD_ACTIVITES"],
                functionCode = function,
                functionLabel = lookup(dictionaries, "R_FONCT", "CD_Fonc", function, "LL_FONC"),
                institutionCode = activity["CD_ETAB"] ?: fields["CD_LAST_ETAB"]
            )
        }
        val employeesWithServices = employees.count { employee ->
            val code = employee.activityCode?.trim().orEmpty()
            code.isNotBlank() && !servicesByActivity[code].isNullOrEmpty()
        }
        val serviceEntities = services.mapNotNull { service ->
            val fields = service.fields
            val serviceCode = fields["CD_TSERVICE"]?.trim().orEmpty()
            val activityCode = fields["CD_ACTIVITES"]?.trim().orEmpty()
            if (serviceCode.isBlank() || activityCode.isBlank()) {
                warnings += "يوجد صف خدمة ينقصه رمز الخدمة أو النشاط، وتم تجاوزه."
                return@mapNotNull null
            }
            val discipline = fields["CD_DISCIP"]
            val track = fields["CD_FILIERE"]
            val level = fields["CD_NIVENS"]
            EmployeeServiceEntity(
                serviceCode = serviceCode,
                employeePpr = pprByActivity[activityCode],
                activityCode = activityCode,
                disciplineCode = discipline,
                disciplineLabelFrench = lookup(dictionaries, "R_Discip", "CD_Discip", discipline, "LL_DISCIP"),
                trackCode = track,
                trackLabel = lookup(dictionaries, "R_FILIERE", "CD_FILIERE", track, "LIB_Filière"),
                levelCode = level,
                levelLabel = lookup(dictionaries, "R_NIVEAUENS", "CD_NIVENS", level, "LL_NIVENS"),
                teachingHours = fields["NBR_HEURE_ENS"],
                extraHours = fields["NBR_HEURE_SUP"],
                classCount = fields["NBR_CLASSE"],
                statisticalCode = fields["NEFSTAT10"]
            )
        }
        return EmployeeImportPlan(
            employees = employees,
            services = serviceEntities,
            referenceValues = referenceValues.distinctBy { it.tableName to it.code },
            activityCount = activityRecords.size,
            serviceRecordCount = services.size,
            employeesWithServiceRows = employeesWithServices,
            employeesWithoutServiceRows = employees.size - employeesWithServices,
            warnings = warnings.distinct()
        )
    }

    private fun lookup(
        dictionaries: Map<String, List<XmlRecord>>,
        table: String,
        keyField: String,
        code: String?,
        valueField: String
    ): String? {
        if (code.isNullOrBlank()) return null
        return dictionaries[table].orEmpty().firstOrNull { it.fields[keyField]?.trim() == code.trim() }
            ?.fields?.get(valueField)?.trim()?.takeIf { it.isNotBlank() }
    }

    private fun clean(value: String?): String = value.orEmpty().replace(Regex("\\s+"), " ").trim()

    private fun readRootRecords(input: InputStream): List<XmlRecord> {
        val parser = Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
            setInput(input, "UTF-8")
        }
        val result = mutableListOf<XmlRecord>()
        var depth = 0
        var recordTag: String? = null
        var recordDepth = -1
        var fields = linkedMapOf<String, String>()
        var fieldName: String? = null
        var fieldDepth = -1
        var text = StringBuilder()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    depth++
                    val tag = parser.name.orEmpty()
                    if (depth == 2 && tag != "schema") {
                        recordTag = tag
                        recordDepth = depth
                        fields = linkedMapOf()
                    } else if (recordTag != null && depth == recordDepth + 1) {
                        fieldName = tag
                        fieldDepth = depth
                        text = StringBuilder()
                    }
                }
                XmlPullParser.TEXT, XmlPullParser.CDSECT -> if (fieldName != null) text.append(parser.text)
                XmlPullParser.END_TAG -> {
                    if (fieldName != null && depth == fieldDepth) {
                        fields[fieldName!!] = text.toString().trim()
                        fieldName = null
                        fieldDepth = -1
                    }
                    if (recordTag != null && depth == recordDepth) {
                        result += XmlRecord(recordTag!!, fields.toMap())
                        recordTag = null
                        recordDepth = -1
                    }
                    depth--
                }
            }
            event = parser.next()
        }
        return result
    }
}
