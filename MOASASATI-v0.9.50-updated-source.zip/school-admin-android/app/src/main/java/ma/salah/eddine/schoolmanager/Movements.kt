package ma.salah.eddine.schoolmanager

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.*
import ma.salah.eddine.schoolmanager.importing.*

private fun Movement.key() = listOf(year,kind,massar,eventDate)

@Composable
internal fun MovementImport(dao: SchoolDao, year: String, fileName: (Uri)->String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var preview by remember(year) { mutableStateOf(emptyList<MovementSheet>()) }
    var known by remember { mutableStateOf(emptyMap<List<String>,Movement>()) }
    var message by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true
            runCatching {
                withContext(Dispatchers.IO) {
                    val batch = uris.distinct().flatMap { uri ->
                        val name = fileName(uri)
                        context.contentResolver.openInputStream(uri)?.use { readMovementSheets(it,name,year) }
                            ?: error("تعذرت قراءة $name")
                    }
                    val conflicts = batch.flatMap { it.rows }.groupBy { it.key() }.any { it.value.distinct().size > 1 }
                    require(!conflicts) { "توجد معطيات متعارضة للحركة نفسها. راجع الملفات أو استوردها منفردة." }
                    batch to dao.movements(year).first().associateBy { it.key() }
                }
            }.onSuccess { (batch,old) -> preview=batch; known=old; message="" }
             .onFailure { message=it.localizedMessage.orEmpty() }
            busy = false
        }
    }
    OutlinedButton(enabled=!busy,onClick={picker.launch(arrayOf("application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/octet-stream"))},modifier=Modifier.fillMaxWidth()) {
        Text(if(busy) "جارٍ معالجة الملفات…" else "استيراد لوائح حركية التلاميذ")
    }
    if(message.isNotBlank()) Text(message)
    if(preview.isNotEmpty()) {
        val rows = preview.flatMap { it.rows }.distinctBy { it.key() }
        val valid = preview.all { it.errors.isEmpty() }
        AlertDialog(onDismissRequest={if(!busy)preview=emptyList()},title={Text("معاينة حركية التلاميذ")},
            text={ LazyColumn {
                item { Text("الأوراق ${preview.size}  •  جديدة ${rows.count { it.key() !in known }}  •  معدّلة ${rows.count { it.key() in known && known[it.key()] != it }}  •  مسجلة ${rows.count { known[it.key()] == it }}") }
                items(preview){sheet ->
                    HorizontalDivider()
                    Text(sheet.name,style=MaterialTheme.typography.labelMedium)
                    Text(MovementKind.valueOf(sheet.coverage.kind).label+" • "+sheet.coverage.level+" "+sheet.coverage.section)
                    Text("${sheet.rows.size} سجل")
                    sheet.errors.forEach { Text(it,color=MaterialTheme.colorScheme.error) }
                }
            }},confirmButton={TextButton(enabled=valid && !busy,onClick={
                busy=true
                scope.launch {
                    runCatching { dao.storeMovements(rows,preview.map { it.coverage }.distinct()) }
                        .onSuccess { message="تم حفظ لوائح الحركية";preview=emptyList() }
                        .onFailure { message="تعذر حفظ اللوائح";preview=emptyList() }
                    busy=false
                }
            }){Text("تأكيد الحفظ")}},dismissButton={TextButton(enabled=!busy,onClick={preview=emptyList()}){Text("إلغاء")}})
    }
}

@Composable
internal fun MovementScreen(dao: SchoolDao,year: String,school:String,academy:String,province:String,onStudent:(StudentListRow)->Unit,back:()->Unit) {
    val all by remember(year){dao.movements(year)}.collectAsState(initial=emptyList())
    val sheets by remember(year){dao.coverage(year)}.collectAsState(initial=emptyList())
    var selected by rememberSaveable(year){mutableStateOf("")}
    var query by rememberSaveable(selected){mutableStateOf("")}
    var level by rememberSaveable(selected){mutableStateOf("")}
    var section by rememberSaveable(selected){mutableStateOf("")}
    var roster by remember(year){mutableStateOf(emptyMap<String,StudentListRow>())}
    LaunchedEffect(year){ roster=dao.studentsForYear(year).associateBy { it.massarCode } }
    var compare by rememberSaveable(year){mutableStateOf(false)}
    var manual by rememberSaveable(year){mutableStateOf("")}
    val close = { if(compare) compare=false else if(selected.isBlank()) back() else selected="" }
    if(manual.isNotBlank()) ManualMovement(dao,year,manual,roster.values.toList()){manual=""}
    BackHandler(enabled=selected.isNotBlank() || compare){close()}
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        PageTitle(if(compare) "مقارنة المواسم الدراسية" else if(selected.isEmpty()) "حركية التلاميذ" else when(MovementKind.valueOf(selected)) {
            MovementKind.ARRIVAL -> "لائحة الوافدين"
            MovementKind.DEPARTURE -> "لائحة المغادرين"
            MovementKind.NON_ATTENDANCE -> "لائحة غير الملتحقين"
            MovementKind.DROPOUT -> "لائحة المنقطعين"
            MovementKind.RETURN -> "لائحة المرجعين"
            MovementKind.CLASS_CHANGE -> "تغيير القسم"
            MovementKind.INTEGRATED -> "لائحة المدمجين"
            MovementKind.DISMISSED -> "لائحة المفصولين"
        },close)
        Text("الموسم الدراسي $year", style=MaterialTheme.typography.labelLarge)
        if(compare) {
            SeasonComparisonScreen(dao,year,all,school,academy,province)
        } else if(selected.isEmpty()) {
            Text("تحيين لائحة التلاميذ من الإعدادات", fontSize = 12.sp)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick={compare=true},modifier=Modifier.fillMaxWidth()){Text("مقارنة المواسم الدراسية")}
            MovementKind.entries.forEach { kind ->
                val covered=sheets.filter { it.kind==kind.name }
                ElevatedCard(onClick={selected=kind.name},modifier=Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(kind.label,fontWeight=FontWeight.Bold)
                        Text("${all.filter { it.kind==kind.name }.distinctBy { it.massar }.size} تلميذاً")
                    }
                }
            }
            }
        } else {
            if(selected in listOf("RETURN","INTEGRATED","DISMISSED")) Button(onClick={manual=selected}){Text("إضافة سجل")}
            val covered=sheets.filter { it.kind==selected }
            val rows=all.filter { it.kind==selected }
            fun classOf(m:Movement)=m.section.ifBlank { roster[m.massar]?.takeIf { it.levelName.trim()==m.level.trim() }?.className.orEmpty() }
            val levels=(covered.map { it.level }+roster.values.map { it.levelName }).distinct().sorted()
            val sections=rows.filter { level.isEmpty() || it.level==level }.map { classOf(it) }.filter(String::isNotBlank).distinct().sorted()
            if(covered.isNotEmpty()) Text("المستويات المستوردة ${covered.distinctBy { it.level }.size}",style=MaterialTheme.typography.labelMedium)
            SearchBox(query,{query=it},"الاسم أو رمز مسار")
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                RosterFilter("حسب المستوى",level,levels,Modifier.weight(1f)){level=it;section=""}
                RosterFilter("حسب القسم",section,sections,Modifier.weight(1f)){section=it}
            }
            val visible=rows.filter { (level.isEmpty() || it.level==level) && (section.isEmpty() || classOf(it)==section) &&
                pupilPrefix(query,it.fullName,it.massar) }
            Text("التلاميذ ${visible.distinctBy { it.massar }.size}  •  السجلات ${visible.size}")
            TableExport(MovementKind.valueOf(selected).label,school,academy,province,year,listOf("مسار","الاسم","القسم","التاريخ","من","إلى"),visible.groupBy { classOf(it).ifBlank { "بدون قسم" } }.map { (name,rs) -> ExportGroup(name,rs.map { listOf(it.massar,it.fullName,classOf(it),it.eventDate,it.origin,it.destination) }) })
            LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                items(visible){m -> Card(onClick={roster[m.massar]?.let(onStudent)},enabled=m.massar in roster,modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(disabledContainerColor=MaterialTheme.colorScheme.surface,disabledContentColor=MaterialTheme.colorScheme.onSurface)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(listOfNotNull((m.ordinal ?: roster[m.massar]?.ordinal)?.toString(),m.fullName,m.massar).joinToString("  •  "),fontWeight=FontWeight.Bold)
                        Text(listOf(m.level,classOf(m),m.eventDate).filter(String::isNotBlank).joinToString("  •  "))
                        if(m.origin.isNotBlank()) Text("من "+m.origin)
                        if(m.destination.isNotBlank()) Text("إلى "+m.destination)
                    }
                } }
            }
        }
    }
}

@Composable
private fun ManualMovement(dao:SchoolDao,year:String,kind:String,roster:List<StudentListRow>,close:()->Unit) {
    val scope=rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("") }
    var section by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest={if(!busy)close()},title={Text(MovementKind.valueOf(kind).label)},text={
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(5.dp)) {
            SearchBox(query,{query=it},"بحث في لائحة التلاميذ")
            if(query.isNotBlank()) roster.filter { pupilPrefix(query,it.givenName,it.surname,it.massarCode) }.forEach { s ->
                TextButton(onClick={code=s.massarCode;name=s.givenName+" "+s.surname;level=s.levelName;section=s.className;query=""}){Text(s.givenName+" "+s.surname+" • "+s.className)}
            }
            Text("أو أدخل بيانات التلميذ من خارج اللائحة")
            OutlinedTextField(code,{code=it},label={Text("رمز مسار")},singleLine=true)
            OutlinedTextField(name,{name=it},label={Text("الاسم الكامل")})
            OutlinedTextField(level,{level=it},label={Text("المستوى")})
            OutlinedTextField(section,{section=it},label={Text("القسم")})
            DayPicker(date){date=it}
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
        }
    },confirmButton={Button(enabled=!busy && code.isNotBlank() && name.isNotBlank(),onClick={
        busy=true;scope.launch {
            val massar=code.trim().uppercase(java.util.Locale.ROOT)
            runCatching { dao.putMovements(listOf(Movement(year,kind,massar,date,name.trim(),level.trim(),section.trim(),"","","",roster.firstOrNull { it.massarCode==massar }?.ordinal))) }
                .onSuccess { close() }.onFailure { error="تعذر الحفظ";busy=false }
        }
    }){Text("حفظ")}},dismissButton={TextButton(enabled=!busy,onClick=close){Text("إلغاء")}})
}

@Composable
private fun SeasonComparisonScreen(dao:SchoolDao,year:String,events:List<Movement>,school:String,academy:String,province:String) {
    val years by produceState(emptyList<String>(),dao,year){value=dao.availableYears().filter { candidate -> val earlier=AcademicSeason.parse(candidate);val active=AcademicSeason.parse(year);earlier!=null && active!=null && earlier<active }}
    var previous by rememberSaveable(year){mutableStateOf("")}
    val current by produceState(emptyList<StudentListRow>(),dao,year){value=dao.studentsForYear(year)}
    val old by produceState(emptyList<StudentListRow>(),dao,previous){value=if(previous.isBlank()) emptyList() else dao.studentsForYear(previous)}
    val comparison=SeasonComparison.compare(old.map { it.massarCode },current.map { it.massarCode },events.filter { it.kind=="DISMISSED" }.map { it.massar },events.filter { it.kind in listOf("DEPARTURE","NON_ATTENDANCE","DROPOUT","RETURN","INTEGRATED") }.map { it.massar })
    var filter by rememberSaveable {mutableStateOf("المستمرون")}
    val groups=mapOf("المستمرون" to comparison.continuing,"الجدد في اللائحة" to comparison.newToList,"غير الموجودين في اللائحة" to comparison.missing,"المفصولون المؤكدون" to comparison.confirmedDismissed,"وضعية غير محسومة" to comparison.unresolved)
    RosterFilter("اختر الموسم للمقارنة",previous,years,Modifier.fillMaxWidth()){previous=it}
    if(previous.isBlank()) {Text("اختر موسماً آخر محفوظاً");return}
    if(old.isEmpty() || current.isEmpty()) {Text("تنبيه: إحدى اللوائح فارغة، لا تعتمد المقارنة قبل التحقق من الاستيراد");return}
    Text("عدم وجود التلميذ في اللائحة لا يعني فصله.")
    RosterFilter("الفئة",filter,groups.keys.toList(),Modifier.fillMaxWidth()){filter=it.ifBlank { "المستمرون" }}
    val oldMap=old.associateBy { it.massarCode.trim().uppercase(java.util.Locale.ROOT) }
    val currentMap=current.associateBy { it.massarCode.trim().uppercase(java.util.Locale.ROOT) }
    val rows=groups[filter].orEmpty().sorted().mapNotNull { code -> (currentMap[code] ?: oldMap[code])?.let { s ->
        val before=oldMap[code]; val after=currentMap[code]
        val status=if(before!=null && after!=null) { if(AcademicSeason.parse(year)!!.startYear-AcademicSeason.parse(previous)!!.startYear==1) classProgress(before.className,after.className) else "مقارنة بين موسمين غير متتاليين" } else ""
        listOf(code,s.givenName+" "+s.surname,before?.className.orEmpty(),after?.className.orEmpty(),status,events.filter { it.massar==code }.joinToString("، "){MovementKind.entries.firstOrNull { k -> k.name==it.kind }?.label ?: it.kind})
    } }
    Text(groups.entries.joinToString(" • "){"${it.key}: ${it.value.size}"})
    TableExport("مقارنة المواسم",school,academy,province,year,listOf("مسار","الاسم","القسم السابق","القسم الحالي","المستوى","الحركية"),listOf(ExportGroup(filter,rows)))
    LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)) { items(rows){row -> OutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(8.dp)){Text(row[1]+" • "+row[0]);Text(row.drop(2).filter(String::isNotBlank).joinToString(" • "))}}} }
}
