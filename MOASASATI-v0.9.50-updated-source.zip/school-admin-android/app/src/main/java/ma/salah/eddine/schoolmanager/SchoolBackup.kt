package ma.salah.eddine.schoolmanager

import android.content.Context
import ma.salah.eddine.schoolmanager.data.SchoolDatabase
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Offline backup of the full Room database, including all school settings and records. */
internal object SchoolBackup {
    private const val DB = "salah_eddine_school.db"
    private const val ENTRY = "database/$DB"
    private const val PENDING = "pending-school-restore.db"

    private val prefNames = listOf("councils_v1", "institution_people", "employee_tasks")
    private const val PREF_PENDING = "pending-school-preferences.json"

    fun export(context: Context, output: java.io.OutputStream) {
        val db = SchoolDatabase.get(context).openHelper.writableDatabase
        db.query("PRAGMA wal_checkpoint(FULL)").use { while (it.moveToNext()) {} }
        val file = context.getDatabasePath(DB)
        require(file.isFile) { "قاعدة البيانات غير موجودة" }
        ZipOutputStream(output).use { zip ->
            zip.putNextEntry(ZipEntry("backup-version.txt"))
            zip.write("MOASASATI_BACKUP_V1\n".toByteArray())
            zip.closeEntry()
            zip.putNextEntry(ZipEntry(ENTRY))
            file.inputStream().use { it.copyTo(zip) }
            zip.closeEntry()
            val root = org.json.JSONObject()
            prefNames.forEach { name ->
                val values = org.json.JSONObject()
                context.getSharedPreferences(name, Context.MODE_PRIVATE).all.forEach { (k,v) ->
                    if (v is String) values.put(k,v)
                }
                root.put(name,values)
            }
            zip.putNextEntry(ZipEntry("preferences.json"))
            zip.write(root.toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }

    /** Stage a verified backup for restoration before the next Room initialization. */
    fun stageRestore(context: Context, input: java.io.InputStream) {
        val staged = File(context.filesDir, "$PENDING.tmp")
        var marker = false
        var found = false
        var preferences: String? = null
        try {
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    when (entry.name) {
                        "backup-version.txt" -> marker = zip.readBytes().decodeToString().trim() == "MOASASATI_BACKUP_V1"
                        "preferences.json" -> {
                            val bytes = zip.readNBytes(16 * 1024 * 1024 + 1)
                            require(bytes.size <= 16 * 1024 * 1024)
                            val raw = bytes.toString(Charsets.UTF_8)
                            val root = org.json.JSONObject(raw)
                            prefNames.forEach { name ->
                                val obj = root.getJSONObject(name)
                                obj.keys().forEach { k -> require(obj.get(k) is String) }
                            }
                            preferences = raw
                        }
                        ENTRY -> {
                            staged.outputStream().use { out ->
                                val buffer = ByteArray(8192)
                                var size = 0L
                                while (true) {
                                    val n = zip.read(buffer)
                                    if (n < 0) break
                                    size += n
                                    require(size <= 200L * 1024 * 1024) { "الملف كبير جدًا" }
                                    out.write(buffer, 0, n)
                                }
                            }
                            found = true
                        }
                    }
                    zip.closeEntry()
                }
            }
            require(marker && found) { "هذا الملف ليس نسخة احتياطية صالحة لمؤسستي" }
            val header = ByteArray(16)
            staged.inputStream().use { require(it.read(header) == 16) }
            require(String(header, Charsets.US_ASCII) == "SQLite format 3\u0000") { "قاعدة البيانات غير صالحة" }
            android.database.sqlite.SQLiteDatabase.openDatabase(staged.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY).use { db ->
                db.rawQuery("PRAGMA integrity_check", null).use { cursor ->
                    require(cursor.moveToFirst() && cursor.getString(0) == "ok") { "قاعدة البيانات غير سليمة" }
                }
                db.rawQuery("SELECT COUNT(*) FROM entry_slips", null).use { require(it.moveToFirst()) }
            }
            val prefFile = File(context.filesDir, PREF_PENDING)
            prefFile.delete()
            preferences?.let { prefFile.writeText(it, Charsets.UTF_8) }
            val renamed = staged.renameTo(File(context.filesDir, PENDING))
            require(renamed) { "تعذر تجهيز الاستعادة" }
        } finally { staged.delete() }
    }

    /** Must run on a fresh process before SchoolDatabase.get(). */
    fun applyPending(context: Context): Int? {
        val pending = File(context.filesDir, PENDING)
        if (!pending.exists()) return null
        SchoolDatabase.closeForRestore()
        val target = context.getDatabasePath(DB)
        target.parentFile?.mkdirs()
        // Preserve the previous database if anything goes wrong during restoration.
        val previous = File(context.filesDir, "pre-restore-school.db")
        if (target.exists()) target.copyTo(previous, overwrite = true)
        val oldPreferences = prefNames.associateWith { name ->
            context.getSharedPreferences(name, Context.MODE_PRIVATE).all.toMap()
        }
        try {
            pending.copyTo(target, overwrite = true)
            File(target.path + "-wal").delete()
            File(target.path + "-shm").delete()
            val count = android.database.sqlite.SQLiteDatabase.openDatabase(target.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY).use { db ->
                db.rawQuery("SELECT COUNT(*) FROM entry_slips", null).use { cursor ->
                    check(cursor.moveToFirst())
                    cursor.getInt(0)
                }
            }
            val prefFile = File(context.filesDir, PREF_PENDING)
            if (prefFile.exists()) {
                val root = org.json.JSONObject(prefFile.readText(Charsets.UTF_8))
                prefNames.forEach { name ->
                    val obj = root.getJSONObject(name)
                    val editor = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
                    obj.keys().forEach { k -> editor.putString(k,obj.getString(k)) }
                    check(editor.commit()) { "تعذر استعادة بيانات المجالس" }
                }
                prefFile.delete()
            }
            pending.delete()
            previous.delete()
            return count
        } catch (e: Exception) {
            if (previous.exists()) previous.copyTo(target, overwrite = true)
            oldPreferences.forEach { (name, values) ->
                val editor = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
                values.forEach { (key, value) -> if (value is String) editor.putString(key, value) }
                if (!editor.commit()) e.addSuppressed(IllegalStateException("تعذر التراجع عن استعادة $name"))
            }
            throw e
        }
    }
}
