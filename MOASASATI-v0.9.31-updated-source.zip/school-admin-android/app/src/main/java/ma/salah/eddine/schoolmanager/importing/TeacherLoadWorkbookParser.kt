package ma.salah.eddine.schoolmanager.importing

import java.io.InputStream

data class TeacherLoadRecord(
    val teacherCode: String,
    val teacherName: String,
    val subjectName: String,
    val className: String,
    val subgroupName: String,
    val lessonCount: Int
)

data class TeacherLoadPlan(
    val schoolYear: String,
    val sectionCount: Int,
    val subgroupCount: Int,
    val subjectCount: Int,
    val teacherCount: Int,
    val statedLessonTotal: Int,
    val assignments: List<TeacherLoadRecord>,
    val warnings: List<String>
)

object TeacherLoadWorkbookParser {
    fun parse(input: InputStream): TeacherLoadPlan {
        val workbook = XlsxDocument.read(input)
        val sheet = workbook.sheets.first()
        val schoolYear = sheet.cell(6, 15)?.trim().orEmpty()
        // A missing/invalid year can be corrected explicitly in the import preview.
        val mainColumns = (6..64).filter { sheet.cell(13, it)?.trim() == "قسم" && !sheet.cell(12, it).isNullOrBlank() }
        val subgroupColumns = (6..64).filter { sheet.cell(13, it)?.contains(":G") == true }
        require(mainColumns.isNotEmpty()) { "لم أجد أعمدة الأقسام في الصف 12 من الملف." }

        val headings = (mainColumns + subgroupColumns).associateWith { column ->
            val header = sheet.cell(13, column)?.trim().orEmpty()
            if (header.contains(":G")) {
                val className = header.substringBefore(':').trim()
                val subgroup = header.substringAfter(':').trim()
                Triple(className, subgroup, true)
            } else {
                Triple(sheet.cell(12, column)?.trim().orEmpty(), "", false)
            }
        }

        val warnings = mutableListOf<String>()
        val assignments = mutableListOf<TeacherLoadRecord>()
        val teacherCodes = mutableSetOf<String>()
        val subjects = mutableSetOf<String>()
        var currentSubject = ""
        val rows = sheet.populatedCells().keys.asSequence().map { it.row }.distinct().sorted()
        rows.filter { it >= 15 }.forEach rowLoop@{ row ->
            val label = sheet.cell(row, 2)?.trim().orEmpty()
            // Excel can repeat the merged total label in both teacher cells.
            if (label.substringBefore(' ') == "المجموع") return@rowLoop
            if (label.isNotBlank()) currentSubject = label
            val teacherCode = sheet.cell(row, 3)?.trim().orEmpty()
            val teacherName = clean(sheet.cell(row, 4))
            if (teacherCode.isBlank() || teacherName.isBlank()) return@rowLoop
            if (currentSubject.isBlank()) {
                warnings += "الصف $row: لم أتمكن من تحديد المادة لهذا الأستاذ."
                return@rowLoop
            }
            teacherCodes += teacherCode
            subjects += currentSubject
            val rowAssignments = mutableListOf<TeacherLoadRecord>()
            headings.forEach columnLoop@{ (column, heading) ->
                val count = sheet.cell(row, column)?.trim()?.toIntOrNull() ?: return@columnLoop
                if (count <= 0) return@columnLoop
                rowAssignments += TeacherLoadRecord(
                    teacherCode = teacherCode,
                    teacherName = teacherName,
                    subjectName = currentSubject,
                    className = heading.first,
                    subgroupName = heading.second,
                    lessonCount = count
                )
            }
            val statedTotal = sheet.cell(row, 5)?.trim()?.toIntOrNull()
            val parsedTotal = rowAssignments.sumOf { it.lessonCount }
            if (statedTotal != null && statedTotal != parsedTotal) {
                warnings += "الصف $row: مجموع العمود E لا يساوي مجموع أعمدة الأقسام والمجموعات."
            }
            assignments += rowAssignments
        }
        require(assignments.isNotEmpty()) { "لم أجد إسنادات حصص قابلة للقراءة في الملف." }
        return TeacherLoadPlan(
            schoolYear = schoolYear,
            sectionCount = mainColumns.size,
            subgroupCount = subgroupColumns.size,
            subjectCount = subjects.size,
            teacherCount = teacherCodes.size,
            statedLessonTotal = assignments.sumOf { it.lessonCount },
            assignments = assignments,
            warnings = warnings.distinct()
        )
    }

    private fun clean(value: String?): String = value.orEmpty().replace(Regex("\\s+"), " ").trim()
}
