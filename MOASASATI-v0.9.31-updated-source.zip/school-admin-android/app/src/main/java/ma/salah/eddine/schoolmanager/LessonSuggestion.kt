package ma.salah.eddine.schoolmanager

import ma.salah.eddine.schoolmanager.data.*
import java.time.LocalDate

internal suspend fun suggestedLessonTime(dao:SchoolDao,year:String,date:String,section:String,teacherCode:String,subject:String=""):String? {
    if(section.isBlank() || teacherCode.isBlank()) return null
    val d=runCatching { LocalDate.parse(date) }.getOrNull() ?: return null
    val day=listOf("lundi","mardi","mercredi","jeudi","vendredi","samedi","dimanche")[d.dayOfWeek.value-1]
    fun key(s:String)=s.filterNot(Char::isWhitespace).uppercase(java.util.Locale.ROOT)
    fun subjectKey(s:String)=arabicConductSubject(s).replace(Regex("[أإآ]"),"ا").replace("اللغة","").replace("التربية","").replace("التاريخ والجغرافيا","الاجتماعيات").replace("اسلامية","اسلاميات").filter(Char::isLetter)
    val matches=dao.currentSchedule("fet.current.$year").filter { it.day.substringBefore('_')==day && it.section.substringBefore(':')==section && key(it.teacher)==key(teacherCode) }
    val subjectMatches=matches.filter { lesson -> val label=dao.setting("fet.label.المادة."+lesson.subject) ?: scheduleSubjects[lesson.subject] ?: lesson.subject; key(lesson.subject)==key(subject) || subjectKey(label)==subjectKey(subject) }
    if(subjectMatches.isEmpty()) return null
    // No guess if multiple distinct periods or different subjects remain possible.
    val distinct=subjectMatches.distinctBy { Triple(it.subject,lessonStart(it.day,it.hour),it.duration) }
    if(distinct.size!=1) return null
    return lessonPeriod(distinct.map { lessonStart(it.day,it.hour) to it.duration })
}
