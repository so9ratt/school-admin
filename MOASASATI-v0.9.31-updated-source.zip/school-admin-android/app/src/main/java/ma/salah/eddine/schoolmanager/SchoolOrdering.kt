package ma.salah.eddine.schoolmanager

internal fun schoolSections(values: Iterable<String>): List<String> = values.filter(String::isNotBlank).distinct().sortedWith(
    compareBy<String> { val code=it.uppercase(java.util.Locale.ROOT); when { code.startsWith("2BAC") -> 0; code.startsWith("1BAC") -> 1; else -> 2 } }
        .thenBy { it.substringBeforeLast("-") }.thenBy { it.substringAfterLast("-").toIntOrNull() ?: Int.MAX_VALUE }.thenBy { it })

internal fun pupilPrefix(query:String,vararg fields:String):Boolean {
    fun normalize(s:String)=s.trim().map { it.digitToIntOrNull()?.digitToChar() ?: it }.joinToString("").lowercase(java.util.Locale.ROOT).replace(Regex("[أإآ]"),"ا").replace(Regex("[\u064B-\u065Fـ]"),"")
    val tokens=normalize(query).split(Regex("\\s+")).filter(String::isNotBlank)
    val words=fields.flatMap { normalize(it).split(Regex("\\s+")) }
    return tokens.all { token -> words.any { it.startsWith(token) } }
}

internal fun lessonStart(day:String,hour:Int):Int = (if(day.endsWith("_m")) 8 else 14)+hour-1
internal fun lessonPeriod(starts:Iterable<Pair<Int,Int>>):String? {
    val unique=starts.filter { it.first in 0..23 && it.second>0 && it.first+it.second<=24 }.distinct().singleOrNull() ?: return null
    return "%02d:00".format(java.util.Locale.ROOT,unique.first)
}

internal fun classProgress(before:String,after:String):String {
    fun rank(code:String):Int? { val c=code.uppercase(java.util.Locale.ROOT);return when {
        c.startsWith("2BAC") -> 3; c.startsWith("1BAC") -> 2; c.startsWith("TC") || c.startsWith("JCS") || c.startsWith("JCA") -> 1; else -> null
    } }
    val old=rank(before);val now=rank(after)
    return when { old==null || now==null -> "تحتاج مراجعة المستوى"; now==old -> "نفس المستوى (إعادة محتملة)"; now>old -> "انتقال إلى مستوى أعلى"; else -> "انتقال إلى مستوى أدنى؛ يحتاج مراجعة" }
}
