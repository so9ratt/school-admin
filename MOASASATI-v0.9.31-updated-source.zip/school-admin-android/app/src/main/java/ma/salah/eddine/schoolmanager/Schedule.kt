package ma.salah.eddine.schoolmanager

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import java.time.LocalDate
import java.time.LocalDateTime
import kotlinx.coroutines.delay
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.*
import ma.salah.eddine.schoolmanager.importing.FetReader
import java.util.UUID

private val days = linkedMapOf("lundi" to "الاثنين","mardi" to "الثلاثاء","mercredi" to "الأربعاء",
    "jeudi" to "الخميس","vendredi" to "الجمعة","samedi" to "السبت")
internal val scheduleSubjects = mapOf("0011" to "العربية","0012" to "الفرنسية","0013" to "الإنجليزية","0014" to "الإسبانية",
    "0018" to "الاجتماعيات","0019" to "الرياضيات","0020" to "علوم الحياة والأرض","0023" to "الفيزياء والكيمياء",
    "0024" to "إسلاميات","0026" to "التربية البدنية","0030" to "المعلوميات","0036" to "الفلسفة")
private fun roomKey(code:String) = if(code=="P-E-007") "P-A-001" else code
private val rooms = buildMap<String,String> {
    val floors = listOf(1 to listOf("LAB1","LAB2","S4","S3","S2","S1"), 101 to listOf("LAB3","LAB4","S5","S6","S7","S8","S9","S10","S11","S12","HG"),
        201 to listOf("LAB5","LAB6","S20","S19","S18","S17","S16","S15","S14","S13"))
    for ((first,names) in floors) names.forEachIndexed { index,name -> put("P-E-"+(first+index).toString().padStart(3,'0'),name) }
    put("P-A-001","P-A-001")
}
private fun ScheduledLesson.start() = lessonStart(day,hour)
private fun ScheduledLesson.code(type:String) = when(type) {
    "الأستاذ" -> teacher
    "المادة" -> subject
    "القاعة" -> roomKey(room)
    else -> section.substringBefore(':')
}
private fun teacherKey(code:String) = code.filterNot(Char::isWhitespace).uppercase()

@Composable
internal fun FetImport(dao:SchoolDao,year:String,openReview:()->Unit) {
    val context=LocalContext.current
    val scope= rememberCoroutineScope()
    var batch by remember(year) { mutableStateOf(emptyList<ScheduledLesson>()) }
    var inventory by remember(year) { mutableStateOf(emptyList<String>()) }
    var previous by remember { mutableStateOf(emptyList<ScheduledLesson>()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null) scope.launch {
            busy=true
            runCatching {
                withContext(Dispatchers.IO) {
                    val revision=UUID.randomUUID().toString()
                    val stream=context.contentResolver.openInputStream(uri) ?: error("تعذر فتح الملف")
                    val roomList = mutableListOf<String>()
                    val rows = stream.use { FetReader.read(it,roomList) }.map { l -> ScheduledLesson(revision,l.id,teacherKey(l.teacher),l.subject,l.students,l.room,l.day,l.hour.drop(1).toInt(),l.duration) }
                    rows to roomList.toList()
                } to dao.currentSchedule("fet.current.$year")
            }.onSuccess { (incoming,old) -> previous=old; inventory=incoming.second; batch=incoming.first; message="" }.onFailure { message=it.message ?: "ملف غير صالح" }
            busy=false
        }
    }
    OutlinedButton(onClick={picker.launch(arrayOf("*/*"))},enabled=!busy && year.isNotBlank(),modifier=Modifier.fillMaxWidth()) {
        Text(if(busy) "جارٍ تجهيز الجدول…" else "استيراد استعمال الزمن — FET")
    }
    if(message.isNotBlank()) Text(message)
    if(batch.isNotEmpty()) {
        val changes=remember(batch,previous) {
            val old=previous.associateBy { it.activity }
            val ids=batch.map { it.activity }.toSet()
            listOf(batch.count { it.activity !in old },batch.count { row -> old[row.activity]?.let { it.copy(revision=row.revision)!=row }==true },old.keys.count { it !in ids })
        }
        AlertDialog(onDismissRequest={if(!busy)batch=emptyList()},title={Text("معاينة استعمال الزمن")},text={
            Text("الموسم: $year\nالأنشطة: ${batch.size} • الفترات: ${batch.sumOf { it.duration }}\nالأقسام: ${batch.distinctBy { it.code("القسم") }.size} • الأساتذة: ${batch.distinctBy { it.teacher }.size}\nدون قاعة: ${batch.count { it.room.isBlank() }}\nجديدة: ${changes[0]} • متغيرة: ${changes[1]} • غائبة: ${changes[2]}\nسيصبح هذا الجدول معتمداً للموسم بعد التأكيد.")
        },confirmButton={Button(enabled=!busy,onClick={
            busy=true
            scope.launch {
                runCatching { dao.saveSchedule(year,batch,org.json.JSONArray(inventory).toString()) }.onSuccess {batch=emptyList(); openReview()}.onFailure {batch=emptyList();message=it.message ?: "تعذر حفظ الجدول"}
                busy=false
            }
        }) { Text("حفظ ومراجعة التسميات") }},dismissButton={TextButton(enabled=!busy,onClick={batch=emptyList()}) {Text("إلغاء")}})
    }
}

@Composable
internal fun WeekScreen(dao:SchoolDao,year:String,initialClass:String,review:Boolean,back:()->Unit) {
    val scope=rememberCoroutineScope()
    var lessons by remember(year) { mutableStateOf(emptyList<ScheduledLesson>()) }
    var labels by remember { mutableStateOf(emptyMap<String,String>()) }
    var teacherNames by remember { mutableStateOf(emptyMap<String,String>()) }
    var editing by rememberSaveable { mutableStateOf(review) }
    var mode by rememberSaveable { mutableStateOf("القسم") }
    var selection by rememberSaveable { mutableStateOf(initialClass) }
    var view by rememberSaveable { mutableStateOf(if(initialClass.isEmpty()) "" else "القسم") }
    var inventory by remember(year) { mutableStateOf(emptyList<String>()) }
    var editKey by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var value by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(year) {
        lessons=dao.currentSchedule("fet.current.$year")
        val savedRooms=org.json.JSONArray(dao.setting("fet.rooms.$year") ?: "[]")
        inventory=(0 until savedRooms.length()).map { roomKey(savedRooms.getString(it)) }
        labels=dao.scheduleLabels().associate { it.key to it.value }
        teacherNames=dao.assignments(year).groupBy { teacherKey(it.teacherCode) }.mapNotNull { (code,rows) ->
            rows.map { it.teacherName.trim() }.filter { it.isNotEmpty() && teacherKey(it)!=code }.distinct().singleOrNull()?.let {code to it}
        }.toMap()
    }
    fun key(type:String,code:String)="fet.label.$type.$code"
    fun name(type:String,code:String):String {
        if(code.isBlank()) return "غير محددة"
        return labels[key(type,code)] ?: when(type) {
            "الأستاذ" -> teacherNames[code] ?: "أستاذ يحتاج إلى تسمية"
            "المادة" -> scheduleSubjects[code] ?: "مادة $code"
            "القاعة" -> rooms[code] ?: code
            else -> code
        }
    }
    var active by remember { mutableStateOf<ScheduledLesson?>(null) }
    active?.let { original ->
        LessonEditor(original, lessons, ::name, { active=null }) { updated ->
            scope.launch {
                runCatching { check(dao.updateLesson(updated)==1) }.onSuccess {
                    lessons=lessons.map { if(it.activity==updated.activity) updated else it };active=null
                }.onFailure {error="تعذر حفظ تعديل الحصة"}
            }
        }
    }
    fun close() {
        if(editing) {editing=false;query=""}
        else if(view.isNotEmpty() && initialClass.isEmpty()) {view="";selection="";query=""}
        else back()
    }
    BackHandler(onBack=::close)
    val roomCodes=remember(inventory,lessons) { (inventory+lessons.map { it.code("القاعة") }).filter(String::isNotBlank).distinct() }
    val options=remember(mode,lessons,labels,teacherNames,roomCodes) {
        val codes=(if(mode=="القاعة") roomCodes else lessons.map { it.code(mode) }.filter(String::isNotBlank).distinct())
        if(mode=="القسم") schoolSections(codes) else codes.sortedBy { name(mode,it) }
    }
    val titles=mapOf("القسم" to "استعمال زمن التلاميذ","الأستاذ" to "استعمال زمن الأساتذة","القاعة" to "استعمال زمن القاعات","المادة" to "استعمال الزمن حسب المادة","free" to "القاعات الشاغرة")
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        PageTitle(if(editing) "مراجعة الرموز والتسميات" else titles[view] ?: "استعمال الزمن",::close)
        if(error.isNotBlank()) Text(error)
        if(lessons.isEmpty()) { Text("استورد ملف استعمال الزمن من الإعدادات للموسم $year."); return@Column }
        if(editing) {
            RosterFilter("طريقة العرض",mode,listOf("القسم","الأستاذ","المادة","القاعة"),Modifier.fillMaxWidth()) {
                if(it.isNotBlank()) {mode=it;selection="";query=""}
            }
            SearchBox(query,{query=it},"بحث في التسميات")
            LazyColumn {
                items(options.filter { name(mode,it).contains(query,true) || it.contains(query,true) },key={it}) { code ->
                    val hint=if(mode=="الأستاذ") lessons.filter {it.teacher==code}.map {it.section.substringBefore(':')}.distinct().joinToString("، ") else code
                    TextButton(onClick={editKey=key(mode,code);value=labels[editKey] ?: if(mode=="الأستاذ") teacherNames[code].orEmpty() else name(mode,code) }) {
                        Text("${name(mode,code)} • $hint" + if(mode=="الأستاذ" && teacherNames[code]==null) " • …${code.takeLast(4)}" else "")
                    }
                }
            }
        } else if(view.isEmpty()) {
            Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                for(kind in listOf("القسم","الأستاذ","القاعة","free","المادة")) {
                    ElevatedCard(onClick={view=kind;mode=kind;selection="";query=""},modifier=Modifier.fillMaxWidth()) {
                        Text(titles.getValue(kind),Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
                    }
                }
                TextButton(onClick={mode="القسم";editing=true}) {Text("مراجعة الرموز والتسميات")}
            }
        } else if(view=="free") {
            FreeRooms(lessons,roomCodes,inventory.isEmpty(),::name)
        } else {
            var choosing by remember { mutableStateOf(false) }
            OutlinedButton(onClick={choosing=true},modifier=Modifier.fillMaxWidth()) { Text(if(selection.isEmpty()) "اختيار $mode" else name(mode,selection)) }
            if(choosing) AlertDialog(onDismissRequest={choosing=false;query=""},title={Text("اختيار $mode")},text={
                Column { SearchBox(query,{query=it},"بحث"); LazyColumn {
                    val found=options.filter {name(mode,it).contains(query,true) || it.contains(query,true) || (mode=="الأستاذ" && lessons.any { lesson -> lesson.teacher==it && name("المادة",lesson.subject).contains(query,true) })}
                    if(mode=="الأستاذ") {
                        val grouped=found.groupBy { code -> lessons.filter { it.teacher==code }.map { name("المادة",it.subject) }.distinct().sorted().joinToString("، ") }
                        grouped.toSortedMap().forEach { (subject,codes) ->
                            item { Text("$subject (${codes.size})",fontWeight=FontWeight.Bold) }
                            items(codes){code -> TextButton(onClick={selection=code;choosing=false;query=""}) {Text(name(mode,code))} }
                        }
                    } else {
                        item { Text("العدد: ${found.size}") }
                        items(found) {code -> TextButton(onClick={selection=code;choosing=false;query=""}) {Text(name(mode,code))} }
                    }
                } }
            },confirmButton={TextButton(onClick={choosing=false;query=""}) {Text("إغلاق")}})
            if(selection.isNotEmpty()) WeeklyGrid(lessons.filter { it.code(mode)==selection },mode,::name){active=it}
        }
    }
    if(editKey.isNotBlank()) AlertDialog(onDismissRequest={editKey=""},title={Text("تعديل الاسم المعروض")},text={
        Column { OutlinedTextField(value,{value=it},label={Text("الاسم")}); if(error.isNotEmpty()) Text(error) }
    },confirmButton={Button(enabled=value.isNotBlank(),onClick={
        val setting=AppSettingEntity(editKey,value.trim())
        scope.launch {
            runCatching { dao.saveSetting(setting) }.onSuccess {labels=labels+(setting.key to setting.value);editKey="";error=""}.onFailure {error="تعذر حفظ الاسم"}
        }
    }) {Text("حفظ")}},dismissButton={TextButton(onClick={editKey=""}){Text("إلغاء")}})
}

@Composable
private fun LessonEditor(original:ScheduledLesson, lessons:List<ScheduledLesson>, name:(String,String)->String,
    close:()->Unit, save:(ScheduledLesson)->Unit) {
    var day by remember(original) { mutableStateOf(original.day.substringBefore('_')) }
    var start by remember(original) { mutableStateOf(original.start()) }
    var room by remember(original) { mutableStateOf(original.room) }
    val hours=listOf(8,9,10,11,14,15,16,17).filter { it+original.duration <= if(it<12) 12 else 18 }
    val session=day+if(start<12) "_m" else "_s"
    val edited=original.copy(day=session,hour=start-(if(start<12) 8 else 14)+1,room=room)
    val conflict=lessons.any { row ->
        val sameClass=row.code("القسم")==original.code("القسم") &&
            (row.section==original.section || ':' !in row.section || ':' !in original.section)
        row.activity!=original.activity && row.day==session && row.start()<start+original.duration &&
            start<row.start()+row.duration && (sameClass || row.teacher==original.teacher || (room.isNotBlank() && row.room==room))
    }
    AlertDialog(onDismissRequest=close,title={Text(name("المادة",original.subject))},text={
        Column {
            Text(name("الأستاذ",original.teacher)+" • "+name("القسم",original.code("القسم")))
            RosterFilter("اليوم",days[day].orEmpty(),days.values.toList(),Modifier.fillMaxWidth()){label->
                days.entries.firstOrNull { it.value==label }?.let { day=it.key }
            }
            RosterFilter("بداية الحصة","$start:00",hours.map { "$it:00" },Modifier.fillMaxWidth()){it.substringBefore(':').toIntOrNull()?.let { h->start=h }}
            val rooms=lessons.map { it.room }.filter { it.isNotBlank() }.distinct()
            fun roomLabel(code:String)=if(code.isBlank()) "دون قاعة" else name("القاعة",roomKey(code))+" ("+code+")"
            RosterFilter("دون قاعة",roomLabel(room),rooms.map(::roomLabel),Modifier.fillMaxWidth()){label->room=rooms.firstOrNull { roomLabel(it)==label }.orEmpty()}
            if(conflict) Text("تعارض مع حصة للقسم أو الأستاذ أو القاعة",color=MaterialTheme.colorScheme.error)
        }
    },confirmButton={Button(enabled=!conflict && edited!=original,onClick={save(edited)}){Text("حفظ التعديل")}},
    dismissButton={TextButton(onClick=close){Text("إغلاق")}})
}

private val schoolHours=listOf(8,9,10,11,14,15,16,17)
private fun hourText(hour:Int)=hour.toString().padStart(2,'0')+":00"
private fun ScheduledLesson.at(dayKey:String,h:Int)=day.substringBefore('_')==dayKey && h in start() until start()+duration

private val shortSubjectNames = mapOf(
    "علوم الحياة والأرض" to "ع.ح.أ",
    "الفيزياء والكيمياء" to "ف.ك",
    "العلوم الفيزيائية" to "ع.ف",
    "التربية البدنية" to "ت.ب",
    "التربية البدنية والرياضية" to "ت.ب",
    "التربية الإسلامية" to "ت.إ",
    "التاريخ والجغرافيا" to "ت.ج",
    "اللغة العربية" to "العربية",
    "اللغة الفرنسية" to "الفرنسية",
    "اللغة الإنجليزية" to "الإنجليزية",
    "اللغة الإسبانية" to "الإسبانية"
)
private fun subjectKey(label:String) = label.filter(Char::isLetter)
    .replace('أ','ا').replace('إ','ا').replace('آ','ا').replace("ـ","")
private val gridSubjects = shortSubjectNames.mapKeys { subjectKey(it.key) }

@Composable
private fun WeeklyGrid(rows:List<ScheduledLesson>,mode:String,name:(String,String)->String,open:(ScheduledLesson)->Unit) {
    val horizontal=rememberScrollState()
    val vertical=rememberScrollState()
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val dayWidth=((maxWidth-48.dp)/6).coerceAtLeast(90.dp)
        Column {
            Row {
                Text("الساعة",Modifier.width(48.dp),color=Navy,fontWeight=FontWeight.Bold)
                Row(Modifier.horizontalScroll(horizontal)) {
                    days.values.forEach { Text(it,Modifier.width(dayWidth).padding(3.dp),fontWeight=FontWeight.Bold,color=Teal) }
                }
            }
            Column(Modifier.verticalScroll(vertical)) {
                for(h in schoolHours) {
                    if(h==8 || h==14) Text(if(h==8) "الفترة الصباحية" else "الفترة المسائية",Modifier.padding(vertical=2.dp),color=Teal)
                    Row {
                        Column(Modifier.width(48.dp).padding(3.dp)) {
                            Text(hourText(h),fontWeight=FontWeight.Bold); Text(hourText(h+1),style=MaterialTheme.typography.labelSmall)
                        }
                        Row(Modifier.horizontalScroll(horizontal)) {
                            for(day in days.keys) {
                                Column(Modifier.width(dayWidth).padding(2.dp)) {
                                    val slot=rows.filter { it.at(day,h) }
                                    if(slot.isEmpty()) Text("—",Modifier.padding(4.dp),color=Teal)
                                    for(l in slot) {
                                        Card(onClick={open(l)},modifier=Modifier.fillMaxWidth().padding(bottom=2.dp)) {
                                            Column(Modifier.padding(horizontal=4.dp,vertical=2.dp)) {
                                                val fullSubject=name("المادة",l.subject)
                                                Text(gridSubjects[subjectKey(fullSubject)] ?: fullSubject,style=MaterialTheme.typography.titleSmall,fontWeight=FontWeight.Bold,color=Navy)
                                                if(mode!="الأستاذ") Text(name("الأستاذ",l.teacher),style=MaterialTheme.typography.bodySmall)
                                                if(mode!="القسم") Text(name("القسم",l.code("القسم")),style=MaterialTheme.typography.bodySmall)
                                                l.section.substringAfter(':',"").takeIf { it.isNotBlank() }?.let { Text("المجموعة "+it.removePrefix("G"),style=MaterialTheme.typography.labelSmall) }
                                                if(mode!="القاعة") Text("القاعة "+name("القاعة",l.code("القاعة")),color=Teal,style=MaterialTheme.typography.labelMedium)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun FreeRooms(lessons:List<ScheduledLesson>,codes:List<String>,legacy:Boolean,name:(String,String)->String) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while(true) { now=LocalDateTime.now();delay(15000) } }
    var selectedDay by rememberSaveable { mutableStateOf("") }
    val today=now.toLocalDate()
    val dayKeys=days.keys.toList()
    val slots=buildList<Pair<LocalDate,Int>> {
        for(offset in 0L..7L) {
            val date=today.plusDays(offset)
            val key=dayKeys.getOrNull(date.dayOfWeek.value-1) ?: continue
            if(selectedDay.isNotEmpty() && days[key]!=selectedDay) continue
            for(hour in schoolHours) {
                if(selectedDay.isEmpty() && date==today && hour<now.hour) continue
                add(date to hour)
            }
            if(selectedDay.isNotEmpty()) break
        }
    }
    RosterFilter("الآن والحصص المقبلة",selectedDay,days.values.toList(),Modifier.fillMaxWidth()){selectedDay=it}
    if(legacy) Text("تُعرض القاعات الواردة في الحصص. لاستكمال لائحة القاعات، أعد استيراد ملف FET.",style=MaterialTheme.typography.bodySmall)
    LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)) {
        items(if(selectedDay.isEmpty()) slots.take(4) else slots) { (date,h) ->
            val key=dayKeys[date.dayOfWeek.value-1]
            val scheduled=lessons.filter { it.at(key,h) }
            val used=scheduled.map { it.code("القاعة") }.toSet()
            val free=codes.filterNot { it in used }.map { name("القاعة",it) }.sorted()
            OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text((if(date==today && h==now.hour) "الآن  •  " else "")+days[key]+"  •  "+hourText(h)+" – "+hourText(h+1),fontWeight=FontWeight.Bold,color=Navy)
                Text("القاعات الشاغرة حسب الجدول: "+free.size,color=Teal)
                if(free.isNotEmpty()) Text(free.joinToString("   ·   "))
                if(scheduled.any { it.room.isBlank() }) Text("توجد حصص لم تُحدّد قاعتها",style=MaterialTheme.typography.labelSmall)
            } }
        }
    }
}
