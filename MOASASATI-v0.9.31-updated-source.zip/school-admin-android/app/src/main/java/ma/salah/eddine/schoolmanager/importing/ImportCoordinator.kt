package ma.salah.eddine.schoolmanager.importing

import ma.salah.eddine.schoolmanager.data.AcademicSeason
import ma.salah.eddine.schoolmanager.data.AppSettingEntity
import ma.salah.eddine.schoolmanager.data.EmployeeEntity
import ma.salah.eddine.schoolmanager.data.EnrollmentEntity
import ma.salah.eddine.schoolmanager.data.ImportHistoryEntity
import ma.salah.eddine.schoolmanager.data.SchoolClassEntity
import ma.salah.eddine.schoolmanager.data.SchoolDao
import ma.salah.eddine.schoolmanager.data.SubjectEntity
import ma.salah.eddine.schoolmanager.data.StudentEntity
import ma.salah.eddine.schoolmanager.data.TeacherAssignmentEntity

data class StudentImportDiff(
    val newStudents: Int,
    val updatedProfiles: Int,
    val sectionTransfers: Int,
    val unchangedStudents: Int,
    val notInNewFile: Int,
    val transferDetails: List<StudentTransfer>,
    val changes: List<ma.salah.eddine.schoolmanager.data.Movement> = emptyList()
)

data class StudentTransfer(val massarCode: String, val oldClass: String, val newClass: String)

data class EmployeeImportDiff(val newEmployees: Int, val updatedEmployees: Int, val unchangedEmployees: Int, val notInNewFile: Int)

data class TeachingImportDiff(val newAssignments: Int, val changedAssignments: Int, val unchangedAssignments: Int, val noLongerListed: Int)

object ImportCoordinator {
    private suspend fun historical(dao: SchoolDao, year: String): Boolean {
        val target = AcademicSeason.parse(year) ?: return false
        val latest = dao.availableYears().mapNotNull { AcademicSeason.parse(it) }.maxOrNull()
        return latest != null && target < latest
    }

    suspend fun compareStudents(dao: SchoolDao, plan: StudentWorkbookPlan): StudentImportDiff {
        val oldStudents = dao.allStudents().associateBy { it.massarCode }
        val oldEnrollments = dao.enrollments(plan.schoolYear).associateBy { it.massarCode }
        val preserveProfiles = historical(dao, plan.schoolYear)
        var new = 0
        var updated = 0
        var transferred = 0
        var unchanged = 0
        val transferDetails = mutableListOf<StudentTransfer>()
        plan.students.forEach { row ->
            val old = oldStudents[row.massarCode]
            val oldEnrollment = oldEnrollments[row.massarCode]
            if (old == null) new++
            else if ((!preserveProfiles && (old.surname != row.surname || old.givenName != row.givenName || old.gender != row.gender ||
                old.birthDate != row.birthDate || old.birthPlace != row.birthPlace)) || oldEnrollment?.ordinal != row.ordinal) updated++
            else unchanged++
            if (oldEnrollment != null && oldEnrollment.className != row.className) {
                transferred++
                transferDetails += StudentTransfer(row.massarCode, oldEnrollment.className, row.className)
            }
        }
        val represented=plan.sections.map {it.className}.toSet()
        val incoming = plan.students.associateBy { it.massarCode }
        val previous = dao.studentsForYear(plan.schoolYear)
        val missing=previous.filter {it.className in represented && it.massarCode !in incoming}
        val notInFile=missing.size
        val date = java.time.LocalDateTime.now().toString()
        val changes = buildList {
            if (previous.isNotEmpty()) {
                plan.students.filter { it.massarCode !in oldEnrollments }.forEach { r -> add(ma.salah.eddine.schoolmanager.data.Movement(plan.schoolYear,"ARRIVAL",r.massarCode,date,r.surname+" "+r.givenName,r.levelName,r.className,"","","",r.ordinal)) }
                missing.forEach { r -> add(ma.salah.eddine.schoolmanager.data.Movement(plan.schoolYear,"DEPARTURE",r.massarCode,date,r.surname+" "+r.givenName,r.levelName,r.className,"","","",r.ordinal)) }
                transferDetails.forEach { t -> val r=incoming.getValue(t.massarCode); add(ma.salah.eddine.schoolmanager.data.Movement(plan.schoolYear,"CLASS_CHANGE",r.massarCode,date,r.surname+" "+r.givenName,r.levelName,r.className,t.oldClass,t.newClass,"",r.ordinal)) }
            }
        }
        return StudentImportDiff(new, updated, transferred, unchanged, notInFile, transferDetails, changes)
    }

    suspend fun importStudents(dao: SchoolDao, plan: StudentWorkbookPlan, fileName: String, diff: StudentImportDiff) {
        require(AcademicSeason.parse(plan.schoolYear)!=null) { "الموسم الدراسي غير صالح" }
        val oldEnrollments = dao.enrollments(plan.schoolYear).associateBy { it.massarCode }
        // Personal profiles are global by Massar. An older roster must not overwrite
        // identity fields already held in a more recent season.
        val existing = dao.allStudents().associateBy { it.massarCode }
        val historical = historical(dao, plan.schoolYear)
        val students = plan.students.map {
            if (historical && existing.containsKey(it.massarCode)) existing.getValue(it.massarCode)
            else StudentEntity(it.massarCode, it.surname, it.givenName, it.gender, it.birthDate, it.birthPlace)
        }
        val enrollments = plan.students.map { row ->
            EnrollmentEntity(
                id = oldEnrollments[row.massarCode]?.id ?: 0,
                massarCode = row.massarCode,
                schoolYear = plan.schoolYear,
                className = row.className,
                ordinal = row.ordinal
            )
        }
        val classes = plan.sections.map { SchoolClassEntity(plan.schoolYear, it.className, it.levelName) }
        val settings = buildList {
            if (dao.setting("academy") == null) plan.academy?.let { add(AppSettingEntity("academy", it)) }
            if (dao.setting("province") == null) plan.province?.let { add(AppSettingEntity("province", it)) }
            if (dao.setting("schoolName") == null) plan.institution?.let { add(AppSettingEntity("schoolName", it)) }
            if (dao.setting("schoolYear").isNullOrBlank()) {
                add(AppSettingEntity("schoolYear", plan.schoolYear))
            }
        }
        dao.commitStudentImport(students, classes, enrollments, settings, ImportHistoryEntity(
            sourceType = "students",
            fileName = fileName,
            importedAt = System.currentTimeMillis(),
            recordsRead = plan.students.size,
            recordsCreated = diff.newStudents,
            recordsUpdated = diff.updatedProfiles + diff.sectionTransfers,
            warnings = plan.warnings.size
        ), diff.changes)
    }

    suspend fun compareEmployees(dao: SchoolDao, plan: EmployeeImportPlan): EmployeeImportDiff {
        val old = dao.allEmployees().associateBy { it.ppr }
        var new = 0
        var updated = 0
        var unchanged = 0
        plan.employees.forEach { item ->
            val previous = old[item.ppr]
            when {
                previous == null -> new++
                previous == item -> unchanged++
                else -> updated++
            }
        }
        val incoming = plan.employees.map { it.ppr }.toSet()
        return EmployeeImportDiff(new, updated, unchanged, old.keys.count { it !in incoming })
    }

    suspend fun importEmployees(dao: SchoolDao, plan: EmployeeImportPlan, fileName: String, diff: EmployeeImportDiff) {
        dao.commitEmployeeImport(plan.employees, plan.services, plan.referenceValues, ImportHistoryEntity(
            sourceType = "employees",
            fileName = fileName,
            importedAt = System.currentTimeMillis(),
            recordsRead = plan.employees.size,
            recordsCreated = diff.newEmployees,
            recordsUpdated = diff.updatedEmployees,
            warnings = plan.warnings.size
        ))
    }

    suspend fun compareTeaching(dao: SchoolDao, plan: TeacherLoadPlan): TeachingImportDiff {
        val old = dao.assignments(plan.schoolYear).associateBy(::assignmentKey)
        val incoming = plan.assignments.associateBy { row ->
            listOf(plan.schoolYear, row.teacherCode, row.subjectName, row.className, row.subgroupName).joinToString("|")
        }
        var new = 0
        var changed = 0
        var unchanged = 0
        incoming.forEach { (key, row) ->
            val previous = old[key]
            when {
                previous == null -> new++
                previous.lessonCount != row.lessonCount || previous.teacherName != row.teacherName -> changed++
                else -> unchanged++
            }
        }
        return TeachingImportDiff(new, changed, unchanged, old.keys.count { it !in incoming })
    }

    suspend fun importTeaching(dao: SchoolDao, plan: TeacherLoadPlan, fileName: String, diff: TeachingImportDiff) {
        require(AcademicSeason.parse(plan.schoolYear)!=null) { "الموسم الدراسي غير صالح" }
        val items = plan.assignments.map {
            TeacherAssignmentEntity(
                schoolYear = plan.schoolYear,
                teacherCode = it.teacherCode,
                teacherName = it.teacherName,
                subjectName = it.subjectName,
                className = it.className,
                subgroupName = it.subgroupName,
                lessonCount = it.lessonCount,
                isCurrent = true
            )
        }
        val classes = plan.assignments.map { SchoolClassEntity(plan.schoolYear, it.className, "") }.distinctBy { it.className }
        val subjects = plan.assignments.map { SubjectEntity(it.subjectName) }.distinctBy { it.name }
        dao.commitTeachingImport(plan.schoolYear, classes, subjects, items, ImportHistoryEntity(
            sourceType = "teaching",
            fileName = fileName,
            importedAt = System.currentTimeMillis(),
            recordsRead = plan.assignments.size,
            recordsCreated = diff.newAssignments,
            recordsUpdated = diff.changedAssignments,
            warnings = plan.warnings.size
        ))
    }

    private fun assignmentKey(item: TeacherAssignmentEntity): String = listOf(
        item.schoolYear, item.teacherCode, item.subjectName, item.className, item.subgroupName
    ).joinToString("|")
}
