package ma.salah.eddine.schoolmanager.data

/** Validated academic season; storage format is YYYY/YYYY. */
data class AcademicSeason private constructor(val startYear: Int) : Comparable<AcademicSeason> {
    val endYear: Int get() = startYear + 1
    val storageValue: String get() = "$startYear/$endYear"
    override fun compareTo(other: AcademicSeason): Int = startYear.compareTo(other.startYear)

    companion object {
        private val pattern = Regex("^([0-9]{4})\\s*[/\\-–]\\s*([0-9]{4})$")
        fun parse(value: String?): AcademicSeason? {
            val match = pattern.matchEntire(value?.trim() ?: return null) ?: return null
            val start = match.groupValues[1].toIntOrNull() ?: return null
            val end = match.groupValues[2].toIntOrNull() ?: return null
            return if (start in 1900..9998 && end == start + 1) AcademicSeason(start) else null
        }
    }
}
