package ma.salah.eddine.schoolmanager

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle
import java.util.Locale

internal enum class SlipPeriod(val title:String) { TODAY("اليوم"), RANGE("من تاريخ إلى تاريخ"), ALL("الجميع") }

private val slipFormats=listOf("uuuu-M-d","d/M/uuuu","uuuu/M/d","d-M-uuuu").map {
    DateTimeFormatter.ofPattern(it,Locale.ROOT).withResolverStyle(ResolverStyle.STRICT)
}
internal fun slipDay(raw:String):LocalDate? {
    val value=raw.trim().substringBefore('T').substringBefore(' ').map { it.digitToIntOrNull()?.digitToChar() ?: it }.joinToString("")
    for(format in slipFormats) runCatching {LocalDate.parse(value,format)}.getOrNull()?.let {return it}
    return null
}
internal fun SlipPeriod.includes(raw:String,today:LocalDate,start:LocalDate,end:LocalDate):Boolean {
    if(this==SlipPeriod.ALL)return true
    val day=slipDay(raw) ?: return false
    return if(this==SlipPeriod.TODAY) day==today else day>=start && day<=end
}
