package ma.salah.eddine.schoolmanager.importing

import java.io.InputStream
import ma.salah.eddine.schoolmanager.data.*

data class FamilyFile(val file: String, val year: String, val section: String, val rows: List<Pair<String,List<FamilyContact>>>)
data class FamilyReview(val notes: List<String>, val contacts: List<FamilyContact>, val ids: List<AppSettingEntity> = emptyList())

object FamilyBatch {
    private fun norm(s: String) = s.replace('أ','ا').replace('إ','ا').replace(" ","").trim()
    fun parse(file: String, input: InputStream): FamilyFile {
        val sheet = XlsxDocument.read(input).sheets.singleOrNull { norm(it.cell(8,3).orEmpty()) == "رقمالتلميذ" }
            ?: error("لم يتم التعرف على جدول أولياء الأمور")
        fun cell(r:Int,c:Int) = sheet.cell(r,c).orEmpty().trim()
        for ((col, label) in listOf(7 to "ولي",15 to "الاب",23 to "الام")) {
            require(norm(cell(8,col)).contains(label) && norm(cell(9,col+6))=="الهاتف") { "عناوين بيانات الأسرة غير مطابقة" }
        }
        val year=cell(5,7)
        val section=cell(6,7)
        require(year.isNotEmpty() && section.isNotEmpty()) { "الموسم أو القسم مفقود" }
        val rows=sheet.populatedCells().keys.map { it.row }.distinct().sorted().filter { it>=10 && (3..5).any { c -> cell(it,c).isNotEmpty() } }.map { r ->
            val code=cell(r,3)
            code to listOf(7 to "ولي الأمر",15 to "الأب",23 to "الأم").map { (c,role) ->
                val name=listOf(cell(r,c+1),cell(r,c+2)).filter { it.isNotBlank() }.joinToString(" ").ifBlank {
                    listOf(cell(r,c+3),cell(r,c+4)).filter { it.isNotBlank() }.joinToString(" ")
                }
                FamilyContact(year,code,role,name,cell(r,c+6),if(c==7) cell(r,6) else cell(r,c),
                    if(c!=7 && norm(cell(9,c+7))=="العنوان") cell(r,c+7).ifBlank { null } else null)
            }
        }
        return FamilyFile(file,year,section,rows)
    }

    suspend fun review(dao: SchoolDao, files: List<FamilyFile>, year: String, errors: List<String>): FamilyReview {
        val roster=dao.enrollments(year).associateBy { it.massarCode }
        val old=dao.familyForYear(year).associateBy { it.massar to it.role }
        val notes=errors.toMutableList()
        val updates=mutableListOf<FamilyContact>()
        val ids=mutableListOf<AppSettingEntity>()
        fun sameYear(f:FamilyFile)=f.year.replace("-","/")==year.replace("-","/")
        val counts=files.filter(::sameYear).flatMap { it.rows }.groupingBy { it.first }.eachCount()
        for (f in files) {
            if (!sameYear(f)) { notes += "${f.file}: موسم مختلف (${f.year})"; continue }
            val details=mutableListOf<String>()
            var matched=0
            for ((code, contacts) in f.rows) {
                val reason=when {
                    code.isBlank() -> "رمز مسار مفقود"
                    counts[code]!=1 -> "رمز متكرر ضمن الدفعة"
                    code !in roster -> "غير مسجل في الموسم"
                    roster[code]?.className != f.section -> "القسم لا يطابق التسجيل"
                    else -> null
                }
                if(reason!=null) { details += "$code — $reason"; continue }
                matched++
                for (incoming in contacts) {
                    if(incoming.role in listOf("الأب","الأم") && incoming.kind.isNotBlank()) ids += AppSettingEntity("family.id.$year.$code.${incoming.role}",incoming.kind)
                    val prev=old[code to incoming.role]
                    val identityChanged=prev!=null && ((incoming.name.isNotBlank() && prev.name.isNotBlank() && incoming.name!=prev.name) ||
                        (incoming.kind.isNotBlank() && prev.kind.isNotBlank() && incoming.kind!=prev.kind))
                    if(identityChanged && incoming.phone.isBlank() && !prev?.phone.isNullOrBlank()) {
                        details += "$code • ${incoming.role}: تغيّر الاسم أو الصفة دون هاتف، احتُفظ بالسجل السابق للمراجعة"
                        continue
                    }
                    val next=incoming.copy(year=year,name=incoming.name.ifBlank { if(identityChanged) "" else prev?.name.orEmpty() },
                        address=incoming.address ?: prev?.address?.takeUnless { identityChanged },
                        phone=incoming.phone.ifBlank { prev?.phone.orEmpty() },kind=incoming.kind.ifBlank { if(identityChanged) "" else prev?.kind.orEmpty() })
                    if(next.phone.isNotBlank() && !Regex("0[0-9]{9}").matches(next.phone)) details += "$code • ${next.role}: راجع صيغة الهاتف ${next.phone}"
                    if(next!=prev && listOf(next.name,next.phone,next.kind,next.address.orEmpty()).any { it.isNotBlank() }) {
                        updates += next
                        if(prev!=null && prev.phone!=next.phone) details += "$code • ${next.role}: ${prev.phone.ifBlank { "غير متوفر" }} ← ${next.phone}"
                    }
                }
            }
            val present=f.rows.map { it.first }.toSet()
            val absent=roster.values.count { it.className==f.section && it.massarCode !in present }
            notes += "${f.section} • ${f.file}\nمطابق: $matched من ${f.rows.size} • للمراجعة: ${f.rows.size-matched} • غير وارد: $absent"
            notes += details
        }
        return FamilyReview(notes, updates, ids)
    }
}
