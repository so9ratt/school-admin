package ma.salah.eddine.schoolmanager

/** Comparison by Massar only. Missing pupils are never automatically dismissed. */
object SeasonComparison {
    data class Result(val continuing: Set<String>, val missing: Set<String>, val newToList: Set<String>, val confirmedDismissed: Set<String>, val unresolved: Set<String>)
    private fun codes(values: Iterable<String>) = values.map { it.trim().uppercase(java.util.Locale.ROOT) }.filter { it.isNotEmpty() }.toSet()
    fun compare(previous: Iterable<String>, current: Iterable<String>, confirmedDismissals: Iterable<String> = emptyList(), knownOtherStatuses: Iterable<String> = emptyList()): Result {
        val old = codes(previous)
        val now = codes(current)
        val missing = old - now
        val dismissed = missing intersect codes(confirmedDismissals)
        return Result(old intersect now, missing, now - old, dismissed, missing - dismissed - codes(knownOtherStatuses))
    }
}
