"""Copy a stopped debug app's school database to a fresh side-by-side installation."""
import os
import shlex
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

SOURCE = "ma.salah.eddine.schoolmanager"
TARGET = SOURCE + ".transfer"
DB = "salah_eddine_school.db"
ADB = shutil.which("adb") or str(Path.cwd() / ("adb.exe" if os.name == "nt" else "adb"))


def device(*args, **kwargs):
    return subprocess.run([ADB, *args], check=True, **kwargs)


def app(package, command, **kwargs):
    return device("shell", "-T", "run-as", package, "sh", "-c", shlex.quote(command), **kwargs)


def transfer():
    device("get-state")
    for package in (SOURCE, TARGET):
        app(package, "id", stdout=subprocess.DEVNULL)
        device("shell", "am", "force-stop", package)
    target = "databases/" + DB
    fresh = " && ".join(f"test ! -e {target}{suffix}" for suffix in ("", "-wal", "-shm", "-journal"))
    app(TARGET, fresh)
    with tempfile.TemporaryDirectory() as directory:
        local = Path(directory)
        for suffix in ("", "-wal", "-journal"):
            path = target + suffix
            exists = app(SOURCE, f"if test -f {path}; then echo yes; fi", capture_output=True)
            if exists.stdout.strip() == b"yes":
                with (local / (DB + suffix)).open("wb") as copy:
                    device("exec-out", "run-as", SOURCE, "cat", path, stdout=copy)
        if not (local / DB).is_file():
            raise ValueError("Source database was not found.")
        merged = local / "snapshot.db"
        with sqlite3.connect(local / DB) as old, sqlite3.connect(merged) as new:
            old.backup(new)
            if new.execute("PRAGMA integrity_check").fetchone() != ("ok",):
                raise ValueError("The snapshot failed verification.")
            if not 1 <= new.execute("PRAGMA user_version").fetchone()[0] <= 6:
                raise ValueError("Unsupported database version.")
            new.execute("SELECT COUNT(*) FROM students").fetchone()
            new.execute("PRAGMA journal_mode=DELETE")
        old.close()
        new.close()
        # Publish only after all bytes have arrived. A hard link refuses to overwrite.
        stage = "databases/transfer.tmp"
        with merged.open("rb") as data:
            app(TARGET, f"mkdir -p databases && cat > {stage} && test $(wc -c < {stage}) -eq {merged.stat().st_size} && {fresh} && ln {stage} {target} && rm {stage}", stdin=data)
    print("Copy verified and transferred. Open the new application. The original remains installed.")


if __name__ == "__main__":
    try:
        transfer()
    except (OSError, ValueError, sqlite3.Error, subprocess.CalledProcessError) as error:
        sys.exit(f"Transfer stopped. Keep the original application installed. {error}")
