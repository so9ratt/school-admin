package ma.salah.eddine.schoolmanager
fun main(){
    check(schoolSections(listOf("TC-1","2BAC-PC-10","1BAC-1","2BAC-PC-2","2BAC-PC-2"))==listOf("2BAC-PC-2","2BAC-PC-10","1BAC-1","TC-1"))
    check(pupilPrefix("احم", "أَحمد علي"));check(!pupilPrefix("حمد","أحمد"));check(pupilPrefix("١٢","12"))
    check(pupilPrefix("عل اح", "أحمد علي"));check(!pupilPrefix("زيد", "أحمد علي"))
    check(lessonStart("lundi_m",1)==8);check(lessonStart("lundi_a",2)==15)
    check(lessonPeriod(listOf(8 to 2,8 to 2))=="08:00");check(lessonPeriod(listOf(8 to 1,10 to 1))==null);check(lessonPeriod(emptyList())==null)
    check(classProgress("TC-1","1BAC-2").contains("أعلى"));check(classProgress("1BAC-2","1BAC-3").contains("إعادة"));check(classProgress("UNKNOWN","2BAC-1").contains("مراجعة"))
    println("PASS: natural ordering, prefix search, schedule time ambiguity, level transitions")
}
