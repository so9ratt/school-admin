import ma.salah.eddine.schoolmanager.data.AcademicSeason
import ma.salah.eddine.schoolmanager.SeasonComparison
fun main() {
    check(AcademicSeason.parse("2026/2027")?.storageValue == "2026/2027")
    check(AcademicSeason.parse(" 2026 - 2027 ") == AcademicSeason.parse("2026/2027"))
    check(AcademicSeason.parse("2026–2027") == AcademicSeason.parse("2026/2027"))
    listOf("2026/2028", "2026", "", "2027/2026", "abcd/efgh").forEach { check(AcademicSeason.parse(it)==null) }
    check(AcademicSeason.parse("2025/2026")!! < AcademicSeason.parse("2026/2027")!!)
    val result = SeasonComparison.compare(listOf("A1","A2","A3"),listOf("a1","B1"),listOf("A2"))
    check(result.continuing==setOf("A1") && result.confirmedDismissed==setOf("A2") && result.unresolved==setOf("A3") && result.newToList==setOf("B1"))
    println("PASS: academic season validation and comparison")
}
