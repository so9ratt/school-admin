package ma.salah.eddine.schoolmanager

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.*
import org.json.JSONObject
import java.io.OutputStream
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val noticeFormat=DateTimeFormatter.ofPattern("dd/MM/uuuu",Locale.ROOT)
internal fun displayDay(day:String)=LocalDate.parse(day).format(noticeFormat)

internal data class NoticePage(val file:NoticeCase,val stage:Int,val day:String,val number:String,val guardian:String,val address:String,val envelope:Boolean=false) {
    fun values()=mapOf("issue" to displayDay(day),"number" to number.ifBlank { "....." },"student" to file.name,
        "section" to file.section,"guardian" to guardian,"address" to address,"first" to displayDay(file.first),
        "deadline" to file.due(4).format(noticeFormat),"prev1" to file.sent.getOrNull(0)?.let { displayDay(it.day) }.orEmpty(),
        "prev2" to file.sent.getOrNull(1)?.let { displayDay(it.day) }.orEmpty())
}

internal fun writeNotices(context:Context,pages:List<NoticePage>,out:OutputStream) {
    require(pages.isNotEmpty())
    val assets=context.assets
    val positions=assets.open("absence_letters/positions.json").bufferedReader().use { JSONObject(it.readText()) }
    val pdf=PdfDocument()
    var bitmap:Bitmap?=null
    var loaded=0
    try {
        pages.forEachIndexed { i,letter ->
            val index=if(letter.envelope) 5 else letter.stage
            if(index!=loaded) {
                bitmap?.recycle()
                bitmap=assets.open("absence_letters/$index.png").use { BitmapFactory.decodeStream(it) }
                loaded=index
            }
            val page=pdf.startPage(PdfDocument.PageInfo.Builder(595,420,i+1).create())
            val canvas=page.canvas
            canvas.drawBitmap(requireNotNull(bitmap),null,RectF(0f,0f,595f,420f),Paint(Paint.FILTER_BITMAP_FLAG))
            val fields=positions.getJSONObject(index.toString())
            val values=letter.values()
            for(key in fields.keys()) {
                val a=fields.getJSONArray(key)
                val value=values[key].orEmpty()
                val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color=Color.BLACK
                    typeface=Typeface.create("serif",if(key in listOf("student","section","guardian","address")) Typeface.BOLD else Typeface.NORMAL)
                    textSize=a.getDouble(3).toFloat();textAlign=Paint.Align.RIGHT
                }
                val width=paint.measureText(value)
                if(width>a.getDouble(2)) paint.textSize*=a.getDouble(2).toFloat()/width
                canvas.drawText(value,a.getDouble(0).toFloat(),a.getDouble(1).toFloat(),paint)
            }
            pdf.finishPage(page)
        }
        pdf.writeTo(out)
    } finally {pdf.close();bitmap?.recycle()}
}

internal fun printNotices(context:Context,pages:List<NoticePage>) {
    val app=context.applicationContext
    val manager=context.getSystemService(Context.PRINT_SERVICE) as PrintManager
    manager.print("مراسلات الغياب",object:PrintDocumentAdapter(){
        override fun onLayout(old:PrintAttributes?,new:PrintAttributes?,signal:CancellationSignal,cb:LayoutResultCallback,extras:Bundle?) {
            if(signal.isCanceled) cb.onLayoutCancelled() else cb.onLayoutFinished(PrintDocumentInfo.Builder("مراسلات الغياب.pdf").setPageCount(pages.size).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(),old!=new)
        }
        override fun onWrite(ranges:Array<PageRange>,dest:ParcelFileDescriptor,signal:CancellationSignal,cb:WriteResultCallback) {
            val indices=pages.indices.filter { i->ranges.any { i in it.start..it.end } }
            Thread {
                try {
                    if(signal.isCanceled) cb.onWriteCancelled() else {
                        ParcelFileDescriptor.AutoCloseOutputStream(dest).use { writeNotices(app,indices.map(pages::get),it) }
                        if(signal.isCanceled) cb.onWriteCancelled() else cb.onWriteFinished(indices.map { PageRange(it,it) }.toTypedArray())
                    }
                } catch(e:Exception){cb.onWriteFailed(e.localizedMessage)}
            }.start()
        }
    },PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A5.asLandscape()).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
}

internal fun writeNoticeWord(context:Context,letter:NoticePage,out:OutputStream) {
    val index=if(letter.envelope)5 else letter.stage
    val values=letter.values()
    val field=Regex("@@([a-zA-Z0-9]+)@@")
    context.assets.open("absence_letters/$index.docx").use { input ->
        java.util.zip.ZipInputStream(input).use { source ->
            java.util.zip.ZipOutputStream(out).use { target ->
                while(true){
                    val entry=source.nextEntry ?: break
                    target.putNextEntry(java.util.zip.ZipEntry(entry.name))
                    if(entry.name=="word/document.xml"){
                        val xml=source.readBytes().toString(Charsets.UTF_8)
                        target.write(field.replace(xml){ match ->
                            android.text.TextUtils.htmlEncode(values.getValue(match.groupValues[1]))
                        }.toByteArray(Charsets.UTF_8))
                    }else source.copyTo(target)
                    target.closeEntry()
                }
            }
        }
    }
}
