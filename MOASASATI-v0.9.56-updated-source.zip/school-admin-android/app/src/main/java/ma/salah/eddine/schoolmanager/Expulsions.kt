package ma.salah.eddine.schoolmanager

import android.app.TimePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ma.salah.eddine.schoolmanager.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.UUID

private const val expulsionKind="الطرد من الحصة"
private val expulsionReasons=listOf("عدم إحضار الدفتر","عدم إحضار الأدوات المدرسية","سلوك غير مناسب","سبب آخر")
private val expulsionClock=DateTimeFormatter.ofPattern("HH:mm",java.util.Locale.ROOT)

@Composable
internal fun ExpulsionScreen(dao:SchoolDao,year:String,school:String,academy:String,province:String,back:()->Unit) {
    val scope=rememberCoroutineScope()
    val context=LocalContext.current
    val records by remember(dao,year){dao.conduct(year)}.collectAsState(emptyList())
    val rows=records.filter { it.kind==expulsionKind }
    val roster by produceState(emptyList<StudentListRow>(),dao,year){value=dao.studentsForYear(year)}
    var adding by rememberSaveable {mutableStateOf(false)}
    var section by rememberSaveable {mutableStateOf("")}
    var date by rememberSaveable {mutableStateOf(LocalDate.now().toString())}
    var time by rememberSaveable {mutableStateOf(LocalTime.now().format(expulsionClock))}
    var teacherKey by rememberSaveable {mutableStateOf("")}
    var query by rememberSaveable {mutableStateOf("")}
    var teacherFilter by rememberSaveable {mutableStateOf("")}
    var dateFilter by rememberSaveable {mutableStateOf(false)}
    var from by rememberSaveable {mutableStateOf(LocalDate.now().toString())}
    var to by rememberSaveable {mutableStateOf(LocalDate.now().toString())}
    val selected=remember {mutableStateMapOf<String,String>()}
    val notes=remember {mutableStateMapOf<String,String>()}
    var commonReason by rememberSaveable {mutableStateOf("")}
    var commonNote by rememberSaveable {mutableStateOf("")}
    fun effectiveReason(code:String)=selected[code].orEmpty().ifBlank {commonReason}
    fun effectiveNote(code:String)=notes[code] ?: if(selected[code].isNullOrBlank()) commonNote else ""
    var busy by remember {mutableStateOf(false)}
    var message by remember {mutableStateOf("")}
    val staff by produceState(emptyList<TeacherAssignmentEntity>(),dao,year,section){value=if(section.isBlank()) emptyList() else dao.assignmentsForClass(year,section).map { row -> row.copy(teacherName=dao.setting("fet.label.الأستاذ."+row.teacherCode.filterNot(Char::isWhitespace).uppercase()) ?: row.teacherName) }.distinctBy { it.teacherCode to it.subjectName }.sortedWith(compareBy({arabicConductSubject(it.subjectName)},{it.teacherName}))}
    val teacher=staff.firstOrNull {it.teacherCode+"|"+it.subjectName==teacherKey}
    val suggestion by produceState<String?>(null,year,section,date,teacherKey){value=null;if(teacher!=null)value=suggestedLessonTime(dao,year,date,section,teacher.teacherCode,teacher.subjectName)}
    var manualTime by rememberSaveable(year,section,date,teacherKey){mutableStateOf(false)}
    LaunchedEffect(suggestion,year,section,date,teacherKey){if(!manualTime && suggestion!=null)time=suggestion!!}
    fun close(){if(adding){adding=false;selected.clear();notes.clear();commonReason="";commonNote="";section="";query="";teacherKey=""}else back()}
    BackHandler { if(!busy)close() }
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        PageTitle("إخراج التلاميذ من الحصة"){if(!busy)close()}
        Text("الموسم الدراسي $year")
        if(message.isNotBlank()) Text(message)
        if(adding) {
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                item {
                    var menu by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value=query,onValueChange={query=it},singleLine=true,
                        modifier=Modifier.fillMaxWidth(),shape=androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                        label={Text("بحث عن تلميذ بالاسم أو مسار")},
                        colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=androidx.compose.ui.graphics.Color(0xFF1976D2),unfocusedBorderColor=androidx.compose.ui.graphics.Color(0xFF90CAF9),cursorColor=androidx.compose.ui.graphics.Color(0xFF1976D2)),
                        trailingIcon={Box { TextButton(onClick={menu=true}){Text(if(section.isBlank()) "الأقسام ▾" else "$section ▾",color=androidx.compose.ui.graphics.Color(0xFF1976D2))};DropdownMenu(expanded=menu,onDismissRequest={menu=false}) {
                            DropdownMenuItem(text={Text("جميع الأقسام")},onClick={section="";selected.clear();notes.clear();teacherKey="";menu=false})
                            schoolSections(roster.map {it.className}).forEach { c -> DropdownMenuItem(text={Text(c)},onClick={if(section!=c){section=c;selected.clear();notes.clear();teacherKey=""};menu=false}) }
                        }}}
                    )
                    if(section.isNotBlank()) {
                        var teacherMenu by remember {mutableStateOf(false)}
                        Box { TextButton(onClick={teacherMenu=true}){Text(teacher?.let {it.teacherName+" • "+arabicConductSubject(it.subjectName)} ?: "اختيار الأستاذ والمادة ▾")};DropdownMenu(expanded=teacherMenu,onDismissRequest={teacherMenu=false}) {staff.forEach {t->DropdownMenuItem(text={Text(t.teacherName+" • "+arabicConductSubject(t.subjectName))},onClick={teacherKey=t.teacherCode+"|"+t.subjectName;teacherMenu=false})}} }
                    }
                }
                item { DayPicker(date){date=it} }
                item { Text(if(teacher==null) "اختر القسم والأستاذ لعرض الحصة" else suggestion?.let{"الحصة: $it • ${arabicConductSubject(teacher.subjectName)}"} ?: "لا توجد حصة مطابقة في استعمال الزمن للتاريخ المحدد") }
                items(roster.filter {section.isNotBlank() && it.className==section && (it.massarCode in selected || pupilPrefix(query,it.givenName,it.surname,it.massarCode,it.ordinal?.toString().orEmpty()))},key={it.massarCode}){s ->
                    OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp)) {
                        Row { Checkbox(s.massarCode in selected,{checked->if(checked){if(section.isBlank()){section=s.className;teacherKey=""};selected[s.massarCode]=""} else {selected.remove(s.massarCode);notes.remove(s.massarCode)}});Text("${s.ordinal ?: "—"}. ${s.givenName} ${s.surname} • ${s.className}",Modifier.padding(top=12.dp)) }

                    } }
                }
                if(selected.isNotEmpty()) {
                    item {
                        Text("سبب الإخراج المشترك",style=MaterialTheme.typography.titleMedium)
                        RosterFilter("اختيار السبب",commonReason,expulsionReasons,Modifier.fillMaxWidth()){commonReason=it}
                        OutlinedTextField(commonNote,{commonNote=it},label={Text("ملاحظة مشتركة / توضيح السبب")},modifier=Modifier.fillMaxWidth())
                    }
                    items(roster.filter { it.massarCode in selected },key={"reason:"+it.massarCode}) { s ->
                        var expanded by remember {mutableStateOf(false)}
                        Column {
                            TextButton(onClick={expanded=!expanded}){Text("${s.givenName} ${s.surname} • ${effectiveReason(s.massarCode).ifBlank {"لم يحدد السبب"}} ▾")}
                            if(expanded){
                                RosterFilter("السبب المشترك",selected[s.massarCode].orEmpty(),expulsionReasons,Modifier.fillMaxWidth()){selected[s.massarCode]=it;notes.remove(s.massarCode)}
                                OutlinedTextField(effectiveNote(s.massarCode),{notes[s.massarCode]=it},label={Text("ملاحظة خاصة بالتلميذ")},modifier=Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }
            Button(enabled=!busy && teacher!=null && suggestion!=null && selected.isNotEmpty() && selected.keys.all { code->effectiveReason(code).isNotBlank() && (effectiveReason(code)!="سبب آخر" || effectiveNote(code).isNotBlank()) },modifier=Modifier.fillMaxWidth(),onClick={
                val t=teacher ?: return@Button
                val id=UUID.randomUUID().toString()
                val batch=roster.filter {it.massarCode in selected && it.className==section}.map { s ->
                    ConductRecord(id+":"+s.massarCode,year,expulsionKind,s.massarCode,s.givenName+" "+s.surname,section,s.levelName,date,suggestion.orEmpty(),t.teacherName,arabicConductSubject(t.subjectName),t.teacherCode,effectiveReason(s.massarCode),effectiveNote(s.massarCode),"","","","","",true,false,false)
                }
                busy=true;scope.launch {runCatching {dao.recordClassExpulsions(batch)}.onSuccess {close();message="تم حفظ ${batch.size} حالة"}.onFailure {message="تعذر الحفظ"};busy=false}
            }){Text("حفظ الإخراج (${selected.size})")}
        } else {
            val visible=rows.filter { (section.isBlank() || it.section==section) && (teacherFilter.isBlank() || it.teacher==teacherFilter) && (!dateFilter || it.date in from..to) && pupilPrefix(query,it.studentName,it.massar) }
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){
                item { Button(onClick={adding=true;section="";query=""}){Text("تسجيل إخراج التلاميذ من الحصة")} }
                item { Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){SummaryCard("الحوادث",visible.map {it.id.substringBefore(":")}.distinct().size.toString(),Modifier.weight(1f));SummaryCard("الحالات",visible.size.toString(),Modifier.weight(1f));SummaryCard("التلاميذ",visible.map {it.massar}.distinct().size.toString(),Modifier.weight(1f))} }
                item {
                    var classMenu by remember { mutableStateOf(false) }
                    var staffMenu by remember { mutableStateOf(false) }
                    OutlinedTextField(value=query,onValueChange={query=it},singleLine=true,
                        label={Text("بحث عن تلميذ")},modifier=Modifier.fillMaxWidth(),
                        trailingIcon={Row {
                            Box { TextButton(onClick={classMenu=true},contentPadding=PaddingValues(3.dp)){Text(if(section.isBlank()) "الأقسام ▾" else "$section ▾",style=MaterialTheme.typography.labelSmall)}
                                DropdownMenu(expanded=classMenu,onDismissRequest={classMenu=false}) {
                                    DropdownMenuItem(text={Text("جميع الأقسام")},onClick={section="";classMenu=false})
                                    schoolSections(rows.map{it.section}).forEach { c->DropdownMenuItem(text={Text(c)},onClick={section=c;classMenu=false}) }
                                }
                            }
                            Box { TextButton(onClick={staffMenu=true},contentPadding=PaddingValues(3.dp)){Text(if(teacherFilter.isBlank()) "الأساتذة ▾" else "أستاذ محدد ▾",style=MaterialTheme.typography.labelSmall)}
                                DropdownMenu(expanded=staffMenu,onDismissRequest={staffMenu=false}) {
                                    DropdownMenuItem(text={Text("جميع الأساتذة")},onClick={teacherFilter="";staffMenu=false})
                                    rows.map{it.teacher}.filter{it.isNotBlank()}.distinct().sorted().forEach { t->DropdownMenuItem(text={Text(t)},onClick={teacherFilter=t;staffMenu=false}) }
                                }
                            }
                        }})
                }
                item { Row {Checkbox(dateFilter,{dateFilter=it});Text("حسب الفترة",Modifier.padding(top=12.dp))};if(dateFilter)Row {DayPicker(from){from=it;if(to<it)to=it};DayPicker(to){to=it;if(from>it)from=it}} }
                item { TableExport("إخراج التلاميذ من الحصة",school,academy,province,year,listOf("الاسم","مسار","القسم","التاريخ","الحصة","المادة","الأستاذ","السبب","ملاحظة"),listOf(ExportGroup("الحالات: ${visible.size} • التلاميذ: ${visible.map {it.massar}.distinct().size} • الحوادث: ${visible.map {it.id.substringBefore(":")}.distinct().size}",visible.map {listOf(it.studentName,it.massar,it.section,it.date,it.time,it.subject,it.teacher,it.reasons,it.proposed)}))) }
                if(visible.isEmpty()) item {Text("لا توجد سجلات")}
                items(visible,key={it.id}){r->
                    var action by remember(r.id){mutableStateOf("")}
                    if(action.isNotEmpty()) ManageConduct(dao,r,action=="delete"){action=""}
                    RecordSwipe(r.id,{action="edit"},{action="delete"}) { OutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(9.dp)){Text(r.studentName+" • "+r.section);Text(r.date+" • "+r.time+" • "+r.teacher+" • "+r.subject);Text(r.reasons);if(r.proposed.isNotBlank())Text(r.proposed)}}} }
            }
        }
    }
}
