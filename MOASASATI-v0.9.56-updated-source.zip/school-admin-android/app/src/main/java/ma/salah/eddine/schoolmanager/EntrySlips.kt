package ma.salah.eddine.schoolmanager

import androidx.compose.foundation.horizontalScroll
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ma.salah.eddine.schoolmanager.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.UUID

private val clockFormat = DateTimeFormatter.ofPattern("HH:mm", java.util.Locale.ROOT)
private val reasons = listOf("غياب", "تأخر")

@Composable
internal fun DayPicker(date: String, change: (String) -> Unit) {
    val context = LocalContext.current
    OutlinedButton(onClick = {
        val d = LocalDate.parse(date)
        DatePickerDialog(context, { _, y, m, day -> change(LocalDate.of(y,m+1,day).toString()) },
            d.year,d.monthValue-1,d.dayOfMonth).show()
    }) { Text(date) }
}

@Composable
private fun SlipStats(rows: List<SlipRow>, personal: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        SummaryCard("الأوراق", rows.distinctBy { it.id }.size.toString(), Modifier.weight(1f))
        for (reason in reasons) {
            val group = rows.filter { it.reason == reason }
            val count = if (personal) group.distinctBy { it.id }.size else group.distinctBy { it.massar }.size
            SummaryCard(if (personal) "أوراق $reason" else if (reason=="غياب") "المتغيبون" else "المتأخرون",count.toString(),Modifier.weight(1f))
        }
    }
}

@Composable
private fun SlipList(dao:SchoolDao, rows: List<SlipRow>, open: (String) -> Unit) {
    if (rows.isEmpty()) Text("لا توجد أوراق مسجّلة")
    rows.groupBy { it.id }.forEach { (id, students) ->
        val slip = students.first()
        key(id) {
            var action by remember { mutableStateOf("") }
            if(action.isNotEmpty()) {
                var entry by remember { mutableStateOf<EntrySlip?>(null) }
                var count by remember { mutableIntStateOf(0) }
                LaunchedEffect(id) { count=dao.recipients(id).size;entry=dao.slip(id);if(entry==null)action="" }
                entry?.let { ManageSlip(dao,it,count,action=="delete"){action=""} }
            }
            RecordSwipe(id,{action="edit"},{action="delete"}) {
        OutlinedCard(Modifier.fillMaxWidth().clickable { open(id) }) {
            Column(Modifier.padding(horizontal=12.dp,vertical=7.dp)) {
                Text("${slip.date}   ${slip.time}   •   ${slip.reason}", style=MaterialTheme.typography.titleMedium)
                Text(slip.section + "   •   " + students.size + " تلميذ(ة)",style=MaterialTheme.typography.bodySmall)
            }
        }
            }
        }
    }
}

@Composable
private fun SlipDetails(dao: SchoolDao, id: String, close: () -> Unit) {
    var slip by remember(id) { mutableStateOf<EntrySlip?>(null) }
    var students by remember(id) { mutableStateOf(emptyList<SlipStudent>()) }
    var manage by remember(id){mutableStateOf(false)}
    var removing by remember(id){mutableStateOf<SlipStudent?>(null)}
    val scope=rememberCoroutineScope()
    LaunchedEffect(id) { students=dao.recipients(id); slip=dao.slip(id) }
    if(manage && slip!=null) { ManageSlip(dao,slip!!,students.size){manage=false;close()}; return }
    removing?.let { pupil ->
        AlertDialog(onDismissRequest={removing=null},title={Text("تأكيد الحذف")},text={Text("إزالة ${pupil.displayName} من هذه الورقة فقط؟" + if(students.size==1) " ستُحذف الورقة لأنها ستصبح فارغة." else " لن تتأثر سجلات بقية التلاميذ.")},confirmButton={TextButton(onClick={scope.launch {dao.removeSlipRecipient(id,pupil.massar);removing=null;close()}}){Text("حذف")}},dismissButton={TextButton(onClick={removing=null}){Text("إلغاء")}})
        return
    }
    AlertDialog(onDismissRequest=close,title={Text("تفاصيل ورقة الدخول")},text={
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            slip?.let { d ->
                Text("${d.date}   ${d.time}   •   ${d.reason}   •   ${d.section}")
                students.forEach { pupil -> Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Text("${pupil.ordinal ?: "—"}. ${pupil.displayName}",Modifier.weight(1f));IconButton(onClick={removing=pupil}){Icon(Icons.Default.Delete,contentDescription="حذف ${pupil.displayName} من الورقة",tint=MaterialTheme.colorScheme.error)}} }
                HorizontalDivider()
                if (d.guardianStudent.isBlank()) {
                    Text("لم يحضر ولي الأمر")
                } else {
                    Text("حضر ولي الأمر للتلميذ: "+students.firstOrNull { it.massar==d.guardianStudent }?.displayName.orEmpty())
                    Text("صفة الحاضر: "+d.relation)
                    Text("اسم الحاضر: "+d.guardianName.ifBlank { "غير مسجل" })
                    if (d.identity.isNotBlank()) Text("رقم البطاقة الوطنية: "+d.identity)
                }
            }
        }
    },confirmButton={TextButton(onClick=close){Text("إغلاق")}},dismissButton={TextButton(onClick={manage=true}){Text("تعديل أو حذف")}})
}

@Composable
internal fun PersonalSlips(dao: SchoolDao, year: String, student: String) {
    val rows by remember(dao,year,student) { dao.slipRows(year,"",student) }.collectAsState(initial=emptyList())
    var expanded by rememberSaveable(student) { mutableStateOf(false) }
    var id by remember { mutableStateOf("") }
    Text("أوراق الدخول • $year")
    SlipStats(rows,true)
    if(rows.isNotEmpty()) TextButton(onClick={expanded=!expanded}) {Text(if(expanded) "طيّ السجل" else "عرض سجل التلميذ")}
    if (rows.any { it.guardianStudent == student && it.reason == "تأخر" }) {
        Text("ملاحظة: سبق حضور ولي الأمر مع ورقة دخول لهذا التلميذ", color=MaterialTheme.colorScheme.primary)
    }
    if(expanded) SlipList(dao,rows){id=it}
    if(id.isNotEmpty()) SlipDetails(dao,id){id=""}
}

@Composable
internal fun SlipsScreen(dao: SchoolDao, year: String, sections: List<String>, back: () -> Unit) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var tab by rememberSaveable { mutableStateOf("سجل الغياب والتأخر") }
    var chosenDate by rememberSaveable { mutableStateOf("") }
    var today by remember { mutableStateOf(LocalDate.now()) }
    LaunchedEffect(Unit) { while(true){today=LocalDate.now();kotlinx.coroutines.delay(15000)} }
    val date=chosenDate.ifBlank {today.toString()}
    var period by rememberSaveable(year) { mutableStateOf(SlipPeriod.ALL) }
    var from by rememberSaveable(year) {mutableStateOf(today.toString())}
    var until by rememberSaveable(year) {mutableStateOf(today.toString())}
    var classFilter by rememberSaveable(year) {mutableStateOf("")}
    var customTime by rememberSaveable { mutableStateOf("") }
    var reason by rememberSaveable { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var chosen by rememberSaveable { mutableStateOf(arrayListOf<String>()) }
    var owner by rememberSaveable { mutableStateOf("") }
    var guardianPresent by rememberSaveable { mutableStateOf(false) }
    var guardian by rememberSaveable { mutableStateOf("") }
    var identity by rememberSaveable { mutableStateOf("") }
    var relation by rememberSaveable { mutableStateOf("") }
    var other by rememberSaveable { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var details by remember { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("") }
    var roster by remember(year) { mutableStateOf(emptyList<StudentListRow>()) }
    LaunchedEffect(year) { roster=dao.studentsForYear(year) }
    val allSlipRows by remember(dao,year) { dao.slipRows(year,"","") }.collectAsState(initial=emptyList())
    val daily=remember(allSlipRows,date){allSlipRows.filter { slipDay(it.date)?.toString()==date }}
    val entries=remember(allSlipRows,period,today,from,until){
        val start=LocalDate.parse(from);val end=LocalDate.parse(until)
        allSlipRows.filter { period.includes(it.date,today,start,end) }
    }
    val visible=remember(entries,classFilter,filter){entries.filter {
        (classFilter.isEmpty() || it.section==classFilter) && (filter.isBlank() || pupilPrefix(filter,it.displayName,it.massar,it.ordinal?.toString().orEmpty()))
    }.let { rows -> if(filter.isBlank()) rows else rows.filter { row -> entries.any { it.massar==row.massar && it.reason=="غياب" } } }}
    val commitments by remember(dao,year){dao.conduct(year)}.collectAsState(emptyList())
    val selected=roster.filter { it.massarCode in chosen && it.className==section }
    val effectiveOwner=if(selected.size==1) selected.first().massarCode else owner
    var phone by rememberSaveable { mutableStateOf("") }
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(year,effectiveOwner,relation,guardianPresent) {
        ready=false;guardian="";identity="";phone=""
        if(guardianPresent && effectiveOwner.isNotBlank() && relation in listOf("الأب","الأم")) {
            val contact=dao.family(year,effectiveOwner).firstOrNull { it.role==relation }
            guardian=contact?.name.orEmpty();phone=contact?.phone.orEmpty()
            identity=dao.setting("family.id.$year.$effectiveOwner.$relation").orEmpty()
        }
        ready=true
    }
    fun matches(s:StudentListRow,input:String):Boolean {
        val q=input.trim().map { it.digitToIntOrNull()?.digitToChar() ?: it }.joinToString("")
        return if(q.toIntOrNull()!=null) s.ordinal==q.toIntOrNull()
        else pupilPrefix(q,s.massarCode,s.givenName,s.surname)
    }
    if(tab=="مراسلات الغياب") { NoticeScreen(dao,year,roster){tab="سجل الغياب والتأخر"};return }
    BackHandler(onBack=back)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
        PageTitle("الغياب",back)
        if (tab == "سجل الغياب والتأخر") {
            SlipStats(visible)
        } else {
            DayPicker(date){chosenDate=it}
            SlipStats(daily)
        }
        SegmentedTabs(listOf("تسجيل ورقة الدخول","سجل الغياب والتأخر","مراسلات الغياب"),tab){tab=it}
        if(message.isNotEmpty()) Text(message)
        when(tab) {
            "سجل الغياب والتأخر" -> {
                var sort by rememberSaveable { mutableStateOf("الأكثر غياباً") }
                Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)){
                    SlipPeriod.entries.forEach { option ->
                        FilterChip(selected=period==option,onClick={today=LocalDate.now();period=option},label={Text(option.title)})
                    }
                }
                if(period==SlipPeriod.TODAY) Text("تاريخ اليوم: "+today)
                if(period==SlipPeriod.RANGE) Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Column {Text("من");DayPicker(from){from=it;if(until<it)until=it}}
                    Column {Text("إلى");DayPicker(until){until=it;if(from>it)from=it}}
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
                    RosterFilter("حسب القسم",classFilter,schoolSections(sections+entries.map {it.section}),Modifier.weight(1f)){classFilter=it}
                    SearchBox(filter,{filter=it},"بحث في المتغيبين",Modifier.weight(1.6f))
                }
                RosterFilter("الترتيب",sort,listOf("الأكثر غياباً","الأكثر تأخراً","الأقل غياباً","الأقل تأخراً","الأحدث أولاً","الأقدم أولاً"),Modifier.fillMaxWidth()){sort=it.ifBlank {"الأكثر غياباً"}}
                val groups = visible.groupBy { it.massar }.values.toList()
                fun count(rows: List<SlipRow>, reason: String) = rows.filter { it.reason == reason }.distinctBy { it.id }.size
                val ordered = when(sort) {
                    "الأكثر غياباً" -> groups.sortedByDescending { count(it,"غياب") }
                    "الأكثر تأخراً" -> groups.sortedByDescending { count(it,"تأخر") }
                    "الأقل غياباً" -> groups.sortedBy { count(it,"غياب") }
                    "الأقل تأخراً" -> groups.sortedBy { count(it,"تأخر") }
                    "الأقدم أولاً" -> groups.sortedBy { rows -> rows.mapNotNull { slipDay(it.date) }.minOrNull() }
                    else -> groups.sortedByDescending { rows -> rows.mapNotNull { slipDay(it.date) }.maxOrNull() }
                }
                if(ordered.isEmpty()) Text("لا توجد أوراق مسجّلة")
                ordered.forEach { rows ->
                    val student=rows.first()
                    key(student.massar) {
                    var expanded by remember(student.massar) { mutableStateOf(false) }
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(defaultElevation=1.dp)) {
                        Column(Modifier.fillMaxWidth().clickable { expanded=!expanded }.padding(horizontal=12.dp,vertical=9.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                Box(Modifier.size(30.dp).background(Color(0xFFE3F1F5),CircleShape),contentAlignment=Alignment.Center) {
                                    Text(rows.distinctBy { it.id }.size.toString(),color=Navy,fontWeight=FontWeight.Bold,fontSize=13.sp)
                                }
                                Text(student.displayName,Modifier.weight(1f),style=MaterialTheme.typography.titleSmall,maxLines=1,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                Icon(if(expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,null,tint=Color(0xFF6B7F8C))
                            }
                            val latest=rows.filter { slipDay(it.date) != null }.maxByOrNull { slipDay(it.date)!! }
                            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                                StatusPill(student.section,Color(0xFF11678B))
                                StatusPill("غياب "+count(rows,"غياب"),Color(0xFFB83E3E))
                                StatusPill("تأخر "+count(rows,"تأخر"),Color(0xFFB47B18))
                                Text(latest?.date.orEmpty(),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
                            }
                            if(expanded) SlipList(dao,rows.sortedWith(compareByDescending<SlipRow>{slipDay(it.date)}.thenByDescending{it.time})){details=it}
                        }
                    }
                    }
                }
            }
            else -> {
                OutlinedButton(onClick={
                    val t=if(customTime.isEmpty()) LocalTime.now() else LocalTime.parse(customTime)
                    TimePickerDialog(context,{_,h,m->customTime=LocalTime.of(h,m).format(clockFormat)},t.hour,t.minute,true).show()
                }) {Text("وقت التسليم: "+customTime.ifBlank { LocalTime.now().format(clockFormat)+" (تلقائي)" })}
                Row { reasons.forEach { r ->
                    Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(reason==r,{reason=r}); Text(r) }
                } }
                RosterFilter("حسب القسم",section,schoolSections(sections),Modifier.fillMaxWidth()){
                    if(section!=it){section=it;chosen=arrayListOf();owner="";guardianPresent=false;guardian="";identity="";relation="";other="";query=""}
                }
                if(section.isNotBlank()) {
                    SearchBox(query,{query=it},"الرقم الترتيبي أو الاسم")
                    val candidates=roster.filter { it.className==section && (it.massarCode in chosen || (query.isNotBlank() && matches(it,query))) }
                    candidates.forEach { s ->
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(s.massarCode in chosen,{checked->
                                chosen=ArrayList(if(checked) chosen+s.massarCode else chosen-s.massarCode)
                                if(!checked && owner==s.massarCode) owner=""
                                query=""
                            })
                            Text("${s.ordinal ?: "—"}. ${s.givenName} ${s.surname}")
                        }
                    }
                }
                if(selected.isNotEmpty()) {
                    selected.forEach { pupil ->
                        val prior=commitments.filter { it.massar==pupil.massarCode && it.kind=="التزامات غياب" && (slipDay(it.date)?.let { d -> d<=LocalDate.parse(date) } ?: false) }
                        if(prior.isNotEmpty()) key(pupil.massarCode) {
                            var expanded by remember { mutableStateOf(false) }
                            TextButton(onClick={expanded=!expanded}) { Text("تنبيه: ${pupil.givenName} ${pupil.surname} • التزام غياب سابق (${prior.size})",color=MaterialTheme.colorScheme.error) }
                            if(expanded) prior.forEach { Text("${it.date} • ${it.reasons}",color=MaterialTheme.colorScheme.error) }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically,
                        horizontalArrangement=Arrangement.SpaceBetween) {
                        Text("هل حضر ولي الأمر؟", style=MaterialTheme.typography.titleMedium)
                        Switch(checked=guardianPresent,onCheckedChange={guardianPresent=it})
                    }
                    if (guardianPresent) {
                        Text("ولي أمر أي تلميذ حضر؟")
                        selected.forEach { s ->
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                RadioButton(effectiveOwner==s.massarCode,{owner=s.massarCode})
                                Text(s.givenName+" "+s.surname)
                            }
                        }
                        RosterFilter("صفة الحاضر",relation,listOf("الأب","الأم","الأخ","الأخت","العم","أخرى"),Modifier.fillMaxWidth()){relation=it}
                        if(relation=="أخرى") OutlinedTextField(other,{other=it},label={Text("الصفة")},singleLine=true)
                        if(relation in listOf("الأب","الأم")) OutlinedTextField(phone,{phone=it},label={Text("رقم الهاتف")},singleLine=true,enabled=ready)
                        OutlinedTextField(guardian,{guardian=it},label={Text("اسم ولي الأمر")},singleLine=true)
                        OutlinedTextField(identity,{identity=it},label={Text("رقم البطاقة الوطنية (اختياري)")},singleLine=true)
                    }
                }
                Button(enabled=!busy && ready && reason in reasons && selected.isNotEmpty() && (!guardianPresent || (selected.any { it.massarCode==effectiveOwner } &&
                    relation.isNotBlank() && (relation!="أخرى" || other.isNotBlank()))),onClick={
                    busy=true
                    val id=UUID.randomUUID().toString()
                    val slip=EntrySlip(id,year,date,customTime.ifBlank { LocalTime.now().format(clockFormat) },section,reason,if(guardianPresent) effectiveOwner else "",
                        if(guardianPresent) guardian.trim() else "",if(guardianPresent) (if(relation=="أخرى") other.trim() else relation) else "",if(guardianPresent) identity.trim() else "")
                    val people=selected.map { SlipStudent(id,it.massarCode,it.givenName+" "+it.surname,it.ordinal) }
                    scope.launch {
                        runCatching { dao.recordSlip(slip,people,phone.trim()) }.onSuccess {
                            chosen=arrayListOf();owner="";guardianPresent=false;guardian="";identity="";relation="";other="";query="";customTime="";chosenDate="";message="حُفظت الورقة • "+slip.time
                        }.onFailure {message="تعذّر حفظ الورقة. حاول مجدداً."}
                        busy=false
                    }
                }) {Text("حفظ الورقة")}
            }
        }
    }
    if(details.isNotBlank()) SlipDetails(dao,details){details=""}
}
