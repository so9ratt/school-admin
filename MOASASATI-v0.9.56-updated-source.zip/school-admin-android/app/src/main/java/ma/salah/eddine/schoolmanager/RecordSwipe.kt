package ma.salah.eddine.schoolmanager

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
internal fun RecordSwipe(id: String, edit: () -> Unit, delete: () -> Unit, content: @Composable () -> Unit) {
    key(id) {
        val width = with(LocalDensity.current) { 100.dp.toPx() }
        var shift by remember { mutableFloatStateOf(0f) }
        Box(Modifier.fillMaxWidth().clipToBounds()) {
            if (shift > 0f) Row(Modifier.align(androidx.compose.ui.AbsoluteAlignment.CenterLeft).width(100.dp),
                horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton({ shift = 0f; edit() }) { Icon(Icons.Default.Edit, "تعديل السجل", tint = MaterialTheme.colorScheme.primary) }
                IconButton({ shift = 0f; delete() }) { Icon(Icons.Default.Delete, "حذف السجل", tint = MaterialTheme.colorScheme.error) }
            }
            Box(Modifier.fillMaxWidth().absoluteOffset { IntOffset(shift.roundToInt(), 0) }
                .then(if (shift > 0f) Modifier.background(MaterialTheme.colorScheme.surface) else Modifier)
                .draggable(rememberDraggableState { delta -> shift = (shift + delta).coerceIn(0f, width) },
                    Orientation.Horizontal, reverseDirection = false, onDragStopped = { velocity ->
                        shift = if (velocity > 550 || (velocity >= -550 && shift >= width / 2)) width else 0f
                    })) { content() }
        }
    }
}
