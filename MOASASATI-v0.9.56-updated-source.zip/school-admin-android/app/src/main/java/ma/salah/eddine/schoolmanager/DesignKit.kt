package ma.salah.eddine.schoolmanager

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * نظام الأزرار والمكونات (0.9.52).
 * Button وOutlinedButton هنا يسبقان نسخ material3 في كل ملف يستورد material3.* لأن الإعلانات في الحزمة نفسها
 * لها أولوية على الاستيراد بالنجمة؛ فتتوحد الأزرار كلها: ارتفاع لا يقل عن 48، زوايا 14، ألوان ثابتة.
 */
private val kitPrimary = Color(0xFF0F5B7C)
private val kitLine = Color(0xFFBFD3DD)

@Composable
internal fun Button(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(14.dp),
    colors: ButtonColors = ButtonDefaults.buttonColors(containerColor = kitPrimary, contentColor = Color.White,
        disabledContainerColor = Color(0xFFC9D8E0), disabledContentColor = Color(0xFF6B7F8C)),
    elevation: ButtonElevation? = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
    border: BorderStroke? = null,
    contentPadding: PaddingValues = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
    content: @Composable RowScope.() -> Unit
) {
    androidx.compose.material3.Button(onClick = onClick, modifier = modifier.heightIn(min = 48.dp), enabled = enabled, shape = shape,
        colors = colors, elevation = elevation, border = border, contentPadding = contentPadding, content = content)
}

@Composable
internal fun OutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(14.dp),
    colors: ButtonColors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = kitPrimary),
    elevation: ButtonElevation? = null,
    border: BorderStroke? = BorderStroke(1.5.dp, kitLine),
    contentPadding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    content: @Composable RowScope.() -> Unit
) {
    androidx.compose.material3.OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 46.dp), enabled = enabled, shape = shape,
        colors = colors, elevation = elevation, border = border, contentPadding = contentPadding, content = content)
}

/** شارة حالة ملونة: غياب، تأخر، قسم… */
@Composable
internal fun StatusPill(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = modifier.background(color.copy(alpha = 0.12f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
}

/** تبويب مقسوم (Segmented): الخيار النشط أبيض ببروز خفيف. */
@Composable
internal fun SegmentedTabs(options: List<String>, selected: String, modifier: Modifier = Modifier, onSelect: (String) -> Unit) {
    Row(modifier.fillMaxWidth().background(Color(0xFFE6EEF3), RoundedCornerShape(16.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { option ->
            val on = option == selected
            Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (on) Color.White else Color.Transparent)
                .clickable { onSelect(option) }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
                Text(option, color = if (on) Navy else Color(0xFF5B7080), fontWeight = if (on) FontWeight.ExtraBold else FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun LegendRow(color: Color, label: String, value: Int) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(10.dp).background(color, RoundedCornerShape(3.dp)))
        Text(label, fontSize = 13.sp, color = Navy)
        Text(value.toString(), fontSize = 13.sp, color = Navy, fontWeight = FontWeight.Bold)
    }
}

/** رسم دائري لتوزيع الإناث والذكور. */
@Composable
internal fun GenderDonut(females: Int, males: Int, modifier: Modifier = Modifier) {
    val total = (females + males).coerceAtLeast(1)
    val share = females.toFloat() / total
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = 16.dp.toPx()
                    val arc = Size(size.width - w, size.height - w)
                    val corner = Offset(w / 2, w / 2)
                    drawArc(color = Color(0xFFDCEFF5), startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = corner, size = arc, style = Stroke(w))
                    drawArc(color = Color(0xFF11678B), startAngle = -90f, sweepAngle = 360f * share, useCenter = false, topLeft = corner, size = arc, style = Stroke(w))
                }
                Text("%.1f%%".format(java.util.Locale.ROOT, share * 100), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("التوزيع حسب الجنس", color = Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                LegendRow(Color(0xFF11678B), "الإناث", females)
                LegendRow(Color(0xFFB7D9E6), "الذكور", males)
            }
        }
    }
}
