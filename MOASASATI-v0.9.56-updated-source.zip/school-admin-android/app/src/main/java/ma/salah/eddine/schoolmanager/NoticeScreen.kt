package ma.salah.eddine.schoolmanager

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.*
import org.json.JSONArray
import java.time.LocalDate
import java.util.UUID

private val ocean=Color(0xFF124C62)
private val sea=Color(0xFF15736C)
private val rust=Color(0xFF964C1B)

@Composable private fun NoticeBanner(title:String,sub:String) {
    Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(ocean,sea)),RoundedCornerShape(18.dp)).padding(16.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Default.MailOutline,null,tint=Color.White)
        Column {Text(title,color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold);Text(sub,color=Color.White,fontSize=12.sp)}
    }
}

@Composable private fun NoticePanel(content:@Composable ColumnScope.()->Unit) {
    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
        Column(Modifier.fillMaxWidth().padding(13.dp),verticalArrangement=Arrangement.spacedBy(6.dp),content=content)
    }
}

@Composable internal fun NoticeScreen(dao:SchoolDao,year:String,roster:List<StudentListRow>,close:()->Unit) {
    val key="absence.notices.$year"
    val raw by remember(key){dao.watchSetting(key)}.collectAsState(null)
    val cases=remember(raw){noticeCases(raw)}
    var screen by rememberSaveable(year){mutableStateOf("list")}
    var focus by rememberSaveable(year){mutableStateOf("")}
    var message by remember {mutableStateOf("")}
    var busy by remember {mutableStateOf(false)}
    var today by remember {mutableStateOf(LocalDate.now())}
    LaunchedEffect(Unit){while(true){today=LocalDate.now();kotlinx.coroutines.delay(30000)}}
    val scope=rememberCoroutineScope()
    fun back(){if(screen=="list")close() else {screen="list";message=""}}
    BackHandler {back()}
    fun save(new:List<NoticeCase>,done:()->Unit) {
        if(busy)return
        val expected=raw
        busy=true
        scope.launch {try {
            dao.writeNoticeLedger(key,expected,JSONArray().apply {new.forEach {put(it.json())}}.toString())
            done();message="تم حفظ المتابعة"
        }catch(e:Exception){message=e.localizedMessage.orEmpty()}finally{busy=false}}
    }
    val selected=remember(year){mutableStateListOf<String>()}
    fun check(id:String){if(!selected.remove(id)) selected.add(id)}
    Column(Modifier.fillMaxSize().padding(horizontal=12.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        PageTitle(when(screen){"new"->"بدء تتبع الغياب";"detail"->"ملف التتبع";"export"->"سجل المراسلات";else->"مراسلات الغياب"}){back()}
        if(message.isNotBlank()) Text(message,color=ocean,modifier=Modifier.clickable{message=""})
        when(screen){
            "new" -> StartNotices(dao,year,roster,cases,today,busy){ additions ->
                save(cases+additions){ screen="list" }
            }
            "detail" -> cases.find {it.id==focus}?.let { file ->
                NoticeDetails(file,today,busy){ change -> save(cases.map {if(it.id==focus)change else it}){} }
            }
            "export" -> NoticeRegister(dao,year,cases,today)
            else -> {
                var section by rememberSaveable {mutableStateOf("")}
                var phase by rememberSaveable {mutableStateOf("")}
                var q by rememberSaveable {mutableStateOf("")}
                val visible=cases.filter {
                    (section.isBlank() || it.section==section) && (phase.isBlank() || noticeTitles.getOrNull(it.next-1)==phase) &&
                        (q.isBlank() || pupilPrefix(q,it.name,it.massar))
                }.sortedWith(compareByDescending<NoticeCase>{it.available(today)}.thenBy {it.first}.thenBy {it.name})
                val batch=cases.filter {it.id in selected && it.available(today) && it.guardian.isNotBlank() && (it.next!=4 || it.status==stopped)}
                LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=20.dp)){
                    item {NoticeBanner("تتبع الغياب المستمر",year)}
                    item {Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
                        SummaryCard("ملفات مفتوحة",cases.count {it.status==ongoing}.toString(),Modifier.weight(1f))
                        SummaryCard("مستحقة",cases.count {it.available(today)}.toString(),Modifier.weight(1f))
                        SummaryCard("تمت مراسلتهم",cases.filter {it.sent.isNotEmpty()}.distinctBy {it.massar}.size.toString(),Modifier.weight(1f))
                    }}
                    item {Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Button({screen="new"},Modifier.weight(1f)){Text("بدء تتبع")}
                        OutlinedButton({screen="export"},Modifier.weight(1f)){Text("تصدير اللائحة")}
                    }}
                    item {SearchBox(q,{q=it},"اسم التلميذ أو رمز مسار")}
                    item {Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        RosterFilter("حسب القسم",section,schoolSections(cases.map {it.section}),Modifier.weight(1f)){section=it}
                        RosterFilter("حسب المرحلة",phase,noticeTitles,Modifier.weight(1f)){phase=it}
                    }}
                    if(batch.isNotEmpty()) item {NoticePanel {
                        Text("مراسلات محددة • "+batch.size,fontWeight=FontWeight.Bold)
                        NoticeActions(batch.map {NoticePage(it,it.next,today.toString(),"",it.guardian,it.address)})
                    }}
                    if(visible.isEmpty()) item {Text(if(cases.isEmpty())"اختر «بدء تتبع» لتحديد التلاميذ وتاريخ أول غياب." else "لا توجد ملفات مطابقة")}
                    items(visible,key={it.id}){f ->
                        NoticePanel { Row(verticalAlignment=Alignment.CenterVertically){
                            if(f.available(today) && f.guardian.isNotBlank() && (f.next!=4 || f.status==stopped))
                                Checkbox(f.id in selected,{check(f.id)})
                            Column(Modifier.weight(1f).clickable {focus=f.id;screen="detail"}) {
                                Text(f.name,fontWeight=FontWeight.Bold,color=ocean)
                                Text(f.section+"   •   "+displayDay(f.first),fontSize=13.sp)
                                val step=noticeTitles.getOrNull(f.next-1)
                                Text(if(f.status==ongoing && step!=null) step+"   •   "+displayDay(f.due(f.next).toString()) else f.status,color=if(f.available(today))rust else sea,fontSize=13.sp)
                            }
                            IconButton({focus=f.id;screen="detail"}){Icon(Icons.Default.KeyboardArrowLeft,"فتح ملف التتبع")}
                        }}
                    }
                }
            }
        }
    }
}

@Composable private fun StartNotices(dao:SchoolDao,year:String,roster:List<StudentListRow>,cases:List<NoticeCase>,today:LocalDate,busy:Boolean,commit:(List<NoticeCase>)->Unit) {
    val scope=rememberCoroutineScope()
    val selected=remember {mutableStateMapOf<String,String>()}
    var day by rememberSaveable {mutableStateOf(today.toString())}
    var section by rememberSaveable {mutableStateOf("")}
    var query by rememberSaveable {mutableStateOf("")}
    var preparing by remember {mutableStateOf(false)}
    var error by remember {mutableStateOf("")}
    val existing=cases.filter {it.status==ongoing || it.status==stopped}.map {it.massar}.toSet()
    val available=roster.filter {it.massarCode !in existing && (section=="" || section==it.className) && pupilPrefix(query,it.surname,it.givenName,it.massarCode,it.ordinal?.toString().orEmpty())}
    LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
        item {NoticeBanner("أول يوم غياب","حدّد التاريخ ثم أشّر على التلاميذ المعنيين")}
        item {DayPicker(day){if(it<=today.toString()){day=it;selected.keys.toList().forEach { k->selected[k]=it };error=""}else error="اختر تاريخًا حتى اليوم"}}
        item {RosterFilter("حسب القسم",section,schoolSections(roster.map {it.className}),Modifier.fillMaxWidth()){section=it}}
        item {SearchBox(query,{query=it},"الاسم أو الرقم الترتيبي أو مسار")}
        item {Button(enabled=selected.isNotEmpty() && !preparing && !busy,onClick={
            preparing=true
            scope.launch {try {
                val ids=selected.toMap()
                val created=roster.filter {it.massarCode in ids}.map {s ->
                    val contact=dao.family(year,s.massarCode).filter {it.name.isNotBlank()}.minByOrNull {when(it.role){"الأب"->0;"الأم"->1;else->2}}
                    NoticeCase(UUID.randomUUID().toString(),s.massarCode,s.givenName+" "+s.surname,s.className,ids.getValue(s.massarCode),contact?.name.orEmpty(),contact?.address.orEmpty())
                }
                commit(created)
            }catch(e:Exception){error=e.localizedMessage.orEmpty()}finally{preparing=false}}
        }) {Text("حفظ الملفات المحددة ("+selected.size+")")}
        if(error.isNotBlank())Text(error,color=rust)}
        items(available,key={it.massarCode}){s ->
            NoticePanel {
                Row(verticalAlignment=Alignment.CenterVertically){
                    Checkbox(s.massarCode in selected,{if(it)selected[s.massarCode]=day else selected.remove(s.massarCode)})
                    Text("${s.ordinal ?: "—"}. ${s.givenName} ${s.surname}",Modifier.weight(1f));Text(s.className,fontSize=12.sp)
                }
                selected[s.massarCode]?.let {date -> DayPicker(date){if(it<=today.toString())selected[s.massarCode]=it else error="تاريخ أول الغياب يتجاوز اليوم"}}
            }
        }
    }
}

@Composable private fun NoticeDetails(file:NoticeCase,today:LocalDate,busy:Boolean,update:(NoticeCase)->Unit) {
    var guardian by rememberSaveable(file.id,file.guardian){mutableStateOf(file.guardian)}
    var address by rememberSaveable(file.id,file.address){mutableStateOf(file.address)}
    var day by rememberSaveable(file.id,file.next){mutableStateOf(today.toString())}
    var number by rememberSaveable(file.id,file.next){mutableStateOf("")}
    var options by rememberSaveable(file.id){mutableStateOf(false)}
    var confirm by remember {mutableStateOf(false)}
    var status by rememberSaveable(file.id,file.status){mutableStateOf(file.status)}
    var visit by rememberSaveable(file.id,file.visit){mutableStateOf(file.visit)}
    var statusDay by rememberSaveable(file.id,file.statusDate){mutableStateOf(file.statusDate.ifBlank {today.toString()})}
    val next=file.next
    val ready=file.available(today) && guardian.isNotBlank() && (next!=4 || file.status==stopped)
    val validDate=ready && day in file.due(next).toString()..today.toString() && (file.sent.lastOrNull()?.day.orEmpty()<=day) &&
        (next!=4 || day>=file.statusDate)
    LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=24.dp)){
        item {NoticeBanner(file.name,file.section+"   •   "+file.massar)}
        item {NoticePanel {Text("أول غياب   "+displayDay(file.first),fontWeight=FontWeight.Bold);Text(file.status+(if(file.statusDate.isBlank())"" else "   •   "+displayDay(file.statusDate)),color=sea)
            Text("ولي الأمر   •   "+if(file.visit.isBlank())"لم يحضر" else "حضر يوم "+displayDay(file.visit))
            TextButton({options=!options}){Text(if(options)"إغلاق التحيين" else "تحيين الملف وبيانات ولي الأمر")}
            if(options){
                OutlinedTextField(guardian,{guardian=it},Modifier.fillMaxWidth(),label={Text("اسم المرسل إليه")})
                OutlinedTextField(address,{address=it},Modifier.fillMaxWidth(),label={Text("العنوان البريدي")})
                Row(verticalAlignment=Alignment.CenterVertically){Checkbox(visit.isNotBlank(),{visit=if(it)today.toString() else ""});Text("حضر ولي الأمر")}
                if(visit.isNotBlank())DayPicker(visit){visit=it}
                val states=listOf(ongoing,"التحق بالدراسة","قُدّم مبرر",stopped)
                RosterFilter("وضعية التلميذ",status,states,Modifier.fillMaxWidth()){status=it.ifBlank {ongoing}}
                if(status!=ongoing){Text("تاريخ تحيين الوضعية");DayPicker(statusDay){statusDay=it}}
                if(status==stopped)Text("بتأكيد الانقطاع تعتمد الإدارة القرار الوارد في مراسلة الانقطاع.",color=rust)
                Button(enabled=!busy && (visit=="" || visit in file.first..today.toString()) && (status==ongoing || statusDay in file.first..today.toString()),onClick={
                    update(file.copy(guardian=guardian.trim(),address=address.trim(),visit=visit,status=status,statusDate=if(status==ongoing)"" else statusDay));options=false
                }){Text("حفظ التحيين")}
            }
        }}
        items(4){index ->
            val stage=index+1;val dispatch=file.sent.getOrNull(index)
            val due=file.due(stage)
            NoticePanel {
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
                    Surface(color=if(dispatch!=null)sea else if(stage==next)ocean else Color(0xFFE3EAED),shape=RoundedCornerShape(12.dp)){
                        Text(stage.toString(),Modifier.padding(horizontal=13.dp,vertical=6.dp),color=if(dispatch!=null || stage==next)Color.White else ocean,fontWeight=FontWeight.Bold)
                    }
                    Column {Text(noticeTitles[index],fontWeight=FontWeight.Bold);Text("موعد الاستحقاق   "+displayDay(due.toString()),fontSize=12.sp)}
                }
                if(dispatch!=null){
                    Text("تمت المراسلة   "+displayDay(dispatch.day)+(if(dispatch.number.isBlank())"" else "   •   رقم "+dispatch.number),color=sea)
                    NoticeActions(listOf(NoticePage(file,stage,dispatch.day,dispatch.number,dispatch.guardian,dispatch.address)))
                }else if(stage==next && file.available(today)){
                    when {
                        stage==4 && file.status!=stopped -> Text("حان موعد مراجعة الانقطاع. أكّد وضعية التلميذ قبل طباعة الإشعار.",color=rust)
                        guardian.isBlank() -> Text("أدخل اسم ولي الأمر من «تحيين الملف» لإعداد المراسلة.",color=rust)
                        else -> {
                            Text("تاريخ المراسلة");DayPicker(day){day=it}
                            OutlinedTextField(number,{number=it},Modifier.fillMaxWidth(),singleLine=true,label={Text("رقم المراسلة")})
                            if(validDate){
                                NoticeActions(listOf(NoticePage(file,stage,day,number,guardian.trim(),address.trim())))
                                Button(enabled=!busy,onClick={confirm=true}){Text("تأكيد الإرسال الفعلي")}
                            }else Text("راجع التاريخ؛ يجب أن يقع بين الاستحقاق واليوم وبعد المراسلة السابقة.",color=rust)
                        }
                    }
                }else Text(if(file.status!=ongoing && file.status!=stopped)"أغلقت المتابعة" else if(due>today)"مبرمج" else "في انتظار المرحلة السابقة",color=Color.DarkGray,fontSize=12.sp)
            }
        }
    }
    if(confirm)AlertDialog(onDismissRequest={confirm=false},title={Text("تسجيل إرسال المراسلة؟")},text={Text(noticeTitles[next-1]+" إلى "+guardian+" بتاريخ "+displayDay(day))},
        confirmButton={TextButton(onClick={confirm=false
            if(validDate)update(file.copy(guardian=guardian.trim(),address=address.trim(),sent=file.sent+Dispatch(day,number.trim(),guardian.trim(),address.trim())))
        }){Text("تم الإرسال")}},dismissButton={TextButton({confirm=false}){Text("إلغاء")}})
}

@Composable private fun NoticeActions(letters:List<NoticePage>) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var envelopes by remember {mutableStateOf(false)}
    var message by remember {mutableStateOf("")}
    var pending by remember {mutableStateOf(emptyList<NoticePage>())}
    val pages=if(envelopes)letters.flatMap {listOf(it,it.copy(envelope=true))} else letters
    val save=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->
        if(uri!=null){
            val snapshot=pending
            scope.launch {message=runCatching {
                withContext(Dispatchers.IO){context.contentResolver.openOutputStream(uri,"wt")!!.use {writeNotices(context,snapshot,it)}}
                "تم حفظ PDF"
            }.getOrElse {"تعذّر التصدير، أعد المحاولة."}}
        }
    }
    val word=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")){uri ->
        if(uri!=null && letters.size==1) scope.launch {
            message=runCatching { withContext(Dispatchers.IO){
                context.contentResolver.openOutputStream(uri,"wt")!!.use {writeNoticeWord(context,letters.single(),it)}
            }; "تم حفظ نسخة Word" }.getOrElse { "تعذّر حفظ المراسلة" }
        }
    }
    Row(verticalAlignment=Alignment.CenterVertically){Checkbox(envelopes,{envelopes=it});Text("إرفاق صفحة العنوان البريدي",fontSize=12.sp)}
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
        if(letters.size==1) OutlinedButton(onClick={word.launch("مراسلة الغياب.docx")}){Text("Word")}
        OutlinedButton(onClick={pending=pages;save.launch("مراسلات الغياب.pdf")}){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(5.dp));Text("PDF")}
        OutlinedButton(onClick={runCatching {printNotices(context,pages)}.onFailure {message="تعذّر فتح خدمة الطباعة"}}){Icon(Icons.Default.Print,null);Spacer(Modifier.width(5.dp));Text("طباعة")}
    }
    if(message.isNotBlank())Text(message,fontSize=12.sp)
}

@Composable private fun NoticeRegister(dao:SchoolDao,year:String,cases:List<NoticeCase>,today:LocalDate) {
    var section by rememberSaveable {mutableStateOf("")}
    val all=cases.filter {it.sent.isNotEmpty()}
    var from by rememberSaveable {mutableStateOf(all.flatMap {it.sent}.minOfOrNull {it.day} ?: today.toString())}
    var to by rememberSaveable {mutableStateOf(today.toString())}
    val rows=all.mapNotNull { f ->
        val last=f.sent.indexOfLast {it.day in from..to}
        if(last<0 || (section.isNotBlank() && section!=f.section))null else f to last
    }.sortedWith(compareBy({it.first.section},{it.first.name}))
    val school by dao.watchSetting("schoolName").collectAsState(null)
    val academy by dao.watchSetting("academy").collectAsState(null)
    val province by dao.watchSetting("province").collectAsState(null)
    LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
        item {NoticeBanner("التلاميذ الذين تمت مراسلتهم","عدد التلاميذ   "+rows.distinctBy {it.first.massar}.size)}
        item {RosterFilter("حسب القسم",section,schoolSections(all.map {it.section}),Modifier.fillMaxWidth()){section=it}}
        item {Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){
            Column {Text("من");DayPicker(from){from=it;if(it>to)to=it}}
            Column {Text("إلى");DayPicker(to){to=it;if(it<from)from=it}}
        }}
        if(rows.isNotEmpty()) item {TableExport("لائحة المراسلات",school.orEmpty(),academy.orEmpty(),province.orEmpty(),year,
            listOf("مسار","التلميذ","القسم","أول غياب","آخر إشعار بالفترة","تاريخ الإرسال","رقم المراسلة","حضور ولي الأمر","الوضعية"),
            listOf(ExportGroup("المراسلات",rows.map {(f,i)->listOf(f.massar,f.name,f.section,displayDay(f.first),noticeTitles[i],displayDay(f.sent[i].day),f.sent[i].number,
                f.visit.takeIf {it.isNotBlank()}?.let(::displayDay) ?: "لم يحضر",f.status)})))}
        if(rows.isEmpty())item {Text("لا توجد مراسلات مؤكدة في هذه الفترة")}
        items(rows,key={it.first.id}){(f,i)->NoticePanel {Text(f.name,fontWeight=FontWeight.Bold);Text(f.section+"   •   "+noticeTitles[i]+"   •   "+displayDay(f.sent[i].day))}}
    }
}
