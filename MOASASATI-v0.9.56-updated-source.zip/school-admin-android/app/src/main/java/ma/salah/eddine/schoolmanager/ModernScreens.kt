package ma.salah.eddine.schoolmanager

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.*
import java.io.ByteArrayOutputStream

@Composable
internal fun SearchBox(value:String, change:(String)->Unit, hint:String, modifier:Modifier=Modifier.fillMaxWidth()) {
    OutlinedTextField(value,change,modifier,singleLine=true,
        shape=RoundedCornerShape(18.dp),
        placeholder={Text(hint,Modifier.fillMaxWidth(),textAlign=TextAlign.Center,color=Color(0xFF697184),fontSize=14.sp)},
        leadingIcon={Icon(Icons.Default.Search,"بحث")},
        colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White,focusedContainerColor=Color.White))
}

private fun thumbnail(context:Context,uri:Uri):String {
    val reader=context.contentResolver
    val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
    reader.openInputStream(uri)?.use { BitmapFactory.decodeStream(it,null,bounds) }
    require(bounds.outWidth>0 && bounds.outHeight>0)
    var sample=1
    while(maxOf(bounds.outWidth,bounds.outHeight)/sample>512) sample*=2
    val image=reader.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it,null,BitmapFactory.Options().apply { inSampleSize=sample })
    } ?: error("تعذرت قراءة الصورة")
    val side=minOf(image.width,image.height)
    val crop=Bitmap.createBitmap(image,(image.width-side)/2,(image.height-side)/2,side,side)
    val small=Bitmap.createScaledBitmap(crop,144,144,true)
    val bytes=ByteArrayOutputStream()
    check(small.compress(Bitmap.CompressFormat.JPEG,85,bytes))
    return Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP)
}

@Composable
internal fun StudentAvatar(code:String, editable:Boolean=false) {
    val context=LocalContext.current
    val dao=remember(context){SchoolDatabase.get(context).schoolDao()}
    val key="student.photo.$code"
    val data by remember(key){dao.watchSetting(key)}.collectAsState(initial=null)
    val picture=remember(data){data?.let { encoded ->
        runCatching {
            val raw=Base64.decode(encoded,Base64.NO_WRAP)
            BitmapFactory.decodeByteArray(raw,0,raw.size)?.asImageBitmap()
        }.getOrNull()
    }}
    val scope=rememberCoroutineScope()
    val picker=if(editable) rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){uri->
        if(uri!=null) scope.launch {
            runCatching { withContext(Dispatchers.IO){dao.saveSetting(AppSettingEntity(key,thumbnail(context,uri)))} }
                .onFailure { Toast.makeText(context,"تعذّر حفظ الصورة",Toast.LENGTH_SHORT).show() }
        }
    } else null
    val pick=if(picker!=null) Modifier.clickable(onClickLabel="اختيار صورة التلميذ"){picker.launch("image/*")} else Modifier
    Box(Modifier.size(if(editable) 54.dp else 44.dp).clip(CircleShape).background(Color.White)
        .border(1.dp,Color(0xFFD8DCE4),CircleShape).then(pick),contentAlignment=Alignment.Center) {
        if(picture!=null) Image(picture,"صورة التلميذ",Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
        else Icon(Icons.Default.Person,"صورة التلميذ",tint=Color.Gray,modifier=Modifier.size(32.dp))
    }
}

@Composable
internal fun StudentResult(s:StudentListRow,status:String="",open:()->Unit) {
    val context=LocalContext.current
    Card(onClick=open,modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){
            StudentAvatar(s.massarCode)
            Column(Modifier.weight(1f)){
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text("${s.ordinal ?: "—"}. ${s.givenName} ${s.surname}",Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=14.sp)
                    Text(s.massarCode,fontSize=12.sp)
                    IconButton(onClick={
                        val cb=context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cb.setPrimaryClip(ClipData.newPlainText("مسار",s.massarCode))
                    }){Icon(Icons.Default.ContentCopy,"نسخ رمز مسار",Modifier.size(16.dp))}
                }
                if(status.isNotBlank()) Text(status,color=Teal,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelSmall)
                Text(s.className+" • "+s.levelName,fontSize=11.sp,lineHeight=13.sp,color=MaterialTheme.colorScheme.secondary)
            }
            Icon(Icons.Default.ChevronLeft,"فتح البطاقة")
        }
    }
}

private data class Distribution(val women:Int,val men:Int,val unknown:Int) {
    val total get()=women+men+unknown
}
private fun distribution(values:List<String?>):Distribution {
    val women=values.count { it.orEmpty().isFemaleValue() }
    val men=values.count { it.orEmpty().isMaleValue() }
    return Distribution(women,men,values.size-women-men)
}
private fun idKey(value:String)=value.filterNot(Char::isWhitespace).uppercase(java.util.Locale.ROOT)
private val femaleColor=Color(0xFFE58A30)
private val maleColor=Color(0xFF087E80)
private val unknownColor=Color(0xFF687080)
private val Distribution.parts get()=listOf(women to femaleColor,men to maleColor,unknown to unknownColor)

@Composable
private fun GenderCard(title:String,counts:Distribution,modifier:Modifier=Modifier){
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.White)){
        Column(Modifier.fillMaxWidth().padding(10.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Text(title,fontWeight=FontWeight.Bold)
            Box(Modifier.size(86.dp),contentAlignment=Alignment.Center){
                Canvas(Modifier.fillMaxSize().padding(5.dp)){
                    val width=10.dp.toPx()
                    val bounds=Size(size.width-width,size.height-width)
                    val corner=Offset(width/2,width/2)
                    drawArc(Color(0xFFEBEDF3),0f,360f,false,corner,bounds,style=Stroke(width))
                    var angle=-90f
                    if(counts.total>0) for((count,color) in counts.parts){
                        val sweep=count*360f/counts.total
                        if(count>0) drawArc(color,angle,sweep,false,corner,bounds,style=Stroke(width))
                        angle+=sweep
                    }
                }
                Text(counts.total.toString(),fontWeight=FontWeight.Bold)
            }
            for((i,part) in counts.parts.withIndex()){
                val (n,color)=part
                if(i==2 && n==0) continue
                val label=listOf("إناث","ذكور","غير محدد")[i]
                val pct=if(counts.total==0) "0" else String.format(java.util.Locale.ROOT,"%.1f",n*100.0/counts.total)
                Row(verticalAlignment=Alignment.CenterVertically){
                    Icon(when(i){0->Icons.Default.Woman;1->Icons.Default.Man;else->Icons.Default.Person},null,Modifier.size(18.dp),tint=color)
                    Text("$label  $n  ($pct%)",fontSize=11.sp)
                }
            }
        }
    }
}

@Composable
internal fun InstitutionDashboard(school:String,level:String,province:String,year:String,counts:DashboardCounts,
    students:List<StudentListRow>,employees:List<EmployeeEntity>,assignments:List<TeacherAssignmentEntity>,back:()->Unit){
    var subject by rememberSaveable(year){mutableStateOf("")}
    val byId=remember(employees){employees.filter { !it.nationalId.isNullOrBlank() }.groupBy { idKey(it.nationalId.orEmpty()) }}
    val subjects=remember(assignments){assignments.groupBy { it.subjectName }.toSortedMap()}
    val filtered=if(subject.isBlank()) assignments else subjects[subject].orEmpty()
    fun teachers(rows:List<TeacherAssignmentEntity>)=distribution(rows.map { idKey(it.teacherCode) }.distinct().map {byId[it]?.singleOrNull()?.gender})
    val groups=remember(filtered,byId){filtered.groupBy { it.subjectName }.mapValues { teachers(it.value) }.toList().sortedByDescending { it.second.total }}
    val max=groups.maxOfOrNull { it.second.total }?.coerceAtLeast(1) ?: 1
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        item { PageTitle("المؤسسة",back) }
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color.White)){
                Column(Modifier.fillMaxWidth().padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally){
                    Text(school,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
                    Text("$level • $province • $year",fontSize=13.sp)
                }
            }
        }
        item { Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
            SummaryCard("التلاميذ",students.size.toString(),Modifier.weight(1f))
            SummaryCard("الأقسام",counts.classCount.toString(),Modifier.weight(1f))
            SummaryCard("الموظفون",employees.size.toString(),Modifier.weight(1f))
        }}
        item { Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            GenderCard("التلاميذ",distribution(students.map { it.gender }),Modifier.weight(1f))
            GenderCard("الموظفون",distribution(employees.map { it.gender }),Modifier.weight(1f))
        }}
        item { MetricGroup("التلاميذ حسب المستوى",students.groupingBy { it.levelName }.eachCount().toList().sortedBy { it.first }) }
        item { MetricGroup("التلاميذ حسب القسم",students.groupingBy { it.className }.eachCount().toList().sortedBy { it.first }) }
        item {Text("المدرّسون حسب المادة والجنس",fontWeight=FontWeight.Bold)}
        item {RosterFilter("حسب المادة",subject,subjects.keys.toList(),Modifier.fillMaxWidth()){subject=it}}
        item {GenderCard(if(subject.isBlank()) "جميع المدرّسين" else subject,teachers(filtered),Modifier.fillMaxWidth())}
        if(groups.isEmpty()) item {Text("تظهر إحصائيات المدرّسين بعد استيراد مستخرج الحصص")}
        items(groups,key={it.first}){(name,group)->
            Card(colors=CardDefaults.cardColors(containerColor=Color.White)){
                Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                    Text("$name  •  ${group.total}",fontWeight=FontWeight.Bold)
                    Row(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(Color(0xFFEBEDF3))){
                        group.parts.filter { it.first>0 }.forEach {(n,color)->Spacer(Modifier.weight(n.toFloat()).fillMaxHeight().background(color))}
                        if(max>group.total) Spacer(Modifier.weight((max-group.total).toFloat()))
                    }
                    Text("إناث ${group.women}   •   ذكور ${group.men}"+if(group.unknown>0) "   •   غير محدد ${group.unknown}" else "",fontSize=12.sp)
                }
            }
        }
    }
}
