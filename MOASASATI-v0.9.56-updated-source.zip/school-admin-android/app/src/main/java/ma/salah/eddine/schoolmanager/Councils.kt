package ma.salah.eddine.schoolmanager

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private val taskRoles=listOf("مدير المؤسسة","الناظر","الحارس العام للخارجية","الحارس العام للداخلية","مسير المصالح الاقتصادية","مستشار في التوجيه والتخطيط التربوي")
@Composable fun EmployeeTaskField(ppr:String){
 val context=LocalContext.current
 val prefs=remember{context.getSharedPreferences("employee_tasks",Context.MODE_PRIVATE)}
 var task by remember(ppr){mutableStateOf(prefs.getString(ppr,"").orEmpty())}
 var expanded by remember{mutableStateOf(false)}
 Column { Text("المهمة المسندة داخل المؤسسة"); OutlinedButton(onClick={expanded=true}){Text(task.ifBlank{"إسناد مهمة"})}; DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){(listOf("")+taskRoles).forEach{role->DropdownMenuItem(text={Text(role.ifBlank{"بدون مهمة"})},onClick={task=role;prefs.edit().putString(ppr,role).apply();expanded=false})}} }
}
private val peopleRoles=listOf("مدير المؤسسة","رئيس جمعية آباء وأولياء التلاميذ","مستشار في التوجيه والتخطيط التربوي","ممثل المجلس الجماعي")
@Composable fun InstitutionPeopleFields(){
 val c=LocalContext.current; val prefs=remember{c.getSharedPreferences("institution_people",Context.MODE_PRIVATE)}
 peopleRoles.forEach { role -> var v by rememberSaveable(role){mutableStateOf(prefs.getString(role,"").orEmpty())}; OutlinedTextField(v,{v=it;prefs.edit().putString(role,it).apply()},label={Text(role)},singleLine=true,modifier=Modifier.fillMaxWidth()) }
}
private val names=listOf("مجلس التدبير","المجلس التربوي","المجالس التعليمية","مجالس الأقسام","المجلس التلاميذي المحلي")
private fun roles(type:Int,level:String):List<String>{
 val primary=level.contains("ابتدائي");val middle=level.contains("إعدادي");val secondary=!primary&&!middle
 val director=listOf("مدير المؤسسة");val guards=listOf("الحارس العام للخارجية")
 return when(type){
 0->director+(if(primary) listOf("ممثل هيئة التدريس عن المستوى","ممثل الأطر الإدارية والتقنية") else guards+listOf("الحارس العام للداخلية (عند توفر داخلية أو مطعم)","ممثل هيئة التدريس عن المادة","ممثل الأطر الإدارية والتقنية 1","ممثل الأطر الإدارية والتقنية 2","مسير المصالح الاقتصادية")+(if(middle) listOf(peopleRoles[2]) else listOf("الناظر","ممثل التلاميذ 1","ممثل التلاميذ 2")))+listOf(peopleRoles[1],peopleRoles[3])
 1->director+(if(primary) listOf("ممثل هيئة التدريس عن المستوى") else guards+listOf("ممثل هيئة التدريس عن المادة")+(if(middle) listOf(peopleRoles[2]) else listOf("الناظر","ممثل التلاميذ 1","ممثل التلاميذ 2")))+peopleRoles[1]
 2->director+(if(secondary) listOf("الناظر") else emptyList())+"مدرس المادة"
 3->director+(if(!primary) guards else emptyList())+(if(middle) listOf(peopleRoles[2]) else emptyList())+listOf("مدرس القسم","ممثل جمعية آباء وأولياء التلاميذ")
 else->listOf("مندوب القسم","نائب مندوب القسم") }
}
private data class Member(val role:String,val name:String="",val office:String="")
private fun encode(rows:List<Member>)=JSONArray().apply{rows.forEach{put(JSONObject().put("role",it.role).put("name",it.name).put("office",it.office))}}.toString()
private fun decode(s:String):List<Member> = try{val a=JSONArray(s);(0 until a.length()).map{a.getJSONObject(it).let{j->Member(j.optString("role"),j.optString("name"),j.optString("office"))}}}catch(_:Exception){emptyList()}
private fun esc(s:String)=android.text.TextUtils.htmlEncode(s)
private fun printCouncil(c:Context,title:String,school:String,year:String,rows:List<Member>,student:Boolean){
 val web=WebView(c); fun table(items:List<Member>,office:Boolean)= "<table><tr><th>الصفة</th><th>الاسم الكامل</th></tr>"+items.joinToString(""){"<tr><td>${esc(if(office) it.office else it.role)}</td><td>${esc(it.name)}</td></tr>"}+"</table>"
 val html="<html dir='rtl'><meta charset='utf-8'><style>body{font-family:sans-serif}table{border-collapse:collapse;width:100%}td,th{border:1px solid #555;padding:8px}h1,h2{text-align:center}</style><body><h2>${esc(school)}</h2><p>الموسم الدراسي: ${esc(year)}</p><h1>${esc(title)}</h1>"+table(rows,false)+(if(student) "<h2>المكتب المنتخب</h2>"+table(rows.filter{it.office.isNotBlank()},true) else "")+"</body></html>"
 web.webViewClient=object:WebViewClient(){override fun onPageFinished(view:WebView,url:String){(c.getSystemService(Context.PRINT_SERVICE) as PrintManager).print(title,view.createPrintDocumentAdapter(title),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())}};web.loadDataWithBaseURL(null,html,"text/html","UTF-8",null)
}
@Composable fun CouncilsScreen(school:String,level:String,year:String,employees:List<ma.salah.eddine.schoolmanager.data.EmployeeEntity>,assignments:List<ma.salah.eddine.schoolmanager.data.TeacherAssignmentEntity>,onBack:()->Unit){
 val c=LocalContext.current;val prefs=remember{c.getSharedPreferences("councils_v1",Context.MODE_PRIVATE)};val people=remember{c.getSharedPreferences("institution_people",Context.MODE_PRIVATE)}
 var type by rememberSaveable{mutableIntStateOf(-1)};var instance by rememberSaveable{mutableStateOf("")};var opened by rememberSaveable{mutableStateOf(false)}
 BackHandler{if(opened)opened=false else if(type>=0)type=-1 else onBack()}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
 TextButton(onClick={if(opened)opened=false else if(type>=0)type=-1 else onBack()}){Text("رجوع")}
 if(type<0){Text("مجالس المؤسسة",style=MaterialTheme.typography.headlineSmall);names.forEachIndexed{i,n->ElevatedCard(onClick={type=i;instance="";opened=i !in 2..3},modifier=Modifier.fillMaxWidth()){Text(n,Modifier.padding(20.dp))}}}
 else if(!opened){Text(names[type]);
 val options=assignments.filter{it.isCurrent && it.schoolYear==year}.map{if(type==2)it.subjectName else it.className}.filter{it.isNotBlank()}.distinct().sorted()
 options.forEach{option->TextButton(onClick={instance=option;opened=true}){Text(option)}}
OutlinedTextField(instance,{instance=it},label={Text(if(type==2)"المادة الدراسية" else "القسم الدراسي")},modifier=Modifier.fillMaxWidth());Button(onClick={opened=true},enabled=instance.isNotBlank()){Text("فتح المجلس")}}
 else key(year,level,type,instance){val key="$year|$level|$type|$instance";var rows by remember{mutableStateOf(prefs.getString(key,null)?.let(::decode)?:roles(type,level).map{Member(it,people.getString(it,"").orEmpty())})};fun save(v:List<Member>){rows=v;prefs.edit().putString(key,encode(v)).apply()};val title=names[type]+if(instance.isBlank())"" else " — $instance"
 Text(title,style=MaterialTheme.typography.headlineSmall)
 OutlinedButton(onClick={
  val tasks=c.getSharedPreferences("employee_tasks",Context.MODE_PRIVATE)
  val allowed=roles(type,level).map{it.substringBefore(" (")}.toSet()
  var updated=rows
  employees.forEach{e->val role=tasks.getString(e.ppr,"").orEmpty();val name=e.nameArabic.ifBlank{e.nameFrench};if(role in allowed && name.isNotBlank() && updated.none{it.role==role && it.name==name}){val blank=updated.indexOfFirst{it.role.substringBefore(" (")==role && it.name.isBlank()};updated=if(blank>=0)updated.toMutableList().also{it[blank]=it[blank].copy(name=name)} else updated+Member(role,name)}}
  save(updated)
 }){Text("اقتراح الأعضاء حسب المهام المسندة")}

 val currentAssignments=assignments.filter{it.isCurrent && it.schoolYear==year}
 if(type==2 || type==3){
 val teachers=currentAssignments.filter{(if(type==2)it.subjectName else it.className).trim()==instance.trim()}.distinctBy{it.teacherCode.ifBlank{it.teacherName.trim()}}
 OutlinedButton(onClick={
 val role=if(type==2)"مدرس المادة" else "مدرس القسم"
 var updated=rows
 teachers.forEach{a->if(a.teacherName.isNotBlank() && updated.none{it.role==role && it.name==a.teacherName}){val blank=updated.indexOfFirst{it.role==role && it.name.isBlank()};updated=if(blank>=0)updated.toMutableList().also{it[blank]=it[blank].copy(name=a.teacherName)} else updated+Member(role,a.teacherName)}}
 save(updated)
 },enabled=teachers.isNotEmpty()){Text("جلب الأساتذة من توزيع الأقسام (${teachers.size})")}
 if(teachers.isEmpty())Text("لا توجد بيانات توزيع مطابقة لهذا المجلس والموسم الدراسي")
 }
 var editing by remember { mutableStateOf(-1) }
 var removing by remember { mutableStateOf(-1) }
 var picking by remember { mutableStateOf("") }
 var search by remember { mutableStateOf("") }
 if((type==0 || type==1) && !level.contains("ابتدائي")){
 val subjects=currentAssignments.map{it.subjectName.trim()}.filter{it.isNotBlank()}.distinct().sorted()
 LaunchedEffect(subjects){val missing=subjects.filter{subject->rows.none{it.role=="ممثل هيئة التدريس عن المادة: $subject"}};if(missing.isNotEmpty())save(rows.filterNot{it.role=="ممثل هيئة التدريس عن المادة" && it.name.isBlank()}+missing.map{Member("ممثل هيئة التدريس عن المادة: $it")})}
 }
 OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp)) {
 Row(Modifier.fillMaxWidth().padding(8.dp)){Text("الصفة",Modifier.weight(1f),style=MaterialTheme.typography.titleSmall);Text("الاسم الكامل",Modifier.weight(1f),style=MaterialTheme.typography.titleSmall)}
 rows.forEachIndexed { i,m ->
     fun editMember() {
         if (m.role.startsWith("ممثل هيئة التدريس عن المادة: ")) { picking=m.role.substringAfter(": ");search="" } else editing=i
     }
     HorizontalDivider()
     RecordSwipe("$i|${m.role}|${m.name}",{editMember()},{removing=i}) {
         Row(Modifier.fillMaxWidth().padding(vertical=4.dp),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
             Text(m.role,Modifier.weight(1f),style=MaterialTheme.typography.bodyMedium)
             TextButton(onClick={editMember()},modifier=Modifier.weight(1f)){Text(m.name.ifBlank{"اختيار عضو"})}
         }
     }
 }
 }}
 if(picking.isNotBlank())AlertDialog(onDismissRequest={picking=""},title={Text("ممثل مادة $picking")},text={Column(Modifier.heightIn(max=350.dp).verticalScroll(rememberScrollState())){OutlinedTextField(search,{search=it},label={Text("بحث عن أستاذ المادة")},singleLine=true);currentAssignments.filter{it.subjectName.trim()==picking && it.teacherName.contains(search.trim(),ignoreCase=true)}.distinctBy{it.teacherCode.ifBlank{it.teacherName}}.forEach{a->TextButton(onClick={val role="ممثل هيئة التدريس عن المادة: $picking";save(rows.map{if(it.role==role)it.copy(name=a.teacherName)else it});picking=""}){Text(a.teacherName)}}}},confirmButton={TextButton(onClick={picking=""}){Text("إغلاق")}})
 if (removing in rows.indices) AlertDialog(onDismissRequest={removing=-1},title={Text("تأكيد الحذف")},
     text={Text("حذف "+rows[removing].name.ifBlank { rows[removing].role }+" من المجلس؟")},
     confirmButton={TextButton(onClick={save(rows.filterIndexed { i,_->i!=removing });removing=-1;editing=-1}){Text("حذف")}},
     dismissButton={TextButton(onClick={removing=-1}){Text("إلغاء")}})
 if(editing in rows.indices){val m=rows[editing];var role by remember(editing){mutableStateOf(m.role)};var name by remember(editing){mutableStateOf(m.name)};var office by remember(editing){mutableStateOf(m.office)};AlertDialog(onDismissRequest={editing=-1},title={Text("تعديل العضو")},text={Column{OutlinedTextField(role,{role=it},label={Text("الصفة")});OutlinedTextField(name,{name=it},label={Text("الاسم الكامل")});if(type==4)OutlinedTextField(office,{office=it},label={Text("مهمة المكتب")})}},confirmButton={TextButton(onClick={save(rows.toMutableList().also{it[editing]=Member(role,name,office)});editing=-1}){Text("حفظ")}},dismissButton={Row{TextButton(onClick={removing=editing;editing=-1}){Text("حذف")};TextButton(onClick={editing=-1}){Text("إلغاء")}}})}
 OutlinedButton(onClick={save(rows+Member(""))},modifier=Modifier.fillMaxWidth()){Text("إضافة عضو")}
 if(type==4){val count=rows.count{it.office.isNotBlank()};Text("أعضاء المكتب: $count من 9 إلى 17");if(count !in 9..17)Text("يرجى مراجعة عدد أعضاء المكتب")}
 Button(onClick={printCouncil(c,title,school,year,rows,type==4)},modifier=Modifier.fillMaxWidth()){Text("تصدير PDF")}
 }
 }
}
