package ma.salah.eddine.schoolmanager

import java.time.LocalDate

internal fun noticeDue(first: LocalDate, stage: Int): LocalDate = when(stage) {
    1, 2, 3 -> first.plusWeeks(stage.toLong())
    4 -> first.plusMonths(1).plusDays(1)
    else -> error("مرحلة غير معروفة")
}
