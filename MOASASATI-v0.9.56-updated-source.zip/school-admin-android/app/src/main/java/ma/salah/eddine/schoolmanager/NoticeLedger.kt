package ma.salah.eddine.schoolmanager

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

internal val noticeTitles = listOf("الإشعار الأول", "الإشعار الثاني", "الإشعار الثالث", "إشعار بالانقطاع")
internal const val ongoing = "غياب مستمر"
internal const val stopped = "تأكد الانقطاع"

internal data class Dispatch(val day:String,val number:String,val guardian:String,val address:String) {
    fun json()=JSONArray(listOf(day,number,guardian,address))
}

internal data class NoticeCase(val id:String,val massar:String,val name:String,val section:String,val first:String,
    val guardian:String,val address:String,val visit:String="",val status:String=ongoing,val statusDate:String="",
    val sent:List<Dispatch> = emptyList()) {
    fun due(stage:Int)=noticeDue(LocalDate.parse(first),stage)
    val next get()=sent.size+1
    fun available(today:LocalDate):Boolean = next<=4 && !due(next).isAfter(today) &&
        (status==ongoing || (status==stopped && next==4))
    fun json()=JSONObject().apply {
        put("id",id);put("massar",massar);put("name",name);put("section",section);put("first",first)
        put("guardian",guardian);put("address",address);put("visit",visit);put("status",status);put("statusDate",statusDate)
        put("sent",JSONArray().apply { sent.forEach { put(it.json()) } })
    }
}

internal fun noticeCases(raw:String?):List<NoticeCase> {
    val array=JSONArray(raw ?: "[]")
    return (0 until array.length()).map { i ->
        val x=array.getJSONObject(i)
        val rows=x.getJSONArray("sent")
        NoticeCase(x.getString("id"),x.getString("massar"),x.getString("name"),x.getString("section"),x.getString("first"),
            x.getString("guardian"),x.getString("address"),x.optString("visit"),x.getString("status"),x.optString("statusDate"),
            (0 until rows.length()).map { j -> val a=rows.getJSONArray(j); Dispatch(a.getString(0),a.getString(1),a.getString(2),a.getString(3)) })
    }
}
