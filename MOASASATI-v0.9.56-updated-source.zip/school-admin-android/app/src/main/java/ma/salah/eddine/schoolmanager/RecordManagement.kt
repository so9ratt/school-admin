package ma.salah.eddine.schoolmanager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ma.salah.eddine.schoolmanager.data.*

@Composable internal fun RecordEditor(title:String, labels:List<String>, initial:List<String>, warning:String, valid:(List<String>)->Boolean, save:suspend (List<String>)->Unit, remove:suspend ()->Unit, deleting:Boolean, close:()->Unit) {
 var values by remember { mutableStateOf(initial) }; var confirm by remember { mutableStateOf(deleting) }; var busy by remember { mutableStateOf(false) }; var error by remember { mutableStateOf("") }; val scope=rememberCoroutineScope()
 fun run(action:suspend ()->Unit) { busy=true; scope.launch { try { action(); close() } catch(e:Exception) { error="تعذر حفظ العملية: "+(e.message?:"") } finally { busy=false } } }
 fun cancelDelete() { if (!busy) { if (deleting) close() else confirm=false } }
 if(confirm) AlertDialog(onDismissRequest={cancelDelete()},title={Text("تأكيد الحذف")},text={Text(if(error.isBlank()) warning else warning+"\n"+error)},confirmButton={TextButton(enabled=!busy,onClick={run(remove)}){Text("حذف نهائي")}},dismissButton={TextButton(enabled=!busy,onClick={cancelDelete()}){Text("إلغاء")}})
 else AlertDialog(onDismissRequest={if(!busy)close()},title={Text(title)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){ labels.forEachIndexed { i,label -> OutlinedTextField(value=values[i],onValueChange={v->values=values.toMutableList().also{it[i]=v}},label={Text(label)},modifier=Modifier.fillMaxWidth(),enabled=!busy) }; if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error); TextButton(enabled=!busy,onClick={confirm=true}){Text("حذف السجل",color=MaterialTheme.colorScheme.error)} }},confirmButton={TextButton(enabled=!busy&&valid(values),onClick={run{save(values)}}){Text("حفظ التعديلات")}},dismissButton={TextButton(enabled=!busy,onClick=close){Text("إلغاء")}})
}
private fun validDateTime(v:List<String>):Boolean = runCatching { java.time.LocalDate.parse(v[0]); java.time.LocalTime.parse(v[1]); true }.getOrDefault(false)
@Composable internal fun ManageConduct(dao:SchoolDao,r:ConductRecord,deleting:Boolean=false,close:()->Unit) {
 RecordEditor("تعديل السجل",listOf("التاريخ YYYY-MM-DD","التوقيت HH:mm","الأسباب","الأستاذ","المادة","اقتراح الأستاذ","الإجراء المتخذ","صفة ولي الأمر","اسم ولي الأمر","الهاتف","البطاقة الوطنية"),listOf(r.date,r.time,r.reasons,r.teacher,r.subject,r.proposed,r.decision,r.relation,r.guardian,r.phone,r.identity),"سيُحذف هذا السجل نهائيًا من ملف التلميذ. هل تؤكد؟",{validDateTime(it)&&it[2].isNotBlank()},{v->dao.saveConduct(r.copy(date=v[0],time=v[1],reasons=v[2],teacher=v[3],subject=v[4],proposed=v[5],decision=v[6],relation=v[7],guardian=v[8],phone=v[9],identity=v[10]))},{dao.deleteConduct(r.id)},deleting,close)
}
@Composable internal fun ManageSlip(dao:SchoolDao,r:EntrySlip,count:Int,deleting:Boolean=false,close:()->Unit) {
 RecordEditor("تعديل ورقة الدخول",listOf("التاريخ YYYY-MM-DD","التوقيت HH:mm","النوع: غياب أو تأخر","اسم ولي الأمر","صفة ولي الأمر","البطاقة الوطنية"),listOf(r.date,r.time,r.reason,r.guardianName,r.relation,r.identity),"ستُحذف الورقة من سجلات جميع المستفيدين منها ($count). هل تؤكد؟",{validDateTime(it)&&it[2] in listOf("غياب","تأخر")},{v->dao.updateSlip(r.copy(date=v[0],time=v[1],reason=v[2],guardianName=v[3],relation=v[4],identity=v[5]))},{dao.deleteSlip(r.id)},deleting,close)
}
