package ma.salah.eddine.schoolmanager

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.salah.eddine.schoolmanager.data.*
import ma.salah.eddine.schoolmanager.importing.*

private fun Movement.key() = listOf(year,kind,massar,eventDate)

@Composable
internal fun MovementImport(dao: SchoolDao, year: String, fileName: (Uri)->String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var preview by remember(year) { mutableStateOf(emptyList<MovementSheet>()) }
    var known by remember { mutableStateOf(emptyMap<List<String>,Movement>()) }
    var message by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true
            runCatching {
                withContext(Dispatchers.IO) {
                    val batch = uris.distinct().flatMap { uri ->
                        val name = fileName(uri)
                        context.contentResolver.openInputStream(uri)?.use { readMovementSheets(it,name,year) }
                            ?: error("تعذرت قراءة $name")
                    }
                    val conflicts = batch.flatMap { it.rows }.groupBy { it.key() }.any { it.value.distinct().size > 1 }
                    require(!conflicts) { "توجد معطيات متعارضة للحركة نفسها. راجع الملفات أو استوردها منفردة." }
                    batch to dao.movements(year).first().associateBy { it.key() }
                }
            }.onSuccess { (batch,old) -> preview=batch; known=old; message="" }
             .onFailure { message=it.localizedMessage.orEmpty() }
            busy = false
        }
    }
    OutlinedButton(enabled=!busy,onClick={picker.launch(arrayOf("application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/octet-stream"))},modifier=Modifier.fillMaxWidth()) {
        Text(if(busy) "جارٍ معالجة الملفات…" else "استيراد لوائح حركية التلاميذ")
    }
    if(message.isNotBlank()) Text(message)
    if(preview.isNotEmpty()) {
        val rows = preview.flatMap { it.rows }.distinctBy { it.key() }
        val valid = preview.all { it.errors.isEmpty() }
        AlertDialog(onDismissRequest={if(!busy)preview=emptyList()},title={Text("معاينة حركية التلاميذ")},
            text={ LazyColumn {
                item { Text("الأوراق ${preview.size}  •  جديدة ${rows.count { it.key() !in known }}  •  معدّلة ${rows.count { it.key() in known && known[it.key()] != it }}  •  مسجلة ${rows.count { known[it.key()] == it }}") }
                items(preview){sheet ->
                    HorizontalDivider()
                    Text(sheet.name,style=MaterialTheme.typography.labelMedium)
                    Text(MovementKind.valueOf(sheet.coverage.kind).label+" • "+sheet.coverage.level+" "+sheet.coverage.section)
                    Text("${sheet.rows.size} سجل")
                    sheet.errors.forEach { Text(it,color=MaterialTheme.colorScheme.error) }
                }
            }},confirmButton={TextButton(enabled=valid && !busy,onClick={
                busy=true
                scope.launch {
                    runCatching { dao.storeMovements(rows,preview.map { it.coverage }.distinct()) }
                        .onSuccess { message="تم حفظ لوائح الحركية";preview=emptyList() }
                        .onFailure { message="تعذر حفظ اللوائح";preview=emptyList() }
                    busy=false
                }
            }){Text("تأكيد الحفظ")}},dismissButton={TextButton(enabled=!busy,onClick={preview=emptyList()}){Text("إلغاء")}})
    }
}

@Composable
internal fun MovementScreen(dao: SchoolDao,year: String,school:String,academy:String,province:String,onStudent:(StudentListRow)->Unit,back:()->Unit) {
    val all by remember(year){dao.movements(year)}.collectAsState(initial=emptyList())
    val sheets by remember(year){dao.coverage(year)}.collectAsState(initial=emptyList())
    var selected by rememberSaveable(year){mutableStateOf("")}
    var query by rememberSaveable(selected){mutableStateOf("")}
    var level by rememberSaveable(selected){mutableStateOf("")}
    var section by rememberSaveable(selected){mutableStateOf("")}
    var roster by remember(year){mutableStateOf(emptyMap<String,StudentListRow>())}
    LaunchedEffect(year){ roster=dao.studentsForYear(year).associateBy { it.massarCode } }
    val close = { if(selected.isBlank()) back() else selected="" }
    BackHandler(enabled=selected.isNotBlank()){selected=""}
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        PageTitle(if(selected.isEmpty()) "حركية التلاميذ" else when(MovementKind.valueOf(selected)) {
            MovementKind.ARRIVAL -> "لائحة الوافدين"
            MovementKind.DEPARTURE -> "لائحة المغادرين"
            MovementKind.NON_ATTENDANCE -> "لائحة غير الملتحقين"
            MovementKind.DROPOUT -> "لائحة المنقطعين"
            MovementKind.RETURN -> "لائحة المرجعين"
            MovementKind.CLASS_CHANGE -> "تغيير القسم"
        },close)
        Text("الموسم الدراسي $year", style=MaterialTheme.typography.labelLarge)
        if(selected.isEmpty()) {
            Text("تحيين لائحة التلاميذ من الإعدادات", fontSize = 12.sp)
            MovementKind.entries.forEach { kind ->
                val covered=sheets.filter { it.kind==kind.name }
                ElevatedCard(onClick={selected=kind.name},modifier=Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(kind.label,fontWeight=FontWeight.Bold)
                        Text(if(covered.isEmpty()) "لم تُستورد لائحة" else "${all.filter { it.kind==kind.name }.distinctBy { it.massar }.size} تلميذاً")
                    }
                }
            }
        } else {
            val covered=sheets.filter { it.kind==selected }
            val rows=all.filter { it.kind==selected }
            fun classOf(m:Movement)=m.section.ifBlank { roster[m.massar]?.takeIf { it.levelName.trim()==m.level.trim() }?.className.orEmpty() }
            val levels=(covered.map { it.level }+roster.values.map { it.levelName }).distinct().sorted()
            val sections=rows.filter { level.isEmpty() || it.level==level }.map { classOf(it) }.filter(String::isNotBlank).distinct().sorted()
            if(covered.isNotEmpty()) Text("المستويات المستوردة ${covered.distinctBy { it.level }.size}",style=MaterialTheme.typography.labelMedium)
            SearchBox(query,{query=it},"الاسم أو رمز مسار")
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                RosterFilter("حسب المستوى",level,levels,Modifier.weight(1f)){level=it;section=""}
                RosterFilter("حسب القسم",section,sections,Modifier.weight(1f)){section=it}
            }
            val visible=rows.filter { (level.isEmpty() || it.level==level) && (section.isEmpty() || classOf(it)==section) &&
                (it.fullName.contains(query.trim()) || it.massar.contains(query.trim(),true)) }
            Text(if(covered.none { level.isEmpty() || it.level==level }) "لم تُستورد لائحة لهذا الاختيار" else "التلاميذ ${visible.distinctBy { it.massar }.size}  •  السجلات ${visible.size}")
            TableExport(MovementKind.valueOf(selected).label,school,academy,province,year,listOf("مسار","الاسم","القسم","التاريخ","من","إلى"),visible.groupBy { classOf(it).ifBlank { "بدون قسم" } }.map { (name,rs) -> ExportGroup(name,rs.map { listOf(it.massar,it.fullName,classOf(it),it.eventDate,it.origin,it.destination) }) })
            LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                items(visible){m -> Card(onClick={roster[m.massar]?.let(onStudent)},enabled=m.massar in roster,modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(disabledContainerColor=MaterialTheme.colorScheme.surface,disabledContentColor=MaterialTheme.colorScheme.onSurface)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(listOfNotNull((m.ordinal ?: roster[m.massar]?.ordinal)?.toString(),m.fullName,m.massar).joinToString("  •  "),fontWeight=FontWeight.Bold)
                        Text(listOf(m.level,classOf(m),m.eventDate).filter(String::isNotBlank).joinToString("  •  "))
                        if(m.origin.isNotBlank()) Text("من "+m.origin)
                        if(m.destination.isNotBlank()) Text("إلى "+m.destination)
                    }
                } }
            }
        }
    }
}
