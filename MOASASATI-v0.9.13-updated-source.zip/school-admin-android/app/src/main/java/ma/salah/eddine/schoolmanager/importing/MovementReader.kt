package ma.salah.eddine.schoolmanager.importing

import jxl.Workbook
import jxl.WorkbookSettings
import ma.salah.eddine.schoolmanager.data.Movement
import ma.salah.eddine.schoolmanager.data.MovementCoverage
import java.io.InputStream
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

internal enum class MovementKind(val label: String, val marker: String) {
    ARRIVAL("الوافدون", "الوافد"), DEPARTURE("المغادرون", "المغادر"),
    NON_ATTENDANCE("غير الملتحقين", "ملتحق"), DROPOUT("المنقطعون", "منقطع"), RETURN("المرجعون", "مرجع"), CLASS_CHANGE("تغيير القسم", "تغيير القسم")
}

internal data class MovementSheet(val name: String, val coverage: MovementCoverage,
    val rows: List<Movement>, val errors: List<String>)

private fun normalized(s: String) = s.trim().replace(Regex("[أإآ]"), "ا")
    .replace(Regex("[\\s:：ـ]+"), "")

private fun movementDate(value: String): String {
    if (value.isBlank()) return ""
    value.toDoubleOrNull()?.let {
        require(it in 1.0..150000.0) { "تاريخ غير صالح" }
        return LocalDate.of(1899,12,30).plusDays(it.toLong()).toString()
    }
    for (pattern in listOf("d-M-uuuu","uuuu-M-d","d/M/uuuu","uuuu/M/d")) {
        val result = runCatching { LocalDate.parse(value, DateTimeFormatter.ofPattern(pattern)
            .withResolverStyle(java.time.format.ResolverStyle.STRICT)) }.getOrNull()
        if (result != null) return result.toString()
    }
    error("تاريخ غير مقروء")
}

internal fun readMovementSheets(input: InputStream, file: String, activeYear: String): List<MovementSheet> {
    val stream = input.buffered()
    stream.mark(8)
    val signature = stream.read()
    stream.reset()
    val sheets = when(signature) {
        0x50 -> XlsxDocument.read(stream).sheets
        0xD0 -> {
            val book = Workbook.getWorkbook(stream, WorkbookSettings().apply { setSuppressWarnings(true) })
            try {
                book.sheets.map { sheet ->
                    val cells = mutableMapOf<CellAddress,String>()
                    for (row in 0 until sheet.rows) {
                        sheet.getRow(row).forEachIndexed { col, cell ->
                            if (cell.contents.isNotBlank()) cells[CellAddress(row+1,col+1)] = cell.contents
                        }
                    }
                    XlsxSheet(sheet.name,cells)
                }
            } finally { book.close() }
        }
        else -> error("صيغة الملف غير معروفة")
    }
    return sheets.map { sheet ->
        val cells = sheet.populatedCells()
        fun value(r:Int,c:Int) = sheet.cell(r,c).orEmpty().trim()
        val kind = MovementKind.entries.firstOrNull { k -> cells.any {
            it.key.row <= 5 && normalized(it.value).contains(normalized(k.marker))
        }} ?: error("$file · ${sheet.name} — تعذر تحديد نوع اللائحة")
        val legacyLayout = cells.keys.any { it.row == 13 && normalized(value(13,it.column)) == "الرمز" }
        val level = if (legacyLayout) value(10,20) else value(7,3)
        val section = if (legacyLayout) value(10,9) else value(8,3)
        val year = if (legacyLayout) value(6,2) else value(7,7)
        require(level.isNotBlank() && year.isNotBlank()) { "$file · ${sheet.name} — المستوى أو الموسم مفقود" }
        require(year.replace('-','/') == activeYear.trim().replace('-','/')) { "$file · الموسم $year مختلف عن الموسم المختار $activeYear" }
        val header = if (legacyLayout) 13 else 10
        val columns = cells.filterKeys { it.row == header }.entries.associate { normalized(it.value) to it.key.column }
        fun column(vararg names:String) = names.firstNotNullOfOrNull { columns[normalized(it)] }
        val code = column("رقم التلميذ","الرمز") ?: error("عمود رمز التلميذ مفقود")
        val first = column("الإسم") ?: error("عمود الاسم مفقود")
        val last = column("النسب") ?: error("عمود النسب مفقود")
        val errors = mutableListOf<String>()
        val rows = mutableListOf<Movement>()
        for (r in cells.keys.map { it.row }.filter { it > header }.toSortedSet()) {
            fun field(vararg names:String) = column(*names)?.let { value(r,it) }.orEmpty()
            val massar = value(r,code).uppercase(Locale.ROOT)
            val name = listOf(value(r,first),value(r,last)).filter(String::isNotBlank).joinToString(" ")
            if (massar.isEmpty() && name.isEmpty()) continue
            if (!massar.matches(Regex("[A-Z][0-9]{9}")) || name.isBlank()) {
                errors += "السطر $r — اسم أو رمز مسار غير صالح"
                continue
            }
            val date = runCatching { movementDate(field("تاريخ التحويل","تاريخ الانقطاع")) }.getOrNull()
            if (date == null || (kind != MovementKind.NON_ATTENDANCE && date.isEmpty())) {
                errors += "السطر $r — تاريخ الحركة مفقود أو غير صالح"
                continue
            }
            rows += Movement(activeYear,kind.name,massar,date,name,level,section,
                field("المؤسسة الأصلية"),field("مؤسسة الإستقبال"),field("نوع التحويل"),field("ر.ت").toDoubleOrNull()?.toInt())
        }
        MovementSheet("$file · ${sheet.name}",MovementCoverage(activeYear,kind.name,level,section),rows,errors)
    }
}
